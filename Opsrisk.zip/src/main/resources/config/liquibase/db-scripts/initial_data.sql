
--
-- Name: control_types; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.control_types AS ENUM (
    'Operational',
    'Governance',
    'Supervisory'
);


ALTER TYPE public.control_types OWNER TO postgres;

--
-- Name: fmech_types; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.fmech_types AS ENUM (
    'People',
    'Process',
    'Systems'
);


ALTER TYPE public.fmech_types OWNER TO postgres;

--
-- Name: level_types; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.level_types AS ENUM (
    'Level1',
    'Level2',
    'Level3',
    'Level4',
    'Level5'
);


ALTER TYPE public.level_types OWNER TO postgres;

--
-- Name: purposes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.purposes AS ENUM (
    'Preventative',
    'Detective',
    'Mitigative',
    'Preventative '
);


ALTER TYPE public.purposes OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: controls_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.controls_tbl (
    policy_ref_id bigint,
    control_minimum_standard_id character varying(10),
    control_name character varying(255),
    control_description text,
    fmode_ref_id bigint,
    control_releveant_process text,
    control_purpose public.purposes,
    control_type public.control_types,
    control_ref_id character varying(10) NOT NULL,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.controls_tbl OWNER TO postgres;

--
-- Name: finmat_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.finmat_ref_tbl (
    finmat_ref_id bigint NOT NULL,
    finmat_level public.level_types,
    finmat_label character varying(20),
    finmat_ext_impact_description character varying(255),
    finmat_reg_impact_description character varying(255),
    finmat_brand character varying(255),
    finmat_upper_threshold numeric(15,2),
    finmat_lower_threshold numeric(15,2),
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.finmat_ref_tbl OWNER TO postgres;

--
-- Name: finmat_ref_tbl_finmat_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.finmat_ref_tbl_finmat_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.finmat_ref_tbl_finmat_ref_id_seq OWNER TO postgres;

--
-- Name: finmat_ref_tbl_finmat_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.finmat_ref_tbl_finmat_ref_id_seq OWNED BY public.finmat_ref_tbl.finmat_ref_id;


--
-- Name: fmech_ref_det_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fmech_ref_det_tbl (
    fmech_ref_det_id bigint NOT NULL,
    fmech_ref_det_description text,
    fmech_ref_det_level public.level_types,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.fmech_ref_det_tbl OWNER TO postgres;

--
-- Name: fmech_ref_det_tbl_fmech_ref_det_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fmech_ref_det_tbl_fmech_ref_det_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fmech_ref_det_tbl_fmech_ref_det_id_seq OWNER TO postgres;

--
-- Name: fmech_ref_det_tbl_fmech_ref_det_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fmech_ref_det_tbl_fmech_ref_det_id_seq OWNED BY public.fmech_ref_det_tbl.fmech_ref_det_id;


--
-- Name: fmech_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fmech_ref_tbl (
    fmech_ref_id bigint NOT NULL,
    fmech_description text,
    fmech_type public.fmech_types,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.fmech_ref_tbl OWNER TO postgres;

--
-- Name: fmech_ref_tbl_fmech_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fmech_ref_tbl_fmech_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fmech_ref_tbl_fmech_ref_id_seq OWNER TO postgres;

--
-- Name: fmech_ref_tbl_fmech_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fmech_ref_tbl_fmech_ref_id_seq OWNED BY public.fmech_ref_tbl.fmech_ref_id;


--
-- Name: fmode_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fmode_ref_tbl (
    fmode_ref_id bigint NOT NULL,
    fmode_ref_level_1 character varying(100),
    fmode_ref_level_2 character varying(100),
    fmode_ref_level_3 character varying(100),
    fmode_ref_description text,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.fmode_ref_tbl OWNER TO postgres;

--
-- Name: fmode_ref_tbl_fmode_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fmode_ref_tbl_fmode_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fmode_ref_tbl_fmode_ref_id_seq OWNER TO postgres;

--
-- Name: fmode_ref_tbl_fmode_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fmode_ref_tbl_fmode_ref_id_seq OWNED BY public.fmode_ref_tbl.fmode_ref_id;


--
-- Name: frequency_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.frequency_ref_tbl (
    frequency_ref_id bigint NOT NULL,
    frequency_label character varying(20),
    frequency_name character varying(20),
    frequency_description character varying(50),
    frequency_upper numeric(7,3),
    frequency_lower numeric(7,3),
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.frequency_ref_tbl OWNER TO postgres;

--
-- Name: frequency_ref_tbl_frequency_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.frequency_ref_tbl_frequency_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.frequency_ref_tbl_frequency_ref_id_seq OWNER TO postgres;

--
-- Name: frequency_ref_tbl_frequency_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.frequency_ref_tbl_frequency_ref_id_seq OWNED BY public.frequency_ref_tbl.frequency_ref_id;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1000
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: jhi_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_authority (
    name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_authority OWNER TO postgres;

--
-- Name: jhi_persistent_audit_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_persistent_audit_event (
    event_id bigint NOT NULL,
    principal character varying(50) NOT NULL,
    event_date timestamp without time zone,
    event_type character varying(255)
);


ALTER TABLE public.jhi_persistent_audit_event OWNER TO postgres;

--
-- Name: jhi_persistent_audit_evt_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_persistent_audit_evt_data (
    event_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.jhi_persistent_audit_evt_data OWNER TO postgres;

--
-- Name: jhi_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_user (
    id bigint NOT NULL,
    login character varying(50) NOT NULL,
    password_hash character varying(60) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(254),
    image_url character varying(256),
    activated boolean NOT NULL,
    lang_key character varying(6),
    activation_key character varying(20),
    reset_key character varying(20),
    created_by character varying(50),
    created_date timestamp without time zone NULL,
    reset_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.jhi_user OWNER TO postgres;

--
-- Name: jhi_user_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_user_authority (
    user_id bigint NOT NULL,
    authority_name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_user_authority OWNER TO postgres;

--
-- Name: kra_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kra_tbl (
    kra_id bigint NOT NULL,
    kra_label character varying(100),
    kra_description text,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.kra_tbl OWNER TO postgres;

--
-- Name: kra_tbl_kra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kra_tbl_kra_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kra_tbl_kra_id_seq OWNER TO postgres;

--
-- Name: kra_tbl_kra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kra_tbl_kra_id_seq OWNED BY public.kra_tbl.kra_id;


--
-- Name: policy_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policy_ref_tbl (
    policy_ref_id bigint NOT NULL,
    policy_name character varying(100),
    policy_description text,
    policy_link character varying(100),
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying,
    last_modified_date timestamp without time zone
);


ALTER TABLE public.policy_ref_tbl OWNER TO postgres;

--
-- Name: policy_ref_tbl_policy_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.policy_ref_tbl_policy_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.policy_ref_tbl_policy_ref_id_seq OWNER TO postgres;

--
-- Name: policy_ref_tbl_policy_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.policy_ref_tbl_policy_ref_id_seq OWNED BY public.policy_ref_tbl.policy_ref_id;


--
-- Name: process_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_ref_tbl (
    process_ref_id bigint NOT NULL,
    process_id bigint,
    process_step_id character varying(15),
    process_description text,
    process_step_description character varying(255),
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.process_ref_tbl OWNER TO postgres;

--
-- Name: process_ref_tbl_process_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_ref_tbl_process_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_ref_tbl_process_ref_id_seq OWNER TO postgres;

--
-- Name: process_ref_tbl_process_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_ref_tbl_process_ref_id_seq OWNED BY public.process_ref_tbl.process_ref_id;


--
-- Name: riskcube_ref_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.riskcube_ref_tbl (
    riskcube_ref_id bigint NOT NULL,
    finmat_ref_id bigint,
    frequency_ref_id bigint,
    frequency_risk_level character varying(50),
    frequency_rag character varying,
    frequency_action text,
    is_delete boolean DEFAULT false,
    created_by character varying(50)  NULL,
    created_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.riskcube_ref_tbl OWNER TO postgres;

--
-- Name: riskcube_ref_tbl_riskcube_ref_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.riskcube_ref_tbl_riskcube_ref_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.riskcube_ref_tbl_riskcube_ref_id_seq OWNER TO postgres;

--
-- Name: riskcube_ref_tbl_riskcube_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.riskcube_ref_tbl_riskcube_ref_id_seq OWNED BY public.riskcube_ref_tbl.riskcube_ref_id;



--
-- Name: finmat_ref_tbl finmat_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.finmat_ref_tbl ALTER COLUMN finmat_ref_id SET DEFAULT nextval('public.finmat_ref_tbl_finmat_ref_id_seq'::regclass);


--
-- Name: fmech_ref_det_tbl fmech_ref_det_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fmech_ref_det_tbl ALTER COLUMN fmech_ref_det_id SET DEFAULT nextval('public.fmech_ref_det_tbl_fmech_ref_det_id_seq'::regclass);


--
-- Name: fmech_ref_tbl fmech_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fmech_ref_tbl ALTER COLUMN fmech_ref_id SET DEFAULT nextval('public.fmech_ref_tbl_fmech_ref_id_seq'::regclass);


--
-- Name: fmode_ref_tbl fmode_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fmode_ref_tbl ALTER COLUMN fmode_ref_id SET DEFAULT nextval('public.fmode_ref_tbl_fmode_ref_id_seq'::regclass);


--
-- Name: frequency_ref_tbl frequency_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frequency_ref_tbl ALTER COLUMN frequency_ref_id SET DEFAULT nextval('public.frequency_ref_tbl_frequency_ref_id_seq'::regclass);


--
-- Name: kra_tbl kra_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kra_tbl ALTER COLUMN kra_id SET DEFAULT nextval('public.kra_tbl_kra_id_seq'::regclass);


--
-- Name: policy_ref_tbl policy_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_ref_tbl ALTER COLUMN policy_ref_id SET DEFAULT nextval('public.policy_ref_tbl_policy_ref_id_seq'::regclass);


--
-- Name: process_ref_tbl process_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_ref_tbl ALTER COLUMN process_ref_id SET DEFAULT nextval('public.process_ref_tbl_process_ref_id_seq'::regclass);


--
-- Name: riskcube_ref_tbl riskcube_ref_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.riskcube_ref_tbl ALTER COLUMN riskcube_ref_id SET DEFAULT nextval('public.riskcube_ref_tbl_riskcube_ref_id_seq'::regclass);


--
-- Data for Name: controls_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (8, 'MP04', 'Model testing ', 'A model must have been tested for accuracy / success before being employed to make decisions in A live environment.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC049');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP01', 'Appointment of DPO ', 'VM will assign an Executive who must establish an Information Management Control Framework to ensure the control, integrity and quality of all information throughout the organization.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC001');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP02', 'Assign information owners', 'Each business area must assign an Information Owner who will be responsible for ensuring the quality and integrity of information used and created by that business area.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC002');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP03', 'Alignment of terms based on VM''s data dictionary ', 'VM will maintain a Data Dictionary (Business & Technical) which will include a definition of the information and set out relevant business and technical rules and usage.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC003');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP04', 'Maintenance of VM Data Model', ',VM will maintain a structured enterprise-wide data model to describe VM?s information, its attributes, relationships, and supporting systems.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC004');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP04', 'Reviewing of data model', ',The model must be reviewed annually, or following sign off by Business Change.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC005');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP06', 'Documentation of data lineage', ',Where it is necessary to store multiple instances of information, the information owner must define and document the relationship between each instance.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC006');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP06', 'Establishment of change synchronisation process', 'A process for change synchronisation must exist to ensure consistency and quality between multiple instances of information.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC007');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (1, 'IMP07', 'Maintenance record retention schedules ', 'Each Information Owner must maintain a record retention schedule which must document the retention periods for all information owned by that business area. The retention periods must comply with legal or regulatory requirements. ', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC008');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP01', 'Appointment of systems executive (CIO) ', ',VM will appoint an Executive with overall responsibility for the design, procurement, development, assurance (testing), implementation, resilience, security, support and management of IT Systems which support business critical processes.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC009');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP01', 'Setting of technical standards ', ',All IT systems will be designed and built to agreed technical standards to enable business processes and facilitate good customer experience, whilst maintaining security, accessibility and availability of services.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC010');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP02', 'Maintenance of a risk or technical deviation framework ', ',The CIO must maintain an approval framework and process to ensure that any risks or technical deviation introduced by non-conformance with the IT Strategy and roadmaps can be authorised, recorded, validated and communicated.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC011');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP03', 'Maintenance IT investment management framework ', ',VM must maintain a framework to manage IT investment programmes that encompasses cost, benefits, risk and prioritisation within budget and aligns with business strategy.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC012');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP04', 'Management of  single owner for third party systems', 'Relationships with third party suppliers of IT Systems or Services must be initiated by IT with support from procurement and the business. The ongoing ownership and management must be through an agreed appropriate owner.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC013');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP04', 'Management of cloud-based third party relationships ,Where a Cloud-based System or Service is being considered this must be initiated by IT with support from Procurement', ' CCP and the relevant business areas. This must be in line with the Cloud Standard and the FCA 16/5 Guidelines for firms outsourcing to the Cloud.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC014');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP07', 'Agreement of service level  ', ',IT and business areas must agree formal Service Level Agreements (SLAs) for the availability and performance of IT systems commensurate with business criticality.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC015');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP08', 'Formulation of critical system disaster recovery plans ', ',All critical IT Systems must have Disaster Recovery plans which refer to and are developed in line with the Business Continuity Policy. These must be maintained and tested in line with a documented and agreed test schedule according to their business criticality to restore service in the event of disruption or degradation and to prevent systemic recurrence.', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Operational', 'PLC016');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP09', 'Definition of IT system change procedures ', ',The CIO must define standards,  procedures and processes to be followed for implementing change to IT Service or IT Systems.', NULL, ',Model design development and management and innovation', 'Preventative', 'Governance', 'PLC017');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP10', 'Regulation of employee access to IT systems', 'Line Managers with the support of IT must ensure that Colleagues have access to the relevant services to perform their job role. Colleagues requesting access must do so in line with the current authorisation procedures.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC018');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (2, 'SYSP10', 'Regulation of 3rd party access to IT systems ', '3rd party software or devices must not access VM networks without explicit approval from ITC. Requests should be made through standard access management procedures.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC019');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP01', 'Appointment of BCM owner / executive ', ',VM will assign responsibility for Business Continuity Management to a nominated Executive who will be responsible for the design maintenance and operation of an organisation wide Business Continuity Management Framework and an Incident & Crisis Management Framework.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC020');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP02', 'Completion of BIA ', ',At least every year, each business area must complete a Business Impact Analysis (BIA) to prioritise the business activities that need to be recovered and to define the related recovery time objectives.', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Operational', 'PLC021');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP03', 'BC plan creation', ',Each business area must have a robust business continuity plan in place which articulates recovery strategies to meet agreed recovery objectives defined in the BIAs,   and these plans must be approved by plan owners and tested', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Operational', 'PLC022');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP04', 'Testing of high / medium critical services ', 'BCP?s and recovery strategies will be tested in accordance with a defined Testing and Maintenance framework. All processes with a criticality of ?High? and ?Medium? will be tested on at least an annual basis or following significant changes.', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Operational', 'PLC023');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP05', 'BCM training', 'Business continuity roles and responsibilities will be reinforced through an ongoing education and awareness programme with central co-ordination from the Business Continuity Team.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC024');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP06', 'BCM evidencing', ',The business must maintain sufficient evidence to demonstrate the ongoing maintenance,  approval and testing of business continuity and crisis management arrangements for review by internal audit and external regulators.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC025');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC07 ', 'Third party vulnerable customer oversight arrangements ', 'Line 1 must ensure appropriate oversight arrangements are in place covering the treatment of vulnerable customers by partners.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Supervisory', 'PLC089');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP07', 'ICMF training', 'Members involved in the ICMF framework must be trained and the processes regularly tested to provide assurance on how incidents impacting business operations are identified,  escalated,  communicated and managed effectively.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC026');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (3, 'BCMP07', 'PIR completion', 'The CMO will co-ordinate Post Incident Reviews (PIR?s) at closure of incident. PIR will be circulated to Crisis Management Team (CRT) members involved in the incident,  to ensure any lessons learnt are captured. Any actions arising from PIR will be tracked and reported via Group Security governance.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC027');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP01', 'Defined Governancecycle', 'All Change projects are managed by a defined cycle of Governanceand Board meetings with clear monitoring and decisioning accountabilities. This applies to projects from initiation through the full delivery lifecycle.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Governance', 'PLC028');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP01', 'Appointment of executive sponsor ', 'Each Change must have a designated Executive sponsor before funding is considered. Funding is approved by Change Board as part of the Change Portfolio.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Governance', 'PLC029');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP02', 'Clear reporting standards', ',To support effective decision making across all aspects of the Change Portfolio,  clear processes are in place to report project progress to predefined standards and clearly identify the instances of changes on the Change Portfolio where these standards are not being met.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Governance', 'PLC030');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP02', 'Post completion review ', ',All projects will undertake a Post Implementation Review (PIR). In addition,  all benefits will be tracked throughout the project life cycle and beyond until the business case is delivered.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC031');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP04', 'Management of the change portfolio budget ', 'VM Change will have suitable arrangements in place to ensure that all Project expenditure is suitably authorised and monitored against estimates to avoid increased cost and the risk of not having budget to support agreed deliveries.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC032');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP05', 'Maintenance of a master portfolio ', 'A master Portfolio plan which identifies all known dependencies is maintained to support scheduling and mitigation standards across all projects.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC033');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP06', 'Following of gated QA standards', ',All Change Portfolio projects follow prescribed gated QA standards to mitigate against the risk of errors in methods and practices,  which could lead to a lack of control on deliverables.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC034');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP06', 'Standard change procedure definitions', 'All Change Portfolio projects follow an agreed methodology known as ?VM Change- Standard Procedures? which outlines the standard process and agreed outputs during the project lifecycle.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC035');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (4, 'CP07', 'Management of resources and capabilities ', ',VM Change will ensure that colleague skills and capabilities reflect the demand that exists to deliver the current and future portfolio by effective planning,  forecasting and flexing of capability to meet demand.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC036');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (5, 'CLP01', 'Competition law training', 'Colleagues are required to complete annual training on Competition Law awareness and compliance. This will be made available to all colleagues via the online VM RRV portal.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC037');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (5, 'CLP03', 'Documentation of meetings with competitors ', 'Contact with competitors must be made only in certain limited prescribed circumstances and meetings with competitors must be fully documented.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Supervisory', 'PLC038');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (6, 'CP05', 'Controlled regulator interaction', 'VM will deal with its regulators in an open and co-operative way and make all required notifications. VM will ensure that all contact with regulators is strictly controlled and only undertaken by authorised individuals.', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Operational', 'PLC039');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS01 ', 'Healthy and safety training ', ',VM must provide relevant health & safety training,  awareness and advice to colleagues', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC040');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS01 ', 'Logging of concerns ', 'VM must ensure that all accidents and health & safety concerns are logged and reported', NULL, 'Workforce management and physical infrastructure ', 'Detective', 'Supervisory', 'PLC041');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS02', 'Undertaking of risk assessments ', 'VM must undertake a health & safety risk assessment of all areas of significant risk.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC042');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS03', 'Appointment of executive in charge of health and safety ', 'Virgin Money must appoint an Executive Director who is accountable for ensuring the organisation complies with all relevant health & safety legislation.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC043');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS03', 'Use of a health and safety forum ', 'VM will establish a forum to monitor the health & safety performance of the organisation and establish appropriate health & safety standards and training', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC044');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS04', 'Appointment of a health and safety manager ', 'Virgin Money will appoint competent persons to provide advice on health and safety matters and ensure adequate resources for implementation of best practice', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC045');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (7, 'HS05', 'Third party health and safety standards ', 'Virgin Money will require partner organisations and contractors to operate health and safety standards which at least match its own.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC046');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (8, 'MP01', 'Changes to high materiality models ', 'Any development or change of a high materiality model must be signed off by the first and second line of defence before its implementation.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC047');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (8, 'MP03', 'Model documentation ', 'All models must be documented with enough detail to ensure they can be replicated by a person with the adequate set of skills and knowledge.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Operational', 'PLC048');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (8, 'MP05', 'High materiality model review', 'High materiality models must go through a first line desktop review once per year and a deep dive review once every two years unless regulatory requirements require more frequent reviews.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC050');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (8, 'MP05', 'Independent model validation ', 'IMV will determine which models will be desktop or deep dive reviewed during the design of the annual Independent Model Validation Plan with the aim to minimise Model Risk.', NULL, ',Model design, development and management and innovation', 'Preventative', 'Supervisory', 'PLC051');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP01', 'Due diligence at contract award ', ',Due Diligence must be undertaken in accordance with the Due Diligence Policy to confirm that the supplier has the capability,  capacity and authorisation required to perform that service. All material factors that would impact on the suppliers ability to provide the service must be considered.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC052');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP01', 'Legal and procurement review at contract award', 'Legal and Procurement will ensure that the contract includes appropriate terms for the arrangement.', NULL, 'Third party / strategic partner management', 'Preventative', 'Operational', 'PLC053');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP01', 'Strategic risk assessment of SYSC8 arrangements ', ',Where a new SYSC8 Critical or Important Outsource Arrangement is proposed (or where there are significant changes to an existing arrangement),  a Strategic Risk Assessment (including a Contract Risk Assessment) will be completed.', NULL, 'Third party / strategic partner management', 'Preventative', 'Operational', 'PLC054');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP02 ', 'Appointment of senior owner ', ',For each SYSC8 Critical or Important Outsourcing Arrangement,  a First Line Exec/Senior Owner must be appointed who will be accountable for the overall third party relationship.', NULL, 'Third party / strategic partner management', 'Preventative', 'Governance', 'PLC055');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP02 ', 'Appointment of Supplier relationship manager ', ',For each SYSC8 Critical or Important Outsourcing Arrangement,  a named Supplier Relationship Manager (SRM) with the appropriate expertise and authority must be appointed.', NULL, 'Third party / strategic partner management', 'Preventative', 'Governance', 'PLC056');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP02 ', 'VM 3rd party supervision review ', 'Exec/Senior Owners must review at least annually the VM arrangements for supervision of the third party and ensure that they are fit for purpose.', NULL, 'Third party / strategic partner management', 'Preventative', 'Supervisory', 'PLC057');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP04', 'Completion of Full annual capability review ', 'For each SYSC8 Critical or Important Outsourcing Arrangements,  SRM?s and Exec/Senior Owners must complete a ?Full? Annual Capability Review with the third party,  normally including a site-visit ,  to assess their on-going technical,  commercial and legal/regulatory capacity and compliance and confirm their ability to perform the service as required by VM.', NULL, 'Third party / strategic partner management', 'Preventative', 'Operational', 'PLC058');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP05', 'Regular review of third party BCM ', 'SRM and Exec/Senior Owner will: Ensure the satisfactory completion and review of a Supplier Information Security Assessment (SISA) to confirm the suitability of third party arrangements to protect confidential information (annually or as otherwise agreed with Group Security).', NULL, 'Third party / strategic partner management', 'Preventative', 'Supervisory', 'PLC059');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP05', 'Regular review of Exit plans ', ',SRM and Exec/Senior Owner will: Develop,  maintain and regularly review a suitable Exit Plan and a suitable Contingency Plan.', NULL, 'Third party / strategic partner management', 'Preventative', 'Supervisory', 'PLC060');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (9, 'OP05', 'Updating the contract ', ',SRM and Exec/Senior Owner will,  in conjunction with Legal and Procurement,  maintain and update the contract to ensure that it include all appropriate terms and provision.', NULL, 'Third party / strategic partner management', 'Preventative', 'Supervisory', 'PLC061');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR01', 'Conduct Governanceframework ', 'An appropriate Governanceframework must be in place in order to ensure the appropriate oversight and visibility of Conduct Risk and TCF issues is achieved.', NULL, 'Proposition design and development ', 'Preventative', 'Governance', 'PLC062');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR01', 'Line 1 TCF assessment ', 'A Line 1 TCF assessment must be completed as part of every Change project', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC063');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR02', 'Line 1 Conduct risk procedures', ',Line 1 must complete a Conduct Risk assessment as part of the approval process for all new products. They must define the proposed target market and intended customer outcomes for each new product proposal,  evidence how the proposal meets the needs of its target market and devise an appropriate communications strategy. They must also complete a post implementation review of new products in line with New Product Approval guidelines. Finally Line 1 must perform regular (at least annual) front and back book reviews of VM?s product range to assess whether products continue to be suitable for customers and offer value for money.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC064');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR02', 'Line 2 conduct risk procedures', 'Line 2 Financial promotions team must review and approve promotional materials which support the distribution strategy. Furthermore all new product proposals must be subject to a Line 2 Conduct Risk Assessment which forms part of the overall Risk Assessment considered by the Product and Pricing Committee (PPC).', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC065');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR03', 'Line 1 fees / charges / contractual terms procedures ', ',New fees and charges must be assessed for reasonableness by Line 1 as part of the approval process for all new products. Line 1 must conduct regular reviews of VM?s fees and charges,  with the scope of the review to ensure the fairness of both existing fees and any new fees that are proposed.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC066');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR03', 'Line 2 fees / charges / contractual terms procedures ', ',Any new terms and conditions that are proposed must be assessed for their fairness by VM?s Legal function and must be subject to Line 2 oversight by Conduct Risk. Line 2 Conduct Risk function must provide oversight of the review of fees and charges and provide guidance and challenge as appropriate. Line 2 Conduct Risk function must consider the fairness,  transparency and communication of fees,  charges and contractual terms and conditions as part of its review of new products.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC067');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR03', 'Record of disputes ', 'VM Legal shall maintain a register of notified and commenced disputes and litigation and diarise key dates.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC144');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR03', 'Legal review of terms and conditions ', 'VM?s Legal function must perform periodic reviews of terms and conditions to ensure that they do not contain terms which are considered to be unfair to customers', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC068');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR05', 'Sales and quality checks requirements ', 'Sales Quality checks must be carried out in line with the requirements of the Training & Competence Scheme and or Quality Framework.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC069');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR05', 'Line 2 quality assurance ', ',Line 2 must perform regular,  independent quality assurance checks to ensure the robustness of Line 1?s framework for ensuring compliance with VM?s Credit Risk and Responsible Lending Policy.', NULL, 'Proposition design and development ', 'Preventative', 'Supervisory', 'PLC070');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR06', 'Reward and recognition schemes', 'VM?s reward and recognition schemes will not incentivise colleague behaviours that result in poor outcomes for customers.', NULL, 'Sales and marketing', 'Preventative', 'Operational', 'PLC071');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR06', 'Reward schemes approval ', ',All reward scheme proposals must be submitted to the Reward and Recognition Committee for review in order to ensure appropriate controls are in place over their design,  implementation and oversight. Corporate bonus schemes (beyond the authorisation level of the Reward and Recognition Committee) must be agreed by the Board?s Remuneration Committee.', NULL, 'Sales and marketing', 'Preventative', 'Governance', 'PLC072');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR08 ', 'Recording customer complaints ', ',All customer complaints must be handled fairly, with the outcome recorded correctly on VM?s systems.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC073');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR08 ', 'Quality checks of complaint handling ', ',Line 1 must complete regular quality checks of complaint handling in line with the requirements of the Quality Framework. The results of these checks,  together with details of any corrective actions,  must be reported on a monthly basis through VM?s Governanceframework.', NULL, 'Ongoing customer management ', 'Preventative', 'Supervisory', 'PLC074');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR09', 'Use of due diligence checks on partners ', ',Due diligence checks,  including consideration of appropriate consumer outcome related metrics,  must be carried out on partners who undertake customer related activities.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC075');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (10, 'CR09', 'Enforcement of supplier performance metrics ', 'Supplier Relationship Managers must ensure supplier performance metrics are in place and enforced and that supplier activity is subject to regular reporting and review by VM.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Supervisory', 'PLC076');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (11, 'WBP02', 'Whistleblowing paths ', ',A dedicated phone line and email address have been set up to allow colleagues to raise their concerns,  if they are not comfortable or able to do so with their line manager ', NULL, 'Workforce management and physical infrastructure ', 'Detective', 'Operational', 'PLC077');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (11, 'WBP03', 'Appointment of Internal Audit Director ', ',The Internal Audit Director has been delegated responsibility by the Whistle-blowers Champion to maintain this policy and the Operationalprocedures that put it into practice. Where necessary,  a full investigation may be carried out with the objective of establishing whether malpractice has occurred.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC078');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC01 ', 'Governanceframework of vulnerable customers ', 'An appropriate Governanceframework must be in place in order to ensure that appropriate oversight and visibility of vulnerable customer issues is achieved.', NULL, 'Ongoing customer management ', 'Preventative', 'Governance', 'PLC079');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC02', 'Appointment and training of vulnerable customer senior manager ', 'VM will appoint a senior manager with responsibility for ensuring vulnerable customers are treated in a sensitive and flexible way. They must be appropriately trained in order to ensure their ongoing ability to fulfil this responsibility. The Senior Manager holding this responsibility must hold appropriate authority to enable decisions and must be held accountable for their implementation.', NULL, 'Ongoing customer management ', 'Preventative', 'Governance', 'PLC080');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC03 ', 'Line 2 general guidance on vulnerable customers ', 'Line 2 Conduct Risk must prepare and maintain general guidance for colleagues covering the identification and treatment of vulnerable customers. This will include policy awareness material to be covered in the VM arrivals event for new employees.', NULL, 'Ongoing customer management ', 'Preventative', 'Governance', 'PLC081');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC03 ', 'Customer facing employees training ', ',Line 1 business areas must ensure that customer facing colleagues are sufficiently trained to identify and deal appropriately with vulnerable customers. Customer facing colleagues must be kept well informed and up to date regarding temporary delegation options,  such as Power of Attorney and Court of Protection orders,  and be able to communicate these processes consistently to customers.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC082');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC04 ', 'Identification,  recording and treatment of vulnerable customers ', 'Line 1 functions must establish processes and procedures to enable the identification,  recording and fair treatment of vulnerable customers,  including customers whose needs and circumstances change making them vulnerable. These will cover,  where appropriate,  arrangements for assessing how an identified vulnerability impacts on a customer?s ability to manage their relationship with VM and the treatments that are available to ensure they are treated fairly. The business must work towards limiting the number of times vulnerable customers have to advise VM of their circumstances.', NULL, 'Ongoing customer management ', 'Preventative', 'Supervisory', 'PLC083');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC05', 'Appropriate design for vulnerable customers', 'Line 1 must consider vulnerable customers as part of the design process for all new products. This will involve a review of the potential risks posed by the product for vulnerable customers and any proposed mitigates. Line 1 business areas must ensure that customer journeys are designed to treat customers in vulnerable circumstances in a sensitive and flexible way. Line 1 functions must consider the needs of vulnerable customers in the delivery of customer interactions and services. Line 1 business areas must establish appropriate strategies to address the needs of vulnerable customers. Line 1 will complete suitability and value reviews that include an assessment of the impact products and services have on vulnerable customers.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC084');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC05', 'Line 2 risk assessment of new product proposals ', 'All new product proposals must be subject to a Line 2 Conduct Risk Assessment (CRA) which forms part of the overall Risk Assessment considered by the Product Development Committee. The CRA will cover vulnerable customer risks associated with the product being proposed. The Conduct Risk Assessment completed as part of the Line 2 Strategic Risk Assessment (SRA) process for all Change projects must include a check to ensure that appropriate arrangements are in place for the treatment of vulnerable customers.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC085');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Reviewing of data retention process', ',Regular reviews should take place to identify when information has passed its specified retention period and if no longer required,  securely archive or delete it as required.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC165');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC05', 'Initial assessment of change projects in regards to vulnerable customers ', ',As part of every Change project an initial assessment must be carried out to establish whether the change has any implications for vulnerable customers. If it does,  an assessment of the needs of the vulnerable customers potentially impacted must be completed and appropriate mitigates introduced for any issues that are identified.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC086');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC06', 'Link with charities for additional support ', ',VM will develop links with charities and other organisations,  where,  appropriate,  to obtain additional specialist guidance and support for vulnerable customers.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC087');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC07 ', 'Third party vulnerable customers policies ', 'Due diligence on proposed new partners must include an assessment of the firms? vulnerable customer policies and processes to ensure they are adequate. All new contracts with strategic partners and outsourcing providers must include appropriate requirements relating to the treatment of vulnerable customers', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC088');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC08', 'Development of processes around vulnerable customer treatment ', 'Line 1 business areas must develop MI and Governanceprocesses which enable the treatment of vulnerable customers to be monitored effectively.', NULL, 'Ongoing customer management ', 'Preventative', 'Governance', 'PLC090');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC08', 'Quality checks of Training and competence ', ',Quality checks,  carried out as part of VM?s Training and Competence Scheme and Quality Assurance Frameworks,  must include consideration of the identification and handling of vulnerable customers', NULL, 'Ongoing customer management ', 'Preventative', 'Supervisory', 'PLC091');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC09', 'Communications aimed toward vulnerable customers ', ',VM must make customer communications and collateral available in appropriate alternative formats such as Braille,  large font and audio and will make additional support available to vulnerable customers as appropriate. VM?s websites and partner hosted VM branded content must adhere to appropriate standards and guidelines relating to accessibility. VM must raise awareness of the support it offers to vulnerable customers with regard to communications and collateral.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC092');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC10', 'Receiving complaints from vulnerable customers ', 'Customer Relations must ensure that VM?s complaints process is readily accessible to vulnerable customers. Front line and Customer Relations complaint handling colleagues must be trained to deal with complaints from vulnerable customers sensitively and pragmatically.', NULL, 'Post sales support ', 'Preventative', 'Operational', 'PLC093');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC10', 'Reporting and remediating vulnerable customer complains ', 'Business areas must report vulnerable customer issues identified in the course of complaints root cause analysis to an appropriate Governanceforum. Corporate remediation projects must consider the needs of vulnerable customers in determining the appropriate course of redress.', NULL, 'Post sales support ', 'Preventative', 'Supervisory', 'PLC094');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (12, 'VC11', 'Compliance check', 'As part of every Change project an assessment of regulatory requirements relating to vulnerable customers must be completed and any actions which are necessary to achieve compliance must be implemented.', NULL, 'Ongoing customer management ', 'Preventative', 'Operational', 'PLC095');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP03 ', 'Assessment of tax team''s skills ', 'The Group Head of Tax must periodically conduct a Tax Team skills assessment of roles,  with focus on resource and knowledge of both the business and tax to ensure the Tax Teams skills can deliver accurate tax reporting.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC096');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP03 ', 'Maintenance of records for audit ', ',The tax team must maintain adequate records to demonstrate audit trail on decisions for HMRC,  External Audit,  Internal Audit and Risk.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC097');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP04 ', 'Minimising of tax risk ', ',The tax team will ensure that all material projects,  transactions and products are reviewed to ensure they minimise associated tax risk and/ or maximise tax opportunities.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC098');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP04 ', 'Review of records and available information ', ',The tax team will maintain all such records in a form readily available to the Tax Team and ensure that the records are kept regularly up to date with a six monthly review. The tax team will conduct periodic review of available information (to include statutory accounts,  company website etc) to ensure that tax information is current and up to-date', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC099');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP06', 'Reporting of key tax risk exposures ', ',The tax team will report tax risk exposures,  provisions and movements and identify associated impact on key financial statements to senior management,  with monthly updates to the Group Financial Controller.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Supervisory', 'PLC100');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP06', 'Tax risk oversight ', ',The tax team will provide tax risk oversight and sign-off on products,  transactions and statutory tax reporting.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Governance', 'PLC101');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP06', 'Review and reporting on likely financial and reputation impacts ', 'The Group Head of Tax will review all material tax judgements and report on likely financial and reputation impacts to the CFO on a periodic basis.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC102');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP06', 'Notes of procedures for each tax return ', 'The tax team will prepare notes of procedures and / or checklists for each tax return process as well as Senior Accounting Officer certification and review these at least annually.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC103');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (13, 'TP06', 'Updating of excel sheets ', ',The tax team will update any Excel spreadsheets forming part of the tax reporting and return process,  completing Change Control sheets and obtaining appropriate sign off as necessary.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC104');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (14, 'RR06 ', 'Brand reputation communication ', 'Robust external communication and brand reparation strategies (covering all stakeholders and both isolated and wider scale scenarios) will be maintained to mitigate reputation impacts of incidents', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Supervisory', 'PLC105');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (14, 'RR06 ', 'Review of protocols ', 'The strategic risk team within the Risk function will conduct periodic thematic review of incidents and brand reparation protocols to ensure reputation impact is appropriately considered and identify trends/heightened exposures', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC106');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP01 ', 'Appointment of Chief Risk officer ', 'VM will appoint a Chief Risk Officer who is the Executive responsible for oversight of all regulator engagement', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Governance', 'PLC107');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP01 ', 'Approval of contact with regulators and delegation of authority ', 'All contact with any regulator requires the prior approval of the Chief Risk Officer or such other person as may be nominated by him/her. Delegation of authority to deal with regulators on specific matters must be set out in the Delegated Authorities Manual which is approved by the Board on an annual basis. ', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Governance', 'PLC108');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP01', 'Correspondence procedure ', 'Any correspondence or contact received from a regulator must be forwarded immediately to the Chief Risk Officer and the Head of Compliance. All written correspondence with a regulator must be approved by the relevant VMET member and reviewed by the Chief Risk Officer or such other person as may be nominated by him/her.', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Supervisory', 'PLC109');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP03 ', 'Maintaining copies of correspondence with FCA and PRA ', 'The Risk Regulatory Relationship team must maintain a copy of all correspondence received from and sent to the FCA and PRA.', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Operational', 'PLC110');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP03 ', 'Logging correspondence with regulators', 'All communication with regulators must be logged and recorded appropriately by the Business/OperationalOwners of the relevant regulatory relationship.', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Operational', 'PLC111');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (15, 'CP03 ', 'Keeping of accurate minutes of meetings with FCA/PRA', ',In respect of all meetings with the FCA/PRA,  a member of the Risk Regulatory Relationship team must normally be present to take detailed and accurate minutes of the meeting. If  due to unforeseen circumstances,  this is not possible or appropriate a VM attendee of the meeting must prepare accurate minutes and provide these to the Risk Regulatory Relationship Team as soon as reasonably practicable.', NULL, 'Regulatory engagement and reporting ', 'Preventative', 'Operational', 'PLC112');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (16, 'PAP01', 'Creation of a product approval committee', 'An Executive-level Product Approval Committee will meet on a regular basis to approve all Product proposals with representation from all key stakeholder areas.', NULL, 'Proposition design and development ', 'Preventative', 'Governance', 'PLC113');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (16, 'PAP01', 'Manual for proposals to the committee', ',Product Teams will maintain a Manual(s) that sets out the detailed processes and organisational engagement,  that must be followed for creating and submitting proposals to the Committee.', NULL, 'Proposition design and development ', 'Preventative', 'Supervisory', 'PLC114');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (16, 'PAP01', 'Legal assessment of product proposals', ',Product proposals will be reviewed by all areas of the business. In addition they will be assessed by the Risk Function and the Legal Function and a written record will be produced. Legal will assess a product proposal against relevant legal requirements, particularly to ensure that proposals are consistent with agreements with counterparties,  relevant consumer law (including the law relating to fairness of terms) and the terms of the trademark licence with Virgin Enterprises Limited (?VEL?).', NULL, 'Proposition design and development ', 'Preventative', 'Supervisory', 'PLC115');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (16, 'PAP07', 'Design analyses', ',When considering new products or channels,  modelling and analysis must be undertaken including,  target customer market analysis,  projected financial business case,  competitor analysis,  stress testing,  consideration of the needs of vulnerable customers and the conclusions of any relevant post implementation reviews', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC116');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP01', 'Executive level pricing committee', 'An Executive-level Pricing Committee will meet on a regular basis to approve Pricing proposals with representation from all key stakeholder areas.', NULL, 'Proposition design and development ', 'Preventative', 'Governance', 'PLC117');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP01', 'Risk function''s assessment of pricing proposals ', 'Pricing proposals will be reviewed by all areas of the business. In addition they will be assessed by the Risk Function,  with a written record produced. In a limited set of circumstances this requirement may be waived or truncated. A record of these cases will be maintained by Change Risk.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC118');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP03', 'Pricing Governanceinline with manual', 'Our Governanceprocesses and supporting Manual and templates are designed to ensure there is a full consideration of Legal and Regulatory issues in every proposal. All Pricing proposals must be approved by the Pricing Committee and are subject to a risk assessment by the Risk Function which includes a review by the Conduct and Compliance Risk team.', NULL, 'Proposition design and development ', 'Preventative', 'Supervisory', 'PLC119');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP04', 'Pricing inline with manual ', ',Our Governanceprocesses and supporting Manual and templates are designed to ensure the communication requirements of all of our customers are considered in every proposal. In addition, all customer literature and communications must be signed off by the Risk Financial Promotions team.', NULL, 'Proposition design and development ', 'Preventative', 'Supervisory', 'PLC120');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP06', 'Financial impact analysis in pricing proposals ', ',All Pricing proposals must include financial impact analysis appropriate to the proposal,  to enable Pricing Committee to assess and decide whether the projected return is acceptable. Where minimum financial hurdles have been quantified,  setting out the return we expect from individual pricing proposals these must be clearly communicated to Pricing Committee. Pricing proposals must set out clearly how it compares to these minimum financial hurdles.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC121');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP07', 'Inputs for pricing models must be approved ', ',Inputs into decision-making from pricing models such as Funds Transfer Pricing,  Costs and Benefits,  Expected Losses,  Capital Allocation and Product Behavioural Assumptions will be from approved sources.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC122');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP08 ', 'Review of the pricing forecasts accuracy ', ',We will regularly review and measure the actual performance of our pricing decisions against the assumptions and estimates made at the time the pricing was approved on subjects like Volumes,  Profile and Risk Adjusted Return on Risk Adjusted Capital.', NULL, 'Proposition design and development ', 'Preventative', 'Operational', 'PLC123');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (17, 'PP09 ', 'Requirements for proposals outside agreed targets ', ',The Pricing Committee Terms of Reference will define the steps that need to be taken for the approval of proposals that are outside of agreed targets or guardrails. These steps must involve an escalation in terms of authority and could include the need to refer such proposals for final approval to the CRO, CFO,  CEO and in exceptional cases the Board.', NULL, 'Proposition design and development ', 'Preventative', 'Governance', 'PLC124');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS02', 'Responsibility for oversight of people policy ', 'ExCo is responsible for the oversight of the People Policy and all managers will be responsible for ensuring the effective implementation of the People Policy.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC125');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS02', 'Maintenance of clear lines of reporting ', ',Clear lines of responsibility,  accountability and reporting will be maintained across the business. Primary responsibility for the management of people risk rests with the Executive of each business area.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Supervisory', 'PLC126');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS03', 'Review of organisation structures ', 'Organisation structures and processes will be continually reviewed and developed to meet the evolving needs of the business and to mitigate the risk of over reliance on a single colleague or role and as an enabler to business effectiveness', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC127');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS03', 'Talent management and succession planning ', ',Talent management and succession planning will be overseen by HR with the Operationalprocesses embedded in the business and owned by line management. Our talent management and succession planning process will be used effectively to make optimum use of the colleague capability available to the business. Based on our strategic business plans,  forward planning will be undertaken to identify talent requirements to ensure that the right people with the right skills and experience are available at the right time', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC128');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS04', 'Monitoring of employment legislation ', 'Effective mechanisms will be maintained to enable proposed changes to employment legislation to be monitored on an ongoing basis to allow us to anticipate the impact of changes on the organisation and mitigate any negative effects.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Supervisory', 'PLC129');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS04', 'Records for roles where there are regulatory requirements ', 'Records will be maintained for all designated roles for which there is particular compliance or regulatory requirements and an appropriate infrastructure will be maintained to enable us to discharge our responsibilities in the management and reporting of these roles. These requirements apply to all regulatory Senior Manager and certified roles.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC130');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS04', 'Recognition of trade unions and meeting their standards', ',Trade Unions are recognised,  (as they are currently with Unite for some of our colleagues),  the formal colleague consultation mechanisms are designed and operated to enable us to meet the prescribed minimum standards,  discharge our responsibilities and maintain positive,  constructive relationships with all formally recognised colleague representative bodies.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC131');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS06', 'Employee training on TCF ', 'All colleagues will undertake appropriate training on TCF to ensure they understand their responsibilities in delivering customer fairness. Our colleague?s are the strategic differentiator in the way that they interact with our customers and support one another to bring TCF to life.', NULL, 'Post sales support ', 'Preventative', 'Operational', 'PLC132');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS07', 'Use of pre employment checks ', ',Pre-employment checks are carried out as appropriate for the role and where applicable,  regulatory clearance will be obtained. All pre-employment checks will comply with our legal obligations and,  as a minimum,  cover the following:- qualifications (relevant to the role) - experience current address- credit checks -Criminal Record checks- nationality (to establish the legal right to work)- references from previous employment', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC133');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS07', 'Use of standardised assessments ', ',Standard assessment procedures help to ensure a consistent,  transparent and fair selection process. We operate an effective and structured induction process to enable new colleagues to understand our business,  values,  culture,  expected behaviours and conduct at work.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC134');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS07', 'Retention of critical skills ', ',We will operate appropriate retention and recruitment mechanisms to retain critical skills within the business and to source externally the required skills and experience where required. Talent management processes,  resourcing strategies and succession plans will be regularly refreshed for business critical skill sets,  to minimise the risk of over reliance on a small number of individuals.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Supervisory', 'PLC135');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS08', 'Reward strategy ', ',In accordance with our Remuneration Policy,  an appropriate reward strategy,  will be developed,  maintained,  and integrated with our performance management process and aligned with our business objectives and people strategy. The strategy will take account of market conditions and will have the overriding objective of rewarding effective individual,  team and business performance in the medium to long term through an appropriate mix of financial and non financial reward components in a risk-adjusted approach', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Supervisory', 'PLC136');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS08', 'Use of job evaluation methodologies ', ',For new roles,  the HR Reward team will ensure the consistent use of robust job evaluation methodologies,  including external market benchmarking.', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC137');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS10', 'Identification of people risk from third parties ', ',In situations where we propose to enter into an outsource arrangement with a third party company,  a people focused risk assessment must be undertaken prior to the finalisation of commercial contracts. The scope of the risk assessment must include,  but not be limited to,  the potential for reputational risk exposure for VM as a consequence of HR policy,  standards and practice in other organisations falling short of the minimum standards set out in this Policy.', NULL, 'Third party / strategic partner management ', 'Preventative', 'Operational', 'PLC138');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS11', 'Use of engagement surveys ', ',Colleague engagement surveys,  and other forms of colleague feedback,  will be used to assess progress and the current state of engagement and commitment', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC139');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (18, 'PS13', 'Appointment of an executive responsible for ', 'VM will appoint an Executive with responsibility for establishing and maintaining a framework and operating procedures to ensure VM complies with the requirements of the Senior Managers Certification Regime (SMCR)', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Governance', 'PLC140');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR01', 'Maintenance of legal horizon ', ',VM Legal will maintain a horizon view of legislative change,  assess its impact and where appropriate in conjunction with Risk (having regard to the policies they own ), track the implementation and readiness of VM for such change. VM Legal will assess the impact and materiality of the legislative change which it considers most relevant to monitor and will use external advisers and resource.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC141');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR02', 'Approval from legal on customer facing agreements ', 'All customer facing agreements or product terms require approval from Legal prior to the launch of a new product or variation of an existing product.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC142');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR02', 'Approval from legal on marketing materials ', 'All material or significant marketing materials relating to products require approval from Legal unless Legal determine otherwise.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC143');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR04', 'Reporting of suspected breaches ', 'All VM colleagues shall report suspected breaches or infringements etc in an accurate and timely manner. It is appropriate for VM colleagues to report or escalate an issue to their line manager (or a superior manger) in the first instance to assess whether there is a suspected breach which should be advised to the General Counsel', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Detective', 'Operational', 'PLC145');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR04', 'Management of disputes ', ',Any disagreement,  question or misunderstanding as to the effect or implications of any legal advice should be raised with the advising lawyer in the first instance for resolution or clarification. Where any disagreement etc remains,  the relevant Executive member shall raise the matter with the General Counsel for resolution.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC146');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (19, 'LR06', 'Requirements for contact with external law firms', 'All instructions and contact with external law firms must be conducted through Legal unless there is prior written agreement of the General Counsel.', NULL, 'Business performance / financial management (incl. legal and tax) ', 'Preventative', 'Operational', 'PLC147');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Conditions of collecting personal information ', ',Business units must have legitimate grounds for collecting and using the information and be able to satisfy at least one schedule two conditions and,  in relation to sensitive personal information,  an additional schedule three condition', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC148');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Informing customers who will be in control of their data ', ',When individuals are asked to provide information,  they must be told,  at a minimum,  who will be in control of their information,  what it will be used for and who it will be shared with. This information must be provided before their information is processed and accessible at a later date.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC149');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Retention of privacy statements ', 'Business units must keep a record of privacy notices and online privacy statements for at least as long as the information to which they relate is retained.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC150');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Approval from Financial Crime and Privacy to rely on exemptions ', 'Business units must seek prior approval from Financial Crime & Privacy Risk before relying on any of the exemption allowed under the Act. Business units must have documented procedures relating to any processing taking place under an exemption (for example releasing information for the prevention or detection of crime).', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC151');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Processing new categories of information ', 'Business units must consult Financial Crime & Privacy Risk if they intend to process new categories of information or use information for new purpose/s before the information is collected/processed.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC152');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Consent to use information in a new way ', 'Individuals must provide freely given and informed consent to any new use of their information.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC153');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Risk assessment around new categories of information ', 'Prior to processing any new categories of information a risk assessment must be carried out to assess the level of risk to the associated individuals', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC154');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Measures to protect information ', 'Business units must take appropriate organisation and technical measures to protect information held in Virgin Money or by third party information systems and associated media or storage locations. Responsibilities and procedures for the secure management and operation of all information processing facilities must be established. Segregation of duties will be included to minimise the risk of misuse or malicious use.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC155');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Controlled access to information ', ',Authorisation to information and IT systems must be effectively controlled to prevent,  detect,  and minimise the effects of unintended or malicious access to assets.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC156');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Reporting of security breaches ', ',All security breaches,  whether actual or suspected must be reported to Group Security; for the breach to be promptly investigated and a suitable response initiated. Financial Crime & Privacy Risk and Information Security Risk will provide oversight appropriate to the nature of the incident.', NULL, 'Technological and data infrastructure management', 'Detective', 'Supervisory', 'PLC157');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP01 ', 'Reporting of data protection breaches ', ',Data protection breaches whether there has been a security breach or not,  must be recorded and reported in aggregate on a monthly basis to Financial Crime and Privacy Risk,  along with a root cause analysis. Data protection breaches involving multiple customers,  whether as the result of a security breach or not,  must be reported immediately to Financial Crime & Privacy Risk.', NULL, 'Technological and data infrastructure management', 'Detective', 'Supervisory', 'PLC158');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Maintenance of a personal information management framework ', ',Virgin Money will maintain a personal information management framework to ensure its quality and integrity through its lifecycle (collection,  organising,  use,  control,  dissemination,  retention and disposal),  as well as confidentiality and availability.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC159');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Collection of necessary information ', 'Business units must identify the minimum amount of relevant information required to fulfil the purpose it is being processed and not collect excessive information', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC160');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Documentation of information flows ', 'Business units must document the information flows throughout their procedures.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC161');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Allocation of information of information asset owners ', 'Business units must allocate Information Asset Owners (named individuals) responsible for the protection and use of specific information.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC162');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Correction of inaccurate information ', 'Business units must have documented procedures for correcting any inaccurate information. Where inaccurate information is identified there must be procedures in place to notify any third party recipients', NULL, 'Technological and data infrastructure management', 'Mitigative', 'Supervisory', 'PLC163');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP02', 'Retention period of data ', ',All information must have a specific retention period based on organisational,  legal or regulatory requirements. This should be in accordance with Group Security?s Record Retention Standard and reflected in Group Security?s Record Retention Schedule.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC164');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP03', 'Customer''s rights to access information hold about them', ',Right to access the information held about them (data subject access request):Business units must have procedures in place to identify data subject access requests including:- Validating them;- Identifying all the information individuals are entitled to;- Advising the individual whether any personal data is being processed;- Providing a copy of any information with a description of it,  the reasons it is being processed, whether it is shared with any third parties and its source (where this is available)', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC166');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP05', 'Investigation of suspected criminal payments ', 'Payments suspected to be the proceeds of crime must be referred and investigated in line with VM?s Financial Crime Policy and regulatory obligations.', NULL, 'Payments ', 'Detective', 'Operational', 'PLC204');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP06', 'Recovery requirements for individual payment systems ', 'The Payment System?s owner must define the recovery requirements for individual payment systems.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC205');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP03', 'Requirements around information being used for marketing purposes', ',1) Where information is to be used for marketing purposes there must be a permission based approach. In particular permission wording must identify who could be contacting them and how (e.g. email,  SMS,  telephone).2) Individuals must be given the opportunity to object to marketing contact when their details are first collected and in relation to electronic marketing,  given the opportunity to opt-out (or unsubscribe) of every future marketing contact.3) A record of individuals? marketing preferences should be maintained detailing when and what they have agreed or objected to (e.g. mail, telephone,  email contact).Customer communications must be reviewed for marketing content and marketing opt-out customers excluded where necessary.4) Procedures must be in place to record changes in customers marketing preferences.5) Where an individual asks Virgin Money not to use their information for marketing purposes it must stop electronic marketing within 28 days and postal marketing within 2 months.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC167');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP03', 'Requirements around automated decisions ', ',1) Business units must not make an automated decision where individual has provided written instruction not to.2) Where no notice has been received,  individuals must be informed an automated decision has been made about them as soon as practical afterwards.3) Business units must have procedures in place to review/reconsider automated decisions manually where requested (e.g. a referral or appeals process).', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC168');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP04', 'Management of data under third party control ', ',Virgin Money will ensure where information is transferred to or processed on its behalf by third parties,  such processing is managed in line with this policy,  personal information is adequately protected and processing is undertaken only for legitimate Operationalor commercial reasons.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC169');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP04', 'Sharing information with 3rd parties ', 'There must be legitimate grounds for sharing information with third parties and only the minimum amount of information must be shared', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC170');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP04', 'Use of contracts with third party information recipients ', ',Written agreements/contracts must be in place with third party recipients of information,  which must describe the purposes the information may be used for,  any limitations to its use and provide a commitment that the information will be processed in line with the Act and in particular that the information will be kept safe', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC171');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP05', 'Approval from Financial Crime and Privacy risk to transfer data outside of EEA ', 'No information will be transferred outside of the EEA without prior approval from Financial Crime & Privacy Risk.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC172');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP05', 'Risk assessment of proposed transfers outside of EEA ', 'A risk assessment of any proposed transfer outside the EEA must be carried out by Group Security (and reviewed by Financial Crime & Privacy Risk) to assess the adequacy of the safeguards in place to protect the information and the rights of the data subjects', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC173');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP05', 'Ex-EEA data transfer contracts', ',Transfers outside the EEA must be under contract,  using the European Commission approved Model Contract Clauses or Binding Corporate Rules.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC174');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP05', 'US Safe harbour agreement ', 'Any recipients of information in the United States must be signed up to the US ''Safe Harbour'' agreement (a set of rules similar to those found in the UK''s data protection law).', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC175');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP06', 'Data protect and information security training', 'All colleagues must receive regular data protection and information security training appropriate to their role. At a minimum they must complete computer based training within four weeks of joining the company and annually thereafter.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC176');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP06', 'Identification and execution of more detailed training ', 'Business unit management must identify staff who may required more detailed training (for example colleagues handling sensitive information or carrying out specialised tasks such as data subject access requests) and ensure these individuals undergo additional training on a regular basis.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC177');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP06', 'Senior management evidencing', ',Senior management must be able to demonstrate,  with documentary evidence,  the completion of or participation in,  data protection and information security awareness training for all staff in their reporting line.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC178');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP07', 'Monitoring the effectiveness of the data protection controls ', 'Financial Crime & Privacy Risk will monitor the adequacy and effectiveness of data protection and privacy systems and controls through a programme of assurance activities (second line assurance)', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC179');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP07', 'Oversight of all business units by financial crime and privacy risk ', ',Financial Crime & Privacy Risk will,  through a combination of relationship management, review of management MI and proactive requests,  perform oversight of all relevant business units. Such oversight activity,  along with internal and external assurance activities,  inform second line assurance activities.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC180');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP08 ', 'Appointment of data protection officer ', 'Virgin Money will nominate a Data Protection Officer (the ?DPO?) to provide a central point of contact for the Information Commissioner?s Office and responsible for co-ordinating management and development of Virgin Money?s data protection and privacy framework.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC181');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP08 ', 'Establishment of a data protection and privacy committee', ',The Head of Financial Crime & Privacy Risk will establish a committee to co-ordinate the implementation and maintenance of these standards across Virgin Money. The committee will be comprised of management of a suitable level of seniority to make decisions and recommendations to the OperationalRisk,  Compliance & Conduct Risk Committee and will include representation across all primary functions', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC182');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP08 ', 'Appointment of a responsible senior manager by each VMET area', ',Each VMET area will assign a senior manager with overall responsibility for compliance with this policy and who will regularly report on the effectiveness of controls on a frequency not less than monthly. As a minimum,  this individual will be a direct report of a member of the VMLT and their responsibilities,  in respect of data protection and privacy risk management,  will be included in their role specification.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC183');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP08 ', 'Annual data protection and privacy risk assessments ', ',At least annually,  or as required through changes to risk profile,  new products or relevant external environmental changes,  business units must perform a data protection and privacy risk assessment taking into account the category of information processed and any risks to associated individuals. Risk assessments must be fully documented and applicable mitigating controls identified and implemented. Controls should be designed to be proportionate to the risk. All risk assessments should take into consideration any outsourcing of data protection and privacy processes or controls to external service providers', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC184');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP08 ', 'Quarterly audit of cookies ', 'Digital will carry out a quarterly audit of cookies on the Virgin Money websites to ensure they are accurately reflected in the Virgin Money cookie policy.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC185');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP09', 'All capabilities embody the principles of privacy by design ', ',Virgin Money will ensure that all products,  systems and processes,  including the use of new technology and digital applications,  are developed and implemented in such a way as to ensure the key principles of ?privacy by design? are adhered to.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Supervisory', 'PLC186');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP09', 'Data protection in implementing new systems', ',Business units must ensure that privacy and data protection are considered throughout the development and implementation of any new IT system,  business process or change to use or extent of personal data captured.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC187');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP09', 'Informing customers of cookies ', 'Individuals visiting Virgin Money?s internet sites must be informed of the use of cookies and suitable consent obtained.', NULL, 'Technological and data infrastructure management', 'Preventative', 'Operational', 'PLC188');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (20, 'DP09', 'Approval of changes to cookie policy ', 'Proposed changes to the use of cookies (including new cookies) must be pre-approved by Financial Crime & Privacy Risk and the Digital Director and changes reflected in the Virgin Money cookie policy', NULL, 'Technological and data infrastructure management', 'Preventative', 'Governance', 'PLC189');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', 'Secondary checks for FPS and CHAPS ', 'All Faster Payments (?FPS?) and CHAPS must have an input and secondary check as standard for all amounts due to the fact that these payments cannot be stopped or recalled', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC190');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', 'Payments of over a set amount ', 'All manually input payments (of any type) must be authorised over a set amount and appropriate controls introduced to mitigate against abuse. Such controls may include (but are not limited to)exception reporting and review of audit logs.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC191');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', ',Checks for payments of 100,000', ',All systems capable of paying away retail funds outside the group must have a system or manually enforced check for all transactions over 100,000,  prior to authorisation.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC192');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', 'Segregation of duties', ',The roles of inputter,  checker and authoriser of these payments must not be performed by the same person.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC193');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', 'Documentation and approval of authorisation limits ', ',Authorisation and approval limits for all payment systems and channels must be documented in the Delegated Authorities Manual,  approved by a VMET member and accessible to all delegated individuals with approved access to the systems/channels.', NULL, 'Payments ', 'Preventative', 'Supervisory', 'PLC194');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP01 ', 'JML process ', ',A Joiners,  Movers and Leavers (?JML?) process must be in place in all areas processing payments to ensure records are kept up to date when colleagues change roles within Virgin Money.', NULL, 'Payments ', 'Preventative', 'Supervisory', 'PLC195');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP02', 'Strategic payments director owns retail payments systems ', 'All payment systems processing retail payments will be owned by the Strategic Payments Director. Any changes to these systems must first be approved by the Strategic Payments Director.', NULL, 'Payments ', 'Preventative', 'Governance', 'PLC196');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP02', 'Ownership of each payment system ', 'All other payments systems outside the retail remit e.g. Wholesale payment must have a designated owner as above.', NULL, 'Payments ', 'Preventative', 'Governance', 'PLC197');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP02', 'Maintenance of central log of payment systems ', ',A central log of all payment systems and owners must be maintained by the Strategic Payments Director,  and must be reviewed on a regular (at least annual) basis.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC198');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP03', 'Physical security of payment areas must align with VM''s Information Security Policy and Physical Security Policy ', ',The physical security of Payment Processing Areas must comply with VM?s Information Security Policy and Physical Security Policy.1) All colleagues or contractors with access to payment processing areas must be authorised through appropriate sanctioned access passes. All unauthorised colleagues or contractors must be accompanied by an authorised individual at all times.
2) Payment areas must be locked down outside core processing hours.3) All stationary and physical assets used for payments (i.e. cheque books and cashier stamps) must be maintained in a secure manner during working hours and secured with access only to authorised individuals out of hours. VM?s Clear Desk Standard must be adhered to at all times.
', NULL, 'Workforce management and physical infrastructure ', 'Preventative', 'Operational', 'PLC199');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP03', 'Access to payment systems ', ',Access to payments systems should be granted on the principle of ?least privilege?,  where staff only have access to systems and functions vital to their role.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC200');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP04', 'Incoming payments requirements ', ',1) Referrals or repairs of incoming payments must be processed in line with scheme rules and internal service levels.2) Payment amounts or the beneficiary?s name must not be changed from the original message.
3) Funds must be applied or returned to the remitting bank in line with Payment Service Regulation (?PSR?) timelines and internal service levels.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC201');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP04', 'Outgoing payments requirements ', ',1) Mandated payments (Standing Order/Direct Debit) and cheque payments referred where the customer has insufficient funds must adhere to internal pay/no pay procedures,  and decisions must not be made until after the 2pm industry timeline on the mandated date.2) Where internally processed payments are referred for two-factor authentication there must not be an option to amend the payment,  only accept or cancel.3) Where an online customer initiated payment is referred for review there must not be an option to amend the payment,  only accept or cancel.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC202');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP05', 'Screening of payments to prevent crime ', ',All payments must be screened to identify and prevent financial crime. Where possible,  this screening must be conducted using an automated system solution which utilises repeatable rules and logic etc. Where an automated solution is not possible,  a documented manual processes must be in place for the screening of payments e.g. exception reports for high risk / high value transactions.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC203');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP06', 'Annual testing of failover to secondary site ', ',All payment systems must be tested on an annual basis for failover to the secondary site,  including testing of live payments from this site. All system changes made at the primary site must be replicated and tested at a suitable Disaster Recovery location.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC206');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP06', 'Third party compliance with VMs information security policy ', 'Any Third Parties involved in the processing of payments must comply within VM?s Information Security policy which includes an annual Supplier Information Security Assessment (?SISA?).', NULL, ' third party / strategic partner management ', 'Preventative', 'Operational', 'PLC207');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP06', 'Maintenance for BC documentation ', ',Operationalareas must maintain approved Business Continuity documentation,  including specific Recovery Time Objective (?RTO?) plans for all key payment processes', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC208');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP07 ', 'Reporting of breaches to regulatory payment timescales ', ',Breaches of regulatory payment timescales must be reported to VM Risk. Breaches of internal Service Level Agreements (SLAs) should be reported via internal management and,  where applicable,  RCSA controls.', NULL, 'Payments ', 'Detective', 'Operational', 'PLC209');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP08 ', 'Daily reconciliation of transactions ', ',A daily reconciliation of transactions must be undertaken for all core payments types,  including FPS, CHAPS,  BACS,  Cheques and card payments. All reconciliations must be documented and must be signed by the preparer and the checker', NULL, 'Payments ', 'Detective', 'Operational', 'PLC210');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP08 ', 'Reporting of reconciliation exceptions ', 'Any reconciliation exceptions must be reported to the relevant department and escalated if not resolved within set SLA?s.', NULL, 'Payments ', 'Detective', 'Supervisory', 'PLC211');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP08 ', 'Procedures for all levels of reconciliation ', 'Documented procedures must exist for all levels of reconciliation performed.', NULL, 'Payments ', 'Preventative', 'Supervisory', 'PLC212');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP11 ', 'Authorisation and approval limits ', 'All payment authorisation and approval limits must be documented and assigned/delegated to relevant individuals involved in payments activity by line management. Line management must review payment authorisation and approval limits on at least an annual basis', NULL, 'Payments ', 'Preventative', 'Supervisory', 'PLC213');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP11 ', 'Sanctioning of individual payment limits ', 'Senior Management/Line Management may delegate to a specific nominee the sanctioning of individual colleague limits but only within their own delegated limit. A JML process must be in place to ensure records are kept up to date when colleagues change their roles.', NULL, 'Payments ', 'Preventative', 'Governance', 'PLC214');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP12 ', 'Checks to ensure sufficient funds available ', 'All retail payments must be checked to ensure that the customer has sufficient cleared funds available which can include an approved borrowing limit. This can be via a system or a controlled manual check depending on the payment system in use.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC215');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP12 ', 'Direct debit processing', ',Where debit payments are processed from non real time accounts,  an indicator must be placed on the account to indicate a withdrawal has taken place that day (to prevent duplicate debits). This can be via a system or manual update depending on the payment system in use.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC216');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP12 ', 'Limit check', ',For applicable accounts,  all payments in excess of a specific limit received by post or in person must be subject to a signature check against the customer mandate. Delegated Authority lists and procedures must exist and be adhered to for such circumstances.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC217');
INSERT INTO public.controls_tbl (policy_ref_id, control_minimum_standard_id, control_name, control_description, fmode_ref_id, control_releveant_process, control_purpose, control_type, control_ref_id) VALUES (21, 'PRP12 ', 'Authentication of payments above agreed limit ', 'Payment requests received above a formally agreed limit require further authentication to confirm the genuineness of the request and an escalating level of authorisation depending on the transaction amount. Delegated Authority lists and procedures must be maintained and reviewed on a regular basis. A JML process must also be in place to ensure records are kept up to date when colleagues change their roles.', NULL, 'Payments ', 'Preventative', 'Operational', 'PLC218');


--
-- Data for Name: finmat_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.finmat_ref_tbl (finmat_ref_id, finmat_level, finmat_label, finmat_ext_impact_description, finmat_reg_impact_description, finmat_brand, finmat_upper_threshold, finmat_lower_threshold) VALUES (1, 'Level1', 'Low', 'Serious systemic failure of key service where customers suffer significant financial loss and/or major inconvenience', 'Serious systemic breaches. Censure, restrictions on trade, capital or other action by regulator likely', 'Concerted, widespread or recurrent hostile coverage in the national and industry media', 5000.00, 50000.00);
INSERT INTO public.finmat_ref_tbl (finmat_ref_id, finmat_level, finmat_label, finmat_ext_impact_description, finmat_reg_impact_description, finmat_brand, finmat_upper_threshold, finmat_lower_threshold) VALUES (2, 'Level2', 'Moderate', 'Customers suffer material financial loss and/or major inconvenience', 'Systemic breach of a major requirement. Formal regulatory investigation possible', 'Consistent critical or negative coverage in national or industry media', 50000.00, 99000.00);
INSERT INTO public.finmat_ref_tbl (finmat_ref_id, finmat_level, finmat_label, finmat_ext_impact_description, finmat_reg_impact_description, finmat_brand, finmat_upper_threshold, finmat_lower_threshold) VALUES (3, 'Level3', 'Medium', 'Large number of customers suffer inconvenience but no material financial loss or detriment', 'Major breach of a single requirement. Remedial action/intensive regulator oversight possible', 'Extended unfavourable coverage in national or industry media', 100000.00, 499000.00);
INSERT INTO public.finmat_ref_tbl (finmat_ref_id, finmat_level, finmat_label, finmat_ext_impact_description, finmat_reg_impact_description, finmat_brand, finmat_upper_threshold, finmat_lower_threshold) VALUES (4, 'Level4', 'High', 'Customers suffer material financial loss and/or major inconvenience', 'Systemic breach of a major requirement. Formal regulatory investigation possible', 'Consistent critical or negative coverage in national or industry media', 500000.00, 999000.00);
INSERT INTO public.finmat_ref_tbl (finmat_ref_id, finmat_level, finmat_label, finmat_ext_impact_description, finmat_reg_impact_description, finmat_brand, finmat_upper_threshold, finmat_lower_threshold) VALUES (5, 'Level5', 'Critical', 'Serious systemic failure of key service where customers suffer significant financial loss and/or major inconvenience', 'Serious systemic breaches. Censure, restrictions on trade, capital or other action by regulator likely', 'Concerted, widespread or recurrent hostile coverage in the national and industry media', 100000000.00, 1000000.00);


--
-- Data for Name: fmech_ref_det_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.fmech_ref_det_tbl (fmech_ref_det_id, fmech_ref_det_description, fmech_ref_det_level) VALUES (1, NULL, 'Level1');
INSERT INTO public.fmech_ref_det_tbl (fmech_ref_det_id, fmech_ref_det_description, fmech_ref_det_level) VALUES (2, NULL, 'Level2');
INSERT INTO public.fmech_ref_det_tbl (fmech_ref_det_id, fmech_ref_det_description, fmech_ref_det_level) VALUES (3, NULL, 'Level3');
INSERT INTO public.fmech_ref_det_tbl (fmech_ref_det_id, fmech_ref_det_description, fmech_ref_det_level) VALUES (4, NULL, 'Level4');
INSERT INTO public.fmech_ref_det_tbl (fmech_ref_det_id, fmech_ref_det_description, fmech_ref_det_level) VALUES (5, NULL, 'Level5');


--
-- Data for Name: fmech_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.fmech_ref_tbl (fmech_ref_id, fmech_description, fmech_type) VALUES (1, NULL, 'People');
INSERT INTO public.fmech_ref_tbl (fmech_ref_id, fmech_description, fmech_type) VALUES (2, NULL, 'Process');
INSERT INTO public.fmech_ref_tbl (fmech_ref_id, fmech_description, fmech_type) VALUES (3, NULL, 'Systems');


--
-- Data for Name: fmode_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (1, 'VMDB Level 1', 'VMDB Level 2', 'VMDB Level 3', 'Description');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (2, 'Systems', 'Hardware issues', 'Computing / storage hardware failure', 'Unavailability of computing or storage hardware (e.g. servers) due to capacity constraints / damage / inadequate maintenance, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (3, 'Systems', 'Hardware issues', 'Network breakdown', 'Breakdown of connectivity between bank systems / workstations due to capacity constraints / damage / inadequate maintenance, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (4, 'Systems', 'Hardware issues', 'Utility / telecommunications failures', 'Outages in external electricity / telecommunications networks, leading to unavailability of system hardware');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (5, 'Systems', 'Software issues', 'Design issues', 'Issues with the design or usability of existing systems e.g. due to inadequate requirements souricng, leading to an unstable / incompatible / not fit-for-purpose design');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (6, 'Systems', 'Software issues', 'Proprietary software unavailability', 'Unavailability of proprietary software tools / applications / interfaces');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (7, 'Systems', 'Software issues', 'External application / service unavailability', 'Unavailability of third party software tools / applications / interfaces');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (8, 'Systems', 'Software issues', 'Proprietary software implementation issues', 'Errors / bugs in proprietary application execution / implementation');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (9, 'Systems', 'Software issues', 'External application implementation issues', 'Errors / bugs in external application / service execution / implementation');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (10, 'Systems', 'Software issues', 'Proprietary interfacing issues', 'Proprietary software interfacing (i.e. incompatibility with other systems) / version management (e.g. inadequate backups of stable software versions) issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (11, 'Systems', 'Software issues', 'External interfacing issues', 'External software interfacing (i.e. incompatibility with other systems) / version management (e.g. inadequate backups of stable software versions) or servicing (i.e. lack of adequate support / documentation) issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (12, 'Business Continuity Management (BCM)', 'Secondary system failure(s)', 'Hardware / connectivity failures', 'Failure of secondary system(s) to come online after primary system fails due to hardware / connectivity issues (similar to those that could affect primary systems)');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (13, 'Business Continuity Management (BCM)', 'Secondary system failure(s)', 'Software failures', 'Failure of secondary system(s) to come online after primary system fails due to software issues (similar to those that could affect primary systems)');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (14, 'Business Continuity Management (BCM)', 'BCM control framework failure', 'Framework effectiveness failure', 'Lack of an effective control framework around BCM, leading to regulatory impact / action');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (15, 'Business Continuity Management (BCM)', 'BCM control framework failure', 'Framework evidence failure', 'Lack of sufficient evidence of the effectiveness of the BCM control framework, leading to regulatory impact / action');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (16, 'Data and information management', 'Design', 'Requirements issues', 'Inadequate data requirements sourcing during system / process design activities, leading to data layers not being fit for purpose / incomplete');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (17, 'Data and information management', 'Design', 'Data dictionary issues', 'Inadequate / un-enforced data dictionary / semantic layer, leading to redundancies / inaccuracies in database and system design across the organisation');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (18, 'Data and information management', 'Availability', 'Customer data', 'Customer data access / availability / linkage (i.e. interconnection between all related / linked databases) failures');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (19, 'Data and information management', 'Availability', 'Employee data', 'Employee data access / availability / linkage (i.e. interconnection between all related / linked databases) failures');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (20, 'Data and information management', 'Availability', 'Bank data', 'Bank data access / availability / linkage (i.e. interconnection between all related / linked databases) failures');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (21, 'Data and information management', 'Synchronisation', 'Customer data', 'Customer data synchronisation (i.e. differences in data values across parts of the system architecture) risks / issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (22, 'Data and information management', 'Synchronisation', 'Employee data', 'Employee data synchronisation risks / issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (23, 'Data and information management', 'Synchronisation', 'Bank data', 'Bank data synchronisation risks / issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (24, 'Data and information management', 'Completeness / integrity', 'Customer data', 'Risks related to the deletion / corruption / incompleteness of customer data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (25, 'Data and information management', 'Completeness / integrity', 'Employee data', 'Risks related to the deletion / corruption / incompleteness of employee data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (26, 'Data and information management', 'Completeness / integrity', 'Bank data', 'Risks related to the deletion / corruption / incompleteness of bank data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (27, 'Data and information management', 'Quality', 'Customer data', 'Customer data unsuitability / incompatibility issues e.g. due to data quality guidelines not being followed / enforced');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (28, 'Data and information management', 'Quality', 'Employee data', 'Employee data unsuitability / incompatibility issues e.g. due to data quality guidelines not being followed / enforced');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (29, 'Data and information management', 'Quality', 'Bank data', 'Bank data unsuitability / incompatibility issues e.g. due to data quality guidelines not being followed / enforced');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (30, 'Data and information management', 'Data protection and confidentiality management', 'Customer data', 'Risks related to the leakage / unanonymisation of confidential customer data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (31, 'Data and information management', 'Data protection and confidentiality management', 'Employee data', 'Risks related to the leakage / unanonymisation of confidential employee data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (32, 'Data and information management', 'Data protection and confidentiality management', 'Bank data', 'Risks related to the unauthorised leakage of proprietary bank data');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (33, 'Innovation and model risk', 'Development and use of analytical models', 'Model development errors', 'Development / design errors in models e.g. poor parameterisation, inappropriate assumptions, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (34, 'Innovation and model risk', 'Development and use of analytical models', 'Solution implementation flaws / errors', 'Errors in implementation of models e.g. incorrect formulas, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (35, 'Innovation and model risk', 'Development and use of analytical models', 'Unsuitable model application', 'Use of wrong model for the task at hand e.g. wrong model for customer segment / proposition being evaluated');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (36, 'Innovation and model risk', 'Innovation execution risks', 'Design issues', 'System design flaws caused by human error or inadequate system requirements sourcing, leading to an unstable / incompatible design');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (37, 'Innovation and model risk', 'Innovation execution risks', 'Planning issues', 'Development planning / scheduling issues i.e. around sprint planning, resource allocations, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (38, 'Innovation and model risk', 'Innovation execution risks', 'Phasing issues', 'Development phasing and dependency management challenges');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (39, 'Innovation and model risk', 'Innovation execution risks', 'Implementation / execution issues', 'Development execution errors e.g. incorrect formulas, type management errors, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (40, 'Innovation and model risk', 'Innovation execution risks', 'Inadequate testing and documentation', 'Inadequate code testing and documentation, increasing likelihood of system failure');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (41, 'Innovation and model risk', 'Innovation execution risks', 'Backwards / sideways compatibility issues', 'Inadequate maintenance of backwards / sideways compatibility of new model / feature with the rest of the codebase, leading to interfacing / version management issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (42, 'Third party failure', 'Critical third party control failure', 'Framework effectiveness failure', 'Lack of an effective control framework around critical (i.e. Sysc 8-grade) suppliers e.g. 10x, AWS, etc. leading to regulatory impact / action');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (43, 'Third party failure', 'Critical third party control failure', 'Framework evidence failure', 'Lack of sufficient evidence of the effectiveness of the critical supplier management framework, leading to regulatory impact / action');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (44, 'Third party failure', 'Third party criminality / non-compliance', 'Criminality', 'Dealing with a criminal third party e.g. due to inadequate due diligence, conflicts of interest, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (45, 'Third party failure', 'Third party criminality / non-compliance', 'Regulatory non-compliance', 'Third party non-compliance with regulations e.g. AML laws, leading to regulatory impact on bank');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (46, 'Third party failure', 'Third party criminality / non-compliance', 'Policy non-compliance', 'Third party non-compliance with bank outsourcing / social corporate responsibility policies / practices');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (47, 'Customers', 'Customer profiling', 'Profiling failures', 'Failure to identify an individual customer?s needs / requirements, leading to erronous / inadequate provision of services');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (48, 'Customers', 'Sales practice', 'Breach of fiduciary duty', 'Breach of fiduciary duty to customers in lending agreements');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (49, 'Customers', 'Sales practice', 'Miscommunication', 'Issues arising from ambiguous / misleading / offensive language in customer communications, website / app copywriting, advertising, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (50, 'Customers', 'Sales practice', 'Accessibility failures', 'Failure to provide customers with accessible features for account access / communications e.g. Braille statements, speech-enabled website, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (51, 'Customers', 'Sales practice', 'Vulnerable customers', 'Failure to adequately support vulnerable customers (e.g. the aged / differently-abled) who may need additional support / different offerings than the majority customer base');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (52, 'Customers', 'Sales practice', 'Customer support timeliness', 'Failure to provide timely customer support');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (53, 'Customers', 'Sales practice', 'Customer support effectiveness', 'Failure to provide adequate / error-free customer support');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (54, 'Customers', 'Sales practice', 'Mis-selling', 'Forcefully subscribing products to customers without their knowledge');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (55, 'Customers', 'Sales practice', 'Mis-buying', 'Risk of customer subscribing to a product they do not fully understand, due to failure of bank to provide adequate explanation');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (56, 'Customers', 'Post-sales support / management', 'Customer support timeliness', 'Failure to provide timely customer support');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (57, 'Customers', 'Post-sales support / management', 'Customer support effectiveness', 'Failure to provide adequate / error-free customer support');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (58, 'Customers', 'Post-sales support / management', 'Miscommunication', 'Issues arising from ambiguous / misleading / offensive language in customer communications, website / app copywriting, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (59, 'Customers', 'Post-sales support / management', 'Asset protection failures', 'Failure to adequately record / reconcile / protect client assets, potentially leading to adverse regulatory and customer impact');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (60, 'Customers', 'Post-sales support / management', 'Accessibility failures', 'Failure to provide customers with accessible features for account access / communications e.g. Braille statements, speech-enabled website, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (61, 'Customers', 'Post-sales support / management', 'Vulnerable customers', 'Failure to adequately support vulnerable customers (e.g. the aged / differently-abled) who may need additional support / different offerings than the majority customer base');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (62, 'Customers', 'Complaints / remediation', 'Mishandling', 'Complaint mishandling issues e.g. erronously closing an open complaint, misrouting customer support requests, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (63, 'Customers', 'Complaints / remediation', 'Dispute management', 'Customer dispute resolution / claims management issues');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (64, 'Business practices', 'Legal (excluding employment law)', 'Contractual rights', 'Risk of legal action related to contractual rights violations e.g. potentially arising from weak / non-enforceable contracts');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (65, 'Business practices', 'Legal (excluding employment law)', 'Non-contractual rights', 'Risk of legal action related to non-contractual rights violations (including intellectual property)');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (66, 'Business practices', 'Legal (excluding employment law)', 'Dispute management', 'Issues related to mis-management of ongoing legal disputes');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (67, 'Business practices', 'Tax', 'Assessment failures', 'Issues related to inaccurate assessment / calculation of tax obligations e.g. due to misinterpretation of requirements / regulations');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (68, 'Business practices', 'Tax', 'Filing failures', 'Issues related to failure to file / untimeliness in filing taxes');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (69, 'Business practices', 'Accreditation and licensing', 'Licensing failure', 'Risk of removal / non-renewal of Virgin Money (core) banking license');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (70, 'Business practices', 'Accreditation and licensing', 'Accreditation failures', 'Risk of removal / non-renewal of accreditations related to certain propositions / services / individuals');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (71, 'Business practices', 'Regulatory reporting', 'Misinterpretation', 'Misinterpretation of standards and policies related to regulatory reporting');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (72, 'Business practices', 'Regulatory reporting', 'Misapplication', 'Misapplication of standards and policies related to regulatory reporting');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (73, 'Business practices', 'Regulatory reporting', 'Untimeliness', 'Failure to report / untimeliness in reporting');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (74, 'Business practices', 'Regulatory reporting', 'Inaccuracy', 'Inaccurate / incomplete reporting');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (75, 'Business practices', 'Regulatory reporting', 'Fraudulent reporting', 'Fraudulent reporting by bank staff / senior management to the regulator');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (76, 'Propositions', 'Proposition / service design', 'Inadequate customer research', 'Inadequate customer research / data collection to inform proposition / service design, leading to inaccurate view of customer group needs / value that the bank''s services provide');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (77, 'Propositions', 'Proposition / service design', 'Proposition assembly flaws', 'Flaws in proposition assembly / interaction design, leading to inefficient customer experience');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (78, 'Propositions', 'Proposition / service design', 'Customisation issues', 'Risk arising from potentially risky / unstable combinations / customisations of bank propositions');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (79, 'Propositions', 'Suitability', 'Unsuitable subscription / advice', 'Subscribing unsuitable products or providing unsuitable advice to customers');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (80, 'Propositions', 'Proposition information / distribution', 'Marketing / promotion issues', 'Issues related to marketing / promotion disclosure, including device differentiation i.e. need to present essential equipment legibly on all device types, screen sizes, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (81, 'Propositions', 'Proposition information / distribution', 'Misrepresentation issues', 'Issues related to misrepresentation of product qualities or performance e.g. using hyperbolic advertising, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (82, 'Propositions', 'Proposition information / distribution', 'Publishing / distribution issues', 'Issues related to the publishing of bank apps / tools e.g. ineligibility for / failure to publish iOS app on App Store due to terms violations / disputes, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (83, 'Propositions', 'Performance issues', 'Performance expectation failure', 'Failure to meet customers? performance expectations e.g. related to provision of services, efficiency of interactions, attractiveness of design, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (84, 'Propositions', 'Performance issues', 'Fair value expectation failure', 'Failure to meet customers? fair value expectations e.g. not performing upto required standard compared with other products of similar price');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (85, 'Execution', 'Customer payments / transactions', 'Misrouting', 'Misrouting of payment to wrong payee');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (86, 'Execution', 'Customer payments / transactions', 'Amount errors', 'Failure to complete payment or use of incorrect amount to process payment / transaction instruction');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (87, 'Execution', 'Customer payments / transactions', 'Delays', 'Delays in processing payments / transactions');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (88, 'Execution', 'Customer payments / transactions', 'Duplication', 'Duplication of payments / transactions');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (89, 'Execution', 'Internal payments', 'Payroll mismanagement', 'Issues related to payment of salaries / benefits to employees e.g. delays, issues with amounts, duplication, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (90, 'Execution', 'Internal payments', 'Third party / vendor payment failure', 'Issues related to payment of invoice fees to third parties / suppliers e.g. delays, issues with amounts, duplication, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (91, 'Execution', 'Data and documentation', 'Regulatory data capture failure', 'Failure to capture regulator-required customer data / documents e.g. identification documents, residency status documents, tax information, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (92, 'Execution', 'Data and documentation', 'Incorrect regulatory data capture', 'Capturing incorrect regulator-required customer data e.g. wrong age, address, etc. due to issues in data scraping / customer service, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (93, 'Execution', 'Data and documentation', 'Non-regulatory data capture failure', 'Failure to capture (non regulator-required) customer data e.g. records / logs from customer support interactions');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (94, 'Execution', 'Data and documentation', 'Incorrect non-regulator data capture', 'Capturing incorrect non regulator-required customer data e.g. customer service records, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (95, 'Execution', 'Internal reporting / business intelligence (BI)', 'Quality issues', 'Errors / inaccuracy / incompleteness in reporting / BI production');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (96, 'Execution', 'Internal reporting / business intelligence (BI)', 'Timeliness issues', 'Delays in reporting / BI production');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (97, 'Execution', 'Change and transformation', 'Planning errors', 'Project scoping, design or scheduling errors i.e. risk of schedule overruns, design not being fit for purpose, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (98, 'Execution', 'Change and transformation', 'Budgeting issues', 'Project budgeting issues i.e. insufficient funds available, risk of budget overruns, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (99, 'Execution', 'Change and transformation', 'Project portfolio management issues', 'Issues related to balancing multiple change projects e.g. dependency management, budget clashes, prioritisation clashes, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (100, 'Employee and workplace safety / environment', 'Employee safety', 'Security event', 'Security event that could affect employee safety e.g. travel accidents, terrorist attacks, kidnapping, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (101, 'Employee and workplace safety / environment', 'Employee safety', 'Medical event', 'Medical event that could affect employee safety e.g. pandemics, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (102, 'Employee and workplace safety / environment', 'Employee relations', 'Organised labour activity / strikes', 'Risk of employees organising labour activity / disputes e.g. strikes, impacting productivity and the company''s reputation');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (103, 'Employee and workplace safety / environment', 'Employee relations', 'Breach of collective agreement', 'Issues related to breach of the collective bargaining agreement between the bank, its employees, and any organised labour / professional membership organisations');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (104, 'Employee and workplace safety / environment', 'Employee relations', 'Breach of employment rights', 'Issues related to breach of employee''s legal or individual rights');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (105, 'Employee and workplace safety / environment', 'Employee relations', 'Breach of contractual obligations', 'Issues related to breach of the contractual obligations placed on the bank through employee contracts');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (106, 'Employee and workplace safety / environment', 'Employee relations', 'Harassment / intimidation issues', 'Issues related to harassment / intimidation / violence by the bank or its staff member(s) against an employee');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (107, 'Employee and workplace safety / environment', 'Employee relations', 'Discrimination / diversity-adverse actions', 'Issues related to discriminatory practice in business processes / hiring, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (108, 'Employee and workplace safety / environment', 'Workplace environment / safety', 'Occupational health', 'Risks related to occupational health e.g. stress / mental health, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (109, 'Employee and workplace safety / environment', 'Workplace environment / safety', 'General physical safety', 'Includes workplace accidents / incidents e.g. slips / trips / falls');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (110, 'Security of physical assets', 'Structures', 'Robbery / burglary', 'Burglary of premises due to compromise of physical security');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (111, 'Security of physical assets', 'Structures', 'Physical damage', 'Physical damage to buildings / structures due to natural disasters, terrorism / vandalism, flooding, external construction actions, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (112, 'Security of physical assets', 'Structures', 'Chemical / biological / radiological attack', 'Physical damage and disruption to buildings / structures due to chemical, biological or radiological attacks');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (113, 'Security of physical assets', 'Furniture and equipment', 'Theft', 'Theft of company belongings e.g. furniture, employee computing equipment, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (114, 'Security of physical assets', 'Furniture and equipment', 'Physical damage', 'Physical damage to  equipment due to natural disasters, terrorism / vandalism, flooding, external construction actions, etc.');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (115, 'Internal fraud and cyber security', 'Out of scope', 'Out of scope', 'Fraud carried out by a bank staff member (inclusion of contractors TBD) against the bank or its customers e.g. misappopriation of funds, intellectual property theft, etc. which may include a cyber attack (e.g. malware, Denial of Service, etc.) component');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (116, 'External fraud and cyber security', 'Out of scope', 'Out of scope', 'Fraud carried out by an external against the bank or its customers e.g. misappopriation of funds, intellectual property theft, etc. which may include a cyber attack (e.g. malware, Denial of Service, etc.) component');
INSERT INTO public.fmode_ref_tbl (fmode_ref_id, fmode_ref_level_1, fmode_ref_level_2, fmode_ref_level_3, fmode_ref_description) VALUES (117, 'Financial crime', 'Out of scope', 'Out of scope', 'Criminal acts by bank staff members or external agents (e.g. customers) that could affect the bank. Includes money laundering, sponsorship of terrorism, sanctions violations and bribery / corruption');


--
-- Data for Name: frequency_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.frequency_ref_tbl (frequency_ref_id, frequency_label, frequency_name, frequency_description, frequency_upper, frequency_lower) VALUES (1, 'A', 'Rare', 'Once in 10 years', 0.025, 0.000);
INSERT INTO public.frequency_ref_tbl (frequency_ref_id, frequency_label, frequency_name, frequency_description, frequency_upper, frequency_lower) VALUES (2, 'B', 'unlikely', 'Once in 5 Years', 0.050, 2.500);
INSERT INTO public.frequency_ref_tbl (frequency_ref_id, frequency_label, frequency_name, frequency_description, frequency_upper, frequency_lower) VALUES (3, 'C', 'Possible', 'Once in 3 Years', 0.083, 2.500);
INSERT INTO public.frequency_ref_tbl (frequency_ref_id, frequency_label, frequency_name, frequency_description, frequency_upper, frequency_lower) VALUES (4, 'D', 'Likely', 'Once a year', 0.250, 2.500);
INSERT INTO public.frequency_ref_tbl (frequency_ref_id, frequency_label, frequency_name, frequency_description, frequency_upper, frequency_lower) VALUES (5, 'E', 'Happening', 'Quarterly', 0.500, 2.500);


--
-- Data for Name: jhi_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.jhi_authority (name) VALUES ('ROLE_ADMIN');
INSERT INTO public.jhi_authority (name) VALUES ('ROLE_USER');


--
-- Data for Name: jhi_persistent_audit_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (951, 'user', '2018-09-12 16:01:14.678', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (952, 'admin', '2018-09-12 16:01:55.831', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (953, 'user', '2018-09-12 17:33:58.477', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1001, 'admin', '2018-09-13 16:06:05.583', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1002, 'user', '2018-09-13 16:18:13.408', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1003, 'admin', '2018-09-13 16:18:40.478', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1051, 'user', '2018-09-13 17:43:48.148', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1052, 'user', '2018-09-13 18:00:30.787', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1053, 'user', '2018-09-13 18:02:21.832', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1054, 'user', '2018-09-13 18:03:05.48', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1055, 'user', '2018-09-13 18:03:57.684', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1056, 'user', '2018-09-13 18:05:06.393', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1057, 'admin', '2018-09-13 18:25:50.965', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1101, 'user', '2018-09-13 19:02:03.813', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1102, 'user', '2018-09-13 19:02:15.434', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1151, 'user', '2018-09-13 19:46:14.767', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1201, 'user', '2018-09-13 20:01:22.884', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1251, 'user', '2018-09-13 20:03:37.209', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1252, 'user', '2018-09-13 20:04:10.844', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1253, 'user', '2018-09-13 20:05:47.593', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1301, 'user', '2018-09-13 20:49:52.7', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1351, 'admin', '2018-09-13 21:47:34.954', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1401, 'user', '2018-09-13 21:51:19.645', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1451, 'user', '2018-09-13 21:58:12.387', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1501, 'user', '2018-09-14 11:46:47.265', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1551, 'admin', '2018-09-14 11:54:32.107', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1601, 'user', '2018-09-14 12:04:50.648', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1651, 'user', '2018-09-14 18:17:55.754', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1652, 'admin', '2018-09-14 18:18:15.957', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1653, 'user', '2018-09-14 18:38:17.466', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1654, 'admin', '2018-09-14 18:42:36.909', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1701, 'user', '2018-09-14 19:17:23.324', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1751, 'user', '2018-09-17 11:17:55.352', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1752, 'user', '2018-09-17 11:36:55.54', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1753, 'admin', '2018-09-17 11:37:41.593', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1754, 'user', '2018-09-17 11:39:23.761', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1755, 'user', '2018-09-17 11:41:53.795', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1756, 'admin', '2018-09-17 11:42:13.902', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1801, 'user', '2018-09-17 12:12:41.839', 'AUTHENTICATION_SUCCESS');
INSERT INTO public.jhi_persistent_audit_event (event_id, principal, event_date, event_type) VALUES (1802, 'admin', '2018-09-17 12:14:57.448', 'AUTHENTICATION_SUCCESS');


--
-- Data for Name: jhi_persistent_audit_evt_data; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: jhi_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) VALUES (1, 'system', '$2a$10$mE.qmcV0mFU5NcKh73TZx.z4ueI/.bDWbj0T1BYyqP481kGGarKLG', 'System', 'System', 'system@localhost', '', true, 'en', NULL, NULL, 'system', '2018-09-12 15:57:20.383404', NULL, 'system', NULL);
INSERT INTO public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) VALUES (2, 'anonymoususer', '$2a$10$j8S5d7Sr7.8VTOYNviDPOeWX8KcYILUVJBsYV83Y5NtECayypx9lO', 'Anonymous', 'User', 'anonymous@localhost', '', true, 'en', NULL, NULL, 'system', '2018-09-12 15:57:20.383404', NULL, 'system', NULL);
INSERT INTO public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) VALUES (3, 'admin', '$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC', 'Administrator', 'Administrator', 'admin@localhost', '', true, 'en', NULL, NULL, 'system', '2018-09-12 15:57:20.383404', NULL, 'system', NULL);
INSERT INTO public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) VALUES (4, 'user', '$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K', 'User', 'User', 'user@localhost', '', true, 'en', NULL, NULL, 'system', '2018-09-12 15:57:20.383404', NULL, 'system', NULL);


--
-- Data for Name: jhi_user_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.jhi_user_authority (user_id, authority_name) VALUES (1, 'ROLE_ADMIN');
INSERT INTO public.jhi_user_authority (user_id, authority_name) VALUES (1, 'ROLE_USER');
INSERT INTO public.jhi_user_authority (user_id, authority_name) VALUES (3, 'ROLE_ADMIN');
INSERT INTO public.jhi_user_authority (user_id, authority_name) VALUES (3, 'ROLE_USER');
INSERT INTO public.jhi_user_authority (user_id, authority_name) VALUES (4, 'ROLE_USER');


--
-- Data for Name: kra_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (1, 'Systems', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (2, 'Business Continuity Management (BCM)', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (3, 'Data and information management', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (4, 'Innovation and model risk', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (5, 'Third party failure', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (6, 'Customers', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (7, 'Business practices', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (8, 'Propositions', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (9, 'Execution', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (10, 'Employee and workplace safety / environment', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (11, 'Security of physical assets', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (12, 'Internal fraud and cyber security', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (13, 'External fraud and cyber security', NULL);
INSERT INTO public.kra_tbl (kra_id, kra_label, kra_description) VALUES (14, 'Financial crime', NULL);


--
-- Data for Name: policy_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (1, 'Information management', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (2, 'Systems', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (3, 'Business continuity management ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (4, 'Change', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (5, 'Competition law', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (6, 'Compliance', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (7, 'Health and Safety', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (8, 'Model Risk', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (9, 'Outsourcing & SYSC8 Supplier Management ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (10, 'Conduct risk', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (11, 'Whistleblowing', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (12, 'Vulnerable customers', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (13, 'Taxation', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (14, 'Reputation risk', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (15, 'Regulator contact', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (16, 'Product approval ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (17, 'Pricing ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (18, 'People ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (19, 'Legal risk management', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (20, 'Data protection and privacy', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (21, 'Payment ', NULL, NULL);
INSERT INTO public.policy_ref_tbl (policy_ref_id, policy_name, policy_description, policy_link) VALUES (22, 'Financial Crime Policy', NULL, NULL);

--
-- Data for Name: process_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: riskcube_ref_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (76, 1, 1, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (77, 1, 2, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (78, 1, 3, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (79, 1, 4, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (80, 1, 5, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (81, 2, 1, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (82, 2, 2, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (83, 2, 3, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (84, 2, 4, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (85, 2, 5, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (86, 3, 1, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (87, 3, 2, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (88, 3, 3, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (89, 3, 4, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (90, 3, 5, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (91, 4, 1, NULL, 'G', 'The risk and any associated mitigating actions can be managed effectively at a ''Head of'' department level');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (92, 4, 2, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (93, 4, 3, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (94, 4, 4, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (95, 4, 5, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (96, 5, 1, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (97, 5, 2, NULL, 'A', 'The need for further mitigation should be established at functional level and agreed by the relevant Executive');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (98, 5, 3, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (99, 5, 4, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');
INSERT INTO public.riskcube_ref_tbl (riskcube_ref_id, finmat_ref_id, frequency_ref_id, frequency_risk_level, frequency_rag, frequency_action) VALUES (100, 5, 5, NULL, 'R', 'Board oversight required. The risk must form part of RCSA reporting to Risk Committee to enable challenge of whether the risk, and its associated mitigating actions is acceptable, or requires further or more immediate mitigation');





--
-- Name: finmat_ref_tbl_finmat_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.finmat_ref_tbl_finmat_ref_id_seq', 5, true);


--
-- Name: fmech_ref_det_tbl_fmech_ref_det_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fmech_ref_det_tbl_fmech_ref_det_id_seq', 5, true);


--
-- Name: fmech_ref_tbl_fmech_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fmech_ref_tbl_fmech_ref_id_seq', 3, true);


--
-- Name: fmode_ref_tbl_fmode_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fmode_ref_tbl_fmode_ref_id_seq', 117, true);


--
-- Name: frequency_ref_tbl_frequency_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.frequency_ref_tbl_frequency_ref_id_seq', 6, true);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1850, true);


--
-- Name: kra_tbl_kra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kra_tbl_kra_id_seq', 14, true);


--
-- Name: policy_ref_tbl_policy_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.policy_ref_tbl_policy_ref_id_seq', 22, true);


--
-- Name: process_ref_tbl_process_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_ref_tbl_process_ref_id_seq', 1, false);


--
-- Name: riskcube_ref_tbl_riskcube_ref_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.riskcube_ref_tbl_riskcube_ref_id_seq', 100, true);

