package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Frequency;
import com.ubm.opsrisk.repository.FrequencyRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.FrequencyService;
import com.ubm.opsrisk.service.dto.FrequencyDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing frequency.
 * <p>
 * This class accesses the Frequency entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Frequency and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FrequencyResource {

    private final Logger log = LoggerFactory.getLogger(FrequencyResource.class);

    private final FrequencyService frequencyService;

    private final FrequencyRepository frequencyRepository;

    private final MailService mailService;

    public FrequencyResource(FrequencyService frequencyService, FrequencyRepository frequencyRepository, MailService mailService) {
        this.frequencyService = frequencyService;
        this.frequencyRepository = frequencyRepository;
        this.mailService = mailService;
    }

    /**
     * GET /frequencies : get all frequencies.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all frequencies
     */
    @GetMapping("/frequencies")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<FrequencyDTO>> getAllActiveFrequencies(Pageable pageable) {
        final Page<FrequencyDTO> page = frequencyService.getAllActiveFrequencies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/frequencies");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/frequencies/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<FrequencyDTO>> getAllFrequencies(Pageable pageable) {
        final Page<FrequencyDTO> page = frequencyService.getAllFrequencies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/frequencies/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/frequencies/{frequencyId}")
    @Timed
    public ResponseEntity<FrequencyDTO> getFrequency(@PathVariable Long frequencyId) {
        log.debug("REST request to get Frequency : {}", frequencyId);
        return ResponseUtil.wrapOrNotFound(
        		frequencyRepository.findByFrequencyRefId(frequencyId)
                .map(FrequencyDTO::new));
    }
    
    @DeleteMapping("/frequencies/{frequencyId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteFrequency(@PathVariable Long frequencyId) {
        log.debug("REST request to delete Frequency: {}", frequencyId);
        frequencyService.deleteFrequency(frequencyId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "frequencies.deleted", String.valueOf(frequencyId))).build();
    }
    
    @PostMapping("/frequencies")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Frequency> createFrequency(@Valid @RequestBody FrequencyDTO frequencyDTO) throws URISyntaxException {
        log.debug("REST request to save Frequency : {}", frequencyDTO);

        if (frequencyDTO.getFrequencyRefId() != null) {
            throw new BadRequestAlertException("A new frequency cannot already have an ID", "frequencyManagement", "idexists");
            // Lowercase the frequency login before comparing with database
        } else if (frequencyRepository.findByFrequencyRefId(frequencyDTO.getFrequencyRefId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "frequencyManagement", "idexists");
        }  {
            Frequency newFrequency = frequencyService.createFrequency(frequencyDTO);
            // mailService.sendCreationEmail(newFrequency);
            return ResponseEntity.created(new URI("/api/frequencies/" + newFrequency.getFrequencyRefId()))
                .headers(HeaderUtil.createAlert( "frequencies.created", String.valueOf(newFrequency.getFrequencyRefId())))
                .body(newFrequency);
        }
    }

   
    @PutMapping("/frequencies")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FrequencyDTO> updateFrequency(@Valid @RequestBody FrequencyDTO frequencyDTO) throws URISyntaxException {
        log.debug("REST request to update Frequency : {}", frequencyDTO);
        Optional<Frequency> existingFrequency = frequencyRepository.findByFrequencyRefId(frequencyDTO.getFrequencyRefId());
        if (existingFrequency.isPresent() && (!existingFrequency.get().getFrequencyRefId().equals(frequencyDTO.getFrequencyRefId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "frequencyManagement", "idexists");
        }
        Optional<FrequencyDTO> updatedFrequency = frequencyService.updateFrequency(frequencyDTO);

        return ResponseUtil.wrapOrNotFound(updatedFrequency,
            HeaderUtil.createAlert("frequencies.updated", String.valueOf(frequencyDTO.getFrequencyRefId())));
    }
}
