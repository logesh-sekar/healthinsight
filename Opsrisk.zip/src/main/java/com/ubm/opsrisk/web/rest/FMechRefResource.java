package com.ubm.opsrisk.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codahale.metrics.annotation.Timed;
import com.ubm.opsrisk.domain.FMechRef;
import com.ubm.opsrisk.repository.FMechRefRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.FMechRefService;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.dto.FMechRefDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;

import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing fMechRef.
 * <p>
 * This class accesses the FMechRef entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between FMechRef and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FMechRefResource {

    private final Logger log = LoggerFactory.getLogger(FMechRefResource.class);

    private final FMechRefService fMechRefService;

    private final FMechRefRepository fMechRefRepository;

    private final MailService mailService;

    public FMechRefResource(FMechRefService fMechRefService, FMechRefRepository fMechRefRepository, MailService mailService) {
        this.fMechRefService = fMechRefService;
        this.fMechRefRepository = fMechRefRepository;
        this.mailService = mailService;
    }

    /**
     * GET /fmechref : get all fmechref.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all fmechref
     */
    @GetMapping("/fmechref")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<FMechRefDTO>> getAllActiveFMechRef(Pageable pageable) {
        final Page<FMechRefDTO> page = fMechRefService.getAllActiveFMechRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmechref");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmechref/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<FMechRefDTO>> getAllFMechRef(Pageable pageable) {
        final Page<FMechRefDTO> page = fMechRefService.getAllFMechRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmechref/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmechref/{fMechRefId}")
    @Timed
    public ResponseEntity<FMechRefDTO> getFMechRef(@PathVariable Long fMechRefId) {
        log.debug("REST request to get FMechRef : {}", fMechRefId);
        return ResponseUtil.wrapOrNotFound(
        		fMechRefRepository.findByFmechRefId(fMechRefId)
                .map(FMechRefDTO::new));
    }
    
    @DeleteMapping("/fmechref/{fMechRefId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteFMechRef(@PathVariable Long fMechRefId) {
        log.debug("REST request to delete FMechRef: {}", fMechRefId);
        fMechRefService.deleteFMechRef(fMechRefId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "fmechref.deleted", String.valueOf(fMechRefId))).build();
    }
    
    @PostMapping("/fmechref")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FMechRef> createFMechRef(@Valid @RequestBody FMechRefDTO fMechRefDTO) throws URISyntaxException {
        log.debug("REST request to save FMechRef : {}", fMechRefDTO);

        if (fMechRefDTO.getFmechRefId() != null) {
            throw new BadRequestAlertException("A new fMechRef cannot already have an ID", "fMechRefManagement", "idexists");
            // Lowercase the fMechRef login before comparing with database
        } else if (fMechRefRepository.findByFmechRefId(fMechRefDTO.getFmechRefId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "fMechRefManagement", "idexists");
        }  {
            FMechRef newFMechRef = fMechRefService.createFMechRef(fMechRefDTO);
            // mailService.sendCreationEmail(newFMechRef);
            return ResponseEntity.created(new URI("/api/fmechref/" + newFMechRef.getFmechRefId()))
                .headers(HeaderUtil.createAlert( "fmechref.created", String.valueOf(newFMechRef.getFmechRefId())))
                .body(newFMechRef);
        }
    }

   
    @PutMapping("/fmechref")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FMechRefDTO> updateFMechRef(@Valid @RequestBody FMechRefDTO fMechRefDTO) throws URISyntaxException {
        log.debug("REST request to update FMechRef : {}", fMechRefDTO);
        Optional<FMechRef> existingFMechRef = fMechRefRepository.findByFmechRefId(fMechRefDTO.getFmechRefId());
        if (existingFMechRef.isPresent() && (!existingFMechRef.get().getFmechRefId().equals(fMechRefDTO.getFmechRefId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "fMechRefManagement", "idexists");
        }
        Optional<FMechRefDTO> updatedFMechRef = fMechRefService.updateFMechRef(fMechRefDTO);

        return ResponseUtil.wrapOrNotFound(updatedFMechRef,
            HeaderUtil.createAlert("fmechref.updated", String.valueOf(fMechRefDTO.getFmechRefId())));
    }
}
