package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Policy;
import com.ubm.opsrisk.repository.PolicyRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.PolicyService;
import com.ubm.opsrisk.service.dto.PolicyDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing policy.
 * <p>
 * This class accesses the Policy entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Policy and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class PolicyResource {

    private final Logger log = LoggerFactory.getLogger(PolicyResource.class);

    private final PolicyService policyService;

    private final PolicyRepository policyRepository;

    private final MailService mailService;

    public PolicyResource(PolicyService policyService, PolicyRepository policyRepository, MailService mailService) {
        this.policyService = policyService;
        this.policyRepository = policyRepository;
        this.mailService = mailService;
    }

    /**
     * GET /policies : get all policies.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all policies
     */
    @GetMapping("/policies")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<PolicyDTO>> getAllActivePolicies(Pageable pageable) {
        final Page<PolicyDTO> page = policyService.getAllActivePolicies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/policies");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/policies/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<PolicyDTO>> getAllPolicies(Pageable pageable) {
        final Page<PolicyDTO> page = policyService.getAllPolicies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/policies/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/policies/{policyId}")
    @Timed
    public ResponseEntity<PolicyDTO> getPolicy(@PathVariable Long policyId) {
        log.debug("REST request to get Policy : {}", policyId);
        return ResponseUtil.wrapOrNotFound(
        		policyRepository.findByPolicyId(policyId)
                .map(PolicyDTO::new));
    }
    
    @DeleteMapping("/policies/{policyId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deletePolicy(@PathVariable Long policyId) {
        log.debug("REST request to delete Policy: {}", policyId);
        policyService.deletePolicy(policyId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "policies.deleted", String.valueOf(policyId))).build();
    }
    
    @PostMapping("/policies")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Policy> createPolicy(@Valid @RequestBody PolicyDTO policyDTO) throws URISyntaxException {
        log.debug("REST request to save Policy : {}", policyDTO);

        if (policyDTO.getPolicyId() != null) {
            throw new BadRequestAlertException("A new policy cannot already have an ID", "policyManagement", "idexists");
            // Lowercase the policy login before comparing with database
        } else if (policyRepository.findByPolicyId(policyDTO.getPolicyId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "policyManagement", "idexists");
        }  {
            Policy newPolicy = policyService.createPolicy(policyDTO);
            // mailService.sendCreationEmail(newPolicy);
            return ResponseEntity.created(new URI("/api/policies/" + newPolicy.getPolicyId()))
                .headers(HeaderUtil.createAlert( "policies.created", String.valueOf(newPolicy.getPolicyId())))
                .body(newPolicy);
        }
    }

   
    @PutMapping("/policies")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<PolicyDTO> updatePolicy(@Valid @RequestBody PolicyDTO policyDTO) throws URISyntaxException {
        log.debug("REST request to update Policy : {}", policyDTO);
        Optional<Policy> existingPolicy = policyRepository.findByPolicyId(policyDTO.getPolicyId());
        if (existingPolicy.isPresent() && (!existingPolicy.get().getPolicyId().equals(policyDTO.getPolicyId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "policyManagement", "idexists");
        }
        Optional<PolicyDTO> updatedPolicy = policyService.updatePolicy(policyDTO);

        return ResponseUtil.wrapOrNotFound(updatedPolicy,
            HeaderUtil.createAlert("policies.updated", String.valueOf(policyDTO.getPolicyId())));
    }
}
