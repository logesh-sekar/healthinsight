package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Control;
import com.ubm.opsrisk.repository.ControlRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.ControlService;
import com.ubm.opsrisk.service.dto.ControlDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing control.
 * <p>
 * This class accesses the Control entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Control and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class ControlResource {

    private final Logger log = LoggerFactory.getLogger(ControlResource.class);

    private final ControlService controlService;

    private final ControlRepository controlRepository;

    private final MailService mailService;

    public ControlResource(ControlService controlService, ControlRepository controlRepository, MailService mailService) {
        this.controlService = controlService;
        this.controlRepository = controlRepository;
        this.mailService = mailService;
    }

    /**
     * GET /control : get all control.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all control
     */
    @GetMapping("/control")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<ControlDTO>> getAllActiveControl(Pageable pageable) {
        final Page<ControlDTO> page = controlService.getAllActiveControl(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/control");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/control/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<ControlDTO>> getAllControls(Pageable pageable) {
        final Page<ControlDTO> page = controlService.getAllControls(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/control/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/control/{controlId}")
    @Timed
    public ResponseEntity<ControlDTO> getControl(@PathVariable String controlId) {
        log.debug("REST request to get Control : {}", controlId);
        return ResponseUtil.wrapOrNotFound(
        		controlRepository.findByControlRefId(controlId)
                .map(ControlDTO::new));
    }
    
    @DeleteMapping("/control/{controlId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteControl(@PathVariable String controlId) {
        log.debug("REST request to delete Control: {}", controlId);
        controlService.deleteControl(controlId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "control.deleted", controlId)).build();
    }
    
    @PostMapping("/control")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Control> createControl(@Valid @RequestBody ControlDTO controlDTO) throws URISyntaxException {
        log.debug("REST request to save Control : {}", controlDTO);

        if (controlDTO.getControlRefId() != null) {
            throw new BadRequestAlertException("A new control cannot already have an ID", "controlManagement", "idexists");
            // Lowercase the control login before comparing with database
        } else if (controlRepository.findByControlRefId(controlDTO.getControlRefId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "controlManagement", "idexists");
        }  {
            Control newControl = controlService.createControl(controlDTO);
            // mailService.sendCreationEmail(newControl);
            return ResponseEntity.created(new URI("/api/control/" + newControl.getControlRefId()))
                .headers(HeaderUtil.createAlert( "control.created", String.valueOf(newControl.getControlRefId())))
                .body(newControl);
        }
    }

   
    @PutMapping("/control")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<ControlDTO> updateControl(@Valid @RequestBody ControlDTO controlDTO) throws URISyntaxException {
        log.debug("REST request to update Control : {}", controlDTO);
        Optional<Control> existingControl = controlRepository.findByControlRefId(controlDTO.getControlRefId());
        if (existingControl.isPresent() && (!existingControl.get().getControlRefId().equals(controlDTO.getControlRefId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "controlManagement", "idexists");
        }
        Optional<ControlDTO> updatedControl = controlService.updateControl(controlDTO);

        return ResponseUtil.wrapOrNotFound(updatedControl,
            HeaderUtil.createAlert("control.updated", String.valueOf(controlDTO.getControlRefId())));
    }
}
