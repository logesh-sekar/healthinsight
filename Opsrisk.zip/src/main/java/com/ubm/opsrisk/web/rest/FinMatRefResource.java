package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.FinMatRef;
import com.ubm.opsrisk.repository.FinMatRefRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.FinMatRefService;
import com.ubm.opsrisk.service.dto.FinMatRefDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing finMatRef.
 * <p>
 * This class accesses the FinMatRef entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between FinMatRef and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FinMatRefResource {

    private final Logger log = LoggerFactory.getLogger(FinMatRefResource.class);

    private final FinMatRefService finMatRefService;

    private final FinMatRefRepository finMatRefRepository;

    private final MailService mailService;

    public FinMatRefResource(FinMatRefService finMatRefService, FinMatRefRepository finMatRefRepository, MailService mailService) {
        this.finMatRefService = finMatRefService;
        this.finMatRefRepository = finMatRefRepository;
        this.mailService = mailService;
    }

    /**
     * GET /finmatref : get all finmatref.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all finmatref
     */
    @GetMapping("/finmatref")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<FinMatRefDTO>> getAllActiveFinmatref(Pageable pageable) {
        final Page<FinMatRefDTO> page = finMatRefService.getAllActiveFinMatRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/finmatref");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/finmatref/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<FinMatRefDTO>> getAllFinmatref(Pageable pageable) {
        final Page<FinMatRefDTO> page = finMatRefService.getAllFinMatRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/finmatref/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/finmatref/{finMatRefId}")
    @Timed
    public ResponseEntity<FinMatRefDTO> getFinMatRef(@PathVariable Long finMatRefId) {
        log.debug("REST request to get FinMatRef : {}", finMatRefId);
        return ResponseUtil.wrapOrNotFound(
        		finMatRefRepository.findByFinmatRefId(finMatRefId)
                .map(FinMatRefDTO::new));
    }
    
    @DeleteMapping("/finmatref/{finMatRefId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteFinMatRef(@PathVariable Long finMatRefId) {
        log.debug("REST request to delete FinMatRef: {}", finMatRefId);
        finMatRefService.deleteFinMatRef(finMatRefId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "finmatref.deleted", String.valueOf(finMatRefId))).build();
    }
    
    @PostMapping("/finmatref")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FinMatRef> createFinMatRef(@Valid @RequestBody FinMatRefDTO finMatRefDTO) throws URISyntaxException {
        log.debug("REST request to save FinMatRef : {}", finMatRefDTO);

        if (finMatRefDTO.getFinmatRefId() != null) {
            throw new BadRequestAlertException("A new finMatRef cannot already have an ID", "finMatRefManagement", "idexists");
            // Lowercase the finMatRef login before comparing with database
        } else if (finMatRefRepository.findByFinmatRefId(finMatRefDTO.getFinmatRefId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "finMatRefManagement", "idexists");
        }  {
            FinMatRef newFinMatRef = finMatRefService.createFinMatRef(finMatRefDTO);
            // mailService.sendCreationEmail(newFinMatRef);
            return ResponseEntity.created(new URI("/api/finmatref/" + newFinMatRef.getFinmatRefId()))
                .headers(HeaderUtil.createAlert( "finmatref.created", String.valueOf(newFinMatRef.getFinmatRefId())))
                .body(newFinMatRef);
        }
    }

   
    @PutMapping("/finmatref")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FinMatRefDTO> updateFinMatRef(@Valid @RequestBody FinMatRefDTO finMatRefDTO) throws URISyntaxException {
        log.debug("REST request to update FinMatRef : {}", finMatRefDTO);
        Optional<FinMatRef> existingFinMatRef = finMatRefRepository.findByFinmatRefId(finMatRefDTO.getFinmatRefId());
        if (existingFinMatRef.isPresent() && (!existingFinMatRef.get().getFinmatRefId().equals(finMatRefDTO.getFinmatRefId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "finMatRefManagement", "idexists");
        }
        Optional<FinMatRefDTO> updatedFinMatRef = finMatRefService.updateFinMatRef(finMatRefDTO);

        return ResponseUtil.wrapOrNotFound(updatedFinMatRef,
            HeaderUtil.createAlert("finmatref.updated", String.valueOf(finMatRefDTO.getFinmatRefId())));
    }
}
