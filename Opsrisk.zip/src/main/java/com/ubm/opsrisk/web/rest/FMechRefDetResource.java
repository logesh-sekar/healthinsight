package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.FMechRefDet;
import com.ubm.opsrisk.repository.FMechRefDetRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.FMechRefDetService;
import com.ubm.opsrisk.service.dto.FMechRefDetDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing fMechRefDet.
 * <p>
 * This class accesses the FMechRefDet entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between FMechRefDet and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FMechRefDetResource {

    private final Logger log = LoggerFactory.getLogger(FMechRefDetResource.class);

    private final FMechRefDetService fMechRefDetService;

    private final FMechRefDetRepository fMechRefDetRepository;

    private final MailService mailService;

    public FMechRefDetResource(FMechRefDetService fMechRefDetService, FMechRefDetRepository fMechRefDetRepository, MailService mailService) {
        this.fMechRefDetService = fMechRefDetService;
        this.fMechRefDetRepository = fMechRefDetRepository;
        this.mailService = mailService;
    }

    /**
     * GET /fmechrefdet : get all fmechrefdet.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all fmechrefdet
     */
    @GetMapping("/fmechrefdet")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<FMechRefDetDTO>> getAllActivefmechrefdet(Pageable pageable) {
        final Page<FMechRefDetDTO> page = fMechRefDetService.getAllActiveFMechRefDet(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmechrefdet");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmechrefdet/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<FMechRefDetDTO>> getAllfmechrefdet(Pageable pageable) {
        final Page<FMechRefDetDTO> page = fMechRefDetService.getAllFMechRefDet(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmechrefdet/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmechrefdet/{fMechRefDetId}")
    @Timed
    public ResponseEntity<FMechRefDetDTO> getFMechRefDet(@PathVariable Long fMechRefDetId) {
        log.debug("REST request to get FMechRefDet : {}", fMechRefDetId);
        return ResponseUtil.wrapOrNotFound(
        		fMechRefDetRepository.findByFmechRefDetId(fMechRefDetId)
                .map(FMechRefDetDTO::new));
    }
    
    @DeleteMapping("/fmechrefdet/{fMechRefDetId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteFMechRefDet(@PathVariable Long fMechRefDetId) {
        log.debug("REST request to delete FMechRefDet: {}", fMechRefDetId);
        fMechRefDetService.deleteFMechRefDat(fMechRefDetId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "fmechrefdet.deleted", String.valueOf(fMechRefDetId))).build();
    }
    
    @PostMapping("/fmechrefdet")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FMechRefDet> createFMechRefDet(@Valid @RequestBody FMechRefDetDTO fMechRefDetDTO) throws URISyntaxException {
        log.debug("REST request to save FMechRefDet : {}", fMechRefDetDTO);

        if (fMechRefDetDTO.getFmechRefDetId() != null) {
            throw new BadRequestAlertException("A new fMechRefDet cannot already have an ID", "fMechRefDetManagement", "idexists");
            // Lowercase the fMechRefDet login before comparing with database
        } else if (fMechRefDetRepository.findByFmechRefDetId(fMechRefDetDTO.getFmechRefDetId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "fMechRefDetManagement", "idexists");
        }  {
            FMechRefDet newFMechRefDet = fMechRefDetService.createFMechRefDet(fMechRefDetDTO);
            // mailService.sendCreationEmail(newFMechRefDet);
            return ResponseEntity.created(new URI("/api/fmechrefdet/" + newFMechRefDet.getFmechRefDetId()))
                .headers(HeaderUtil.createAlert( "fmechrefdet.created", String.valueOf(newFMechRefDet.getFmechRefDetId())))
                .body(newFMechRefDet);
        }
    }

   
    @PutMapping("/fmechrefdet")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FMechRefDetDTO> updateFMechRefDet(@Valid @RequestBody FMechRefDetDTO fMechRefDetDTO) throws URISyntaxException {
        log.debug("REST request to update FMechRefDet : {}", fMechRefDetDTO);
        Optional<FMechRefDet> existingFMechRefDet = fMechRefDetRepository.findByFmechRefDetId(fMechRefDetDTO.getFmechRefDetId());
        if (existingFMechRefDet.isPresent() && (!existingFMechRefDet.get().getFmechRefDetId().equals(fMechRefDetDTO.getFmechRefDetId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "fMechRefDetManagement", "idexists");
        }
        Optional<FMechRefDetDTO> updatedFMechRefDet = fMechRefDetService.updateFMechRefDet(fMechRefDetDTO);

        return ResponseUtil.wrapOrNotFound(updatedFMechRefDet,
            HeaderUtil.createAlert("fmechrefdet.updated", String.valueOf(fMechRefDetDTO.getFmechRefDetId())));
    }
}
