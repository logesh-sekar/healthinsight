package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Process;
import com.ubm.opsrisk.repository.ProcessRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.ProcessService;
import com.ubm.opsrisk.service.dto.ProcessDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing process.
 * <p>
 * This class accesses the Process entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Process and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class ProcessResource {

    private final Logger log = LoggerFactory.getLogger(ProcessResource.class);

    private final ProcessService processService;

    private final ProcessRepository processRepository;

    private final MailService mailService;

    public ProcessResource(ProcessService processService, ProcessRepository processRepository, MailService mailService) {
        this.processService = processService;
        this.processRepository = processRepository;
        this.mailService = mailService;
    }

    /**
     * GET /process : get all process.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all process
     */
    @GetMapping("/process")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<ProcessDTO>> getAllActivePolicies(Pageable pageable) {
        final Page<ProcessDTO> page = processService.getAllActivePolicies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/process");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/process/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<ProcessDTO>> getAllPolicies(Pageable pageable) {
        final Page<ProcessDTO> page = processService.getAllPolicies(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/process/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/process/{processId}")
    @Timed
    public ResponseEntity<ProcessDTO> getProcess(@PathVariable Long processId) {
        log.debug("REST request to get Process : {}", processId);
        return ResponseUtil.wrapOrNotFound(
        		processRepository.findByProcessRefId(processId)
                .map(ProcessDTO::new));
    }
    
    @DeleteMapping("/process/{processId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteProcess(@PathVariable Long processId) {
        log.debug("REST request to delete Process: {}", processId);
        processService.deleteProcess(processId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "process.deleted", String.valueOf(processId))).build();
    }
    
    @PostMapping("/process")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Process> createProcess(@Valid @RequestBody ProcessDTO processDTO) throws URISyntaxException {
        log.debug("REST request to save Process : {}", processDTO);

        if (processDTO.getProcessId() != null) {
            throw new BadRequestAlertException("A new process cannot already have an ID", "processManagement", "idexists");
            // Lowercase the process login before comparing with database
        } else if (processRepository.findByProcessRefId(processDTO.getProcessId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "processManagement", "idexists");
        }  {
            Process newProcess = processService.createProcess(processDTO);
            // mailService.sendCreationEmail(newProcess);
            return ResponseEntity.created(new URI("/api/process/" + newProcess.getProcessId()))
                .headers(HeaderUtil.createAlert( "process.created", String.valueOf(newProcess.getProcessId())))
                .body(newProcess);
        }
    }

   
    @PutMapping("/process")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<ProcessDTO> updateProcess(@Valid @RequestBody ProcessDTO processDTO) throws URISyntaxException {
        log.debug("REST request to update Process : {}", processDTO);
        Optional<Process> existingProcess = processRepository.findByProcessRefId(processDTO.getProcessId());
        if (existingProcess.isPresent() && (!existingProcess.get().getProcessId().equals(processDTO.getProcessId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "processManagement", "idexists");
        }
        Optional<ProcessDTO> updatedProcess = processService.updateProcess(processDTO);

        return ResponseUtil.wrapOrNotFound(updatedProcess,
            HeaderUtil.createAlert("process.updated", String.valueOf(processDTO.getProcessId())));
    }
}
