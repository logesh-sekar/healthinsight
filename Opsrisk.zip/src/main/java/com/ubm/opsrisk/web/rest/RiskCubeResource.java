package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.RiskCube;
import com.ubm.opsrisk.repository.RiskCubeRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.RiskCubeService;
import com.ubm.opsrisk.service.dto.RiskCubeDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing riskCube.
 * <p>
 * This class accesses the RiskCube entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between RiskCube and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class RiskCubeResource {

    private final Logger log = LoggerFactory.getLogger(RiskCubeResource.class);

    private final RiskCubeService riskCubeService;

    private final RiskCubeRepository riskCubeRepository;

    private final MailService mailService;

    public RiskCubeResource(RiskCubeService riskCubeService, RiskCubeRepository riskCubeRepository, MailService mailService) {
        this.riskCubeService = riskCubeService;
        this.riskCubeRepository = riskCubeRepository;
        this.mailService = mailService;
    }

    /**
     * GET /riskcube : get all riskCube.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all riskCube
     */
    @GetMapping("/riskcube")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<RiskCubeDTO>> getAllActiveRiskCube(Pageable pageable) {
        final Page<RiskCubeDTO> page = riskCubeService.getAllActiveRiskCube(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/riskcube");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/riskcube/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<RiskCubeDTO>> getAllRiskCubes(Pageable pageable) {
        final Page<RiskCubeDTO> page = riskCubeService.getAllRiskCube(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/riskcube/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/riskcube/{riskCubeId}")
    @Timed
    public ResponseEntity<RiskCubeDTO> getRiskCube(@PathVariable Long riskCubeId) {
        log.debug("REST request to get RiskCube : {}", riskCubeId);
        return ResponseUtil.wrapOrNotFound(
        		riskCubeRepository.findByRiskcubeRefId(riskCubeId)
                .map(RiskCubeDTO::new));
    }
    
    @DeleteMapping("/riskcube/{riskCubeId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteRiskCube(@PathVariable Long riskCubeId) {
        log.debug("REST request to delete RiskCube: {}", riskCubeId);
        riskCubeService.deleteRiskCube(riskCubeId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "riskCube.deleted", String.valueOf(riskCubeId))).build();
    }
    
    @PostMapping("/riskcube")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<RiskCube> createRiskCube(@Valid @RequestBody RiskCubeDTO riskCubeDTO) throws URISyntaxException {
        log.debug("REST request to save RiskCube : {}", riskCubeDTO);

        if (riskCubeDTO.getRiskcubeRefId() != null) {
            throw new BadRequestAlertException("A new riskCube cannot already have an ID", "riskCubeManagement", "idexists");
            // Lowercase the riskCube login before comparing with database
        } else if (riskCubeRepository.findByRiskcubeRefId(riskCubeDTO.getRiskcubeRefId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "riskCubeManagement", "idexists");
        }  {
            RiskCube newRiskCube = riskCubeService.createRiskCube(riskCubeDTO);
            // mailService.sendCreationEmail(newRiskCube);
            return ResponseEntity.created(new URI("/api/riskcube/" + newRiskCube.getRiskcubeRefId()))
                .headers(HeaderUtil.createAlert( "riskCube.created", String.valueOf(newRiskCube.getRiskcubeRefId())))
                .body(newRiskCube);
        }
    }

   
    @PutMapping("/riskcube")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<RiskCubeDTO> updateRiskCube(@Valid @RequestBody RiskCubeDTO riskCubeDTO) throws URISyntaxException {
        log.debug("REST request to update RiskCube : {}", riskCubeDTO);
        Optional<RiskCube> existingRiskCube = riskCubeRepository.findByRiskcubeRefId(riskCubeDTO.getRiskcubeRefId());
        if (existingRiskCube.isPresent() && (!existingRiskCube.get().getRiskcubeRefId().equals(riskCubeDTO.getRiskcubeRefId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "riskCubeManagement", "idexists");
        }
        Optional<RiskCubeDTO> updatedRiskCube = riskCubeService.updateRiskCube(riskCubeDTO);

        return ResponseUtil.wrapOrNotFound(updatedRiskCube,
            HeaderUtil.createAlert("riskCube.updated", String.valueOf(riskCubeDTO.getRiskcubeRefId())));
    }
}
