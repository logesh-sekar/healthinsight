package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Fmode;
import com.ubm.opsrisk.repository.FmodeRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing policy.
 * <p>
 * This class accesses the Policy entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Policy and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FmodeResource {

    private final Logger log = LoggerFactory.getLogger(FmodeResource.class);


//    private final PolicyRepository policyRepository;
//
//
//    public FmodeResource( PolicyRepository policyRepository) {
//        this.policyRepository = policyRepository;
//
//    }
//
//    /**
//     * GET /fmode : get all fmode data.
//     *
//     * @param pageable the pagination information
//     * @return the ResponseEntity with status 200 (OK) and with body all policies
//     */
//    @GetMapping("/fmode")
//    @Timed
//    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
//    public ResponseEntity<List<PolicyDTO>> getAllActivePolicies(Pageable pageable) {
//        final Page<PolicyDTO> page = policyService.getAllActivePolicies(pageable);
//        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/policies");
//        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
//    }
        
}
