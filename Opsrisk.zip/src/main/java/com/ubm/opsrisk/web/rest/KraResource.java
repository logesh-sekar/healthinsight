package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.Kra;
import com.ubm.opsrisk.repository.KraRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.KraService;
import com.ubm.opsrisk.service.dto.KraDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing kra.
 * <p>
 * This class accesses the Kra entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between Kra and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class KraResource {

    private final Logger log = LoggerFactory.getLogger(KraResource.class);

    private final KraService kraService;

    private final KraRepository kraRepository;

    private final MailService mailService;

    public KraResource(KraService kraService, KraRepository kraRepository, MailService mailService) {
        this.kraService = kraService;
        this.kraRepository = kraRepository;
        this.mailService = mailService;
    }

    /**
     * GET /kra : get all kra.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all kra
     */
    @GetMapping("/kra")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<KraDTO>> getAllActiveKra(Pageable pageable) {
        final Page<KraDTO> page = kraService.getAllActiveKra(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/kra");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/kra/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<KraDTO>> getAllKra(Pageable pageable) {
        final Page<KraDTO> page = kraService.getAllKra(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/kra/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/kra/{kraId}")
    @Timed
    public ResponseEntity<KraDTO> getKra(@PathVariable Long kraId) {
        log.debug("REST request to get Kra : {}", kraId);
        return ResponseUtil.wrapOrNotFound(
        		kraRepository.findByKraId(kraId)
                .map(KraDTO::new));
    }
    
    @DeleteMapping("/kra/{kraId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteKra(@PathVariable Long kraId) {
        log.debug("REST request to delete Kra: {}", kraId);
        kraService.deleteKra(kraId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "kra.deleted", String.valueOf(kraId))).build();
    }
    
    @PostMapping("/kra")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Kra> createKra(@Valid @RequestBody KraDTO kraDTO) throws URISyntaxException {
        log.debug("REST request to save Kra : {}", kraDTO);

        if (kraDTO.getKraId() != null) {
            throw new BadRequestAlertException("A new kra cannot already have an ID", "kraManagement", "idexists");
            // Lowercase the kra login before comparing with database
        } else if (kraRepository.findByKraId(kraDTO.getKraId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "kraManagement", "idexists");
        }  {
            Kra newKra = kraService.createKra(kraDTO);
            // mailService.sendCreationEmail(newKra);
            return ResponseEntity.created(new URI("/api/kra/" + newKra.getKraId()))
                .headers(HeaderUtil.createAlert( "kra.created", String.valueOf(newKra.getKraId())))
                .body(newKra);
        }
    }

   
    @PutMapping("/kra")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<KraDTO> updateKra(@Valid @RequestBody KraDTO kraDTO) throws URISyntaxException {
        log.debug("REST request to update Kra : {}", kraDTO);
        Optional<Kra> existingKra = kraRepository.findByKraId(kraDTO.getKraId());
        if (existingKra.isPresent() && (!existingKra.get().getKraId().equals(kraDTO.getKraId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "kraManagement", "idexists");
        }
        Optional<KraDTO> updatedKra = kraService.updateKra(kraDTO);

        return ResponseUtil.wrapOrNotFound(updatedKra,
            HeaderUtil.createAlert("kra.updated", String.valueOf(kraDTO.getKraId())));
    }
}
