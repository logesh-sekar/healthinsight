/**
 * View Models used by Spring MVC REST controllers.
 */
package com.ubm.opsrisk.web.rest.vm;
