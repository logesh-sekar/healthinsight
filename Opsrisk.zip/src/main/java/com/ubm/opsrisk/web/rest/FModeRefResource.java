package com.ubm.opsrisk.web.rest;

import com.ubm.opsrisk.domain.FModeRef;
import com.ubm.opsrisk.repository.FModeRefRepository;
import com.ubm.opsrisk.security.AuthoritiesConstants;
import com.ubm.opsrisk.service.MailService;
import com.ubm.opsrisk.service.FModeRefService;
import com.ubm.opsrisk.service.dto.FModeRefDTO;
import com.ubm.opsrisk.web.rest.errors.BadRequestAlertException;
import com.ubm.opsrisk.web.rest.util.HeaderUtil;
import com.ubm.opsrisk.web.rest.util.PaginationUtil;
import com.codahale.metrics.annotation.Timed;

import io.github.jhipster.web.util.ResponseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import javax.validation.Valid;

/**
 * REST controller for managing fModeRef.
 * <p>
 * This class accesses the FModeRef entity, and needs to fetch its collection.
 * <p>
 * For a normal use-case, it would be better to have an eager relationship between FModeRef and Authority,
 * and send everything to the client side: there would be no View Model and DTO, a lot less code, and an outer-join
 * which would be good for performance.
 * <p>
 * Another option would be to have a specific JPA entity graph to handle this case.
 */
@RestController
@RequestMapping("/api")
public class FModeRefResource {

    private final Logger log = LoggerFactory.getLogger(FModeRefResource.class);

    private final FModeRefService fModeRefService;

    private final FModeRefRepository fModeRefRepository;

    private final MailService mailService;

    public FModeRefResource(FModeRefService fModeRefService, FModeRefRepository fModeRefRepository, MailService mailService) {
        this.fModeRefService = fModeRefService;
        this.fModeRefRepository = fModeRefRepository;
        this.mailService = mailService;
    }

    /**
     * GET /fmoderef : get all fmoderef.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and with body all fmoderef
     */
    @GetMapping("/fmoderef")
    @Timed
    // @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<List<FModeRefDTO>> getAllActiveFModeref(Pageable pageable) {
        final Page<FModeRefDTO> page = fModeRefService.getAllActiveFModeRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmoderef");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmoderef/all")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.ADMIN + "\")")
    public ResponseEntity<List<FModeRefDTO>> getAllFModeref(Pageable pageable) {
        final Page<FModeRefDTO> page = fModeRefService.getAllFModeRef(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/fmoderef/all");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    
    @GetMapping("/fmoderef/{fModeRefId}")
    @Timed
    public ResponseEntity<FModeRefDTO> getFModeRef(@PathVariable Long fModeRefId) {
        log.debug("REST request to get FModeRef : {}", fModeRefId);
        return ResponseUtil.wrapOrNotFound(
        		fModeRefRepository.findByFmodeId(fModeRefId)
                .map(FModeRefDTO::new));
    }
    
    @DeleteMapping("/fmoderef/{fModeRefId}")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<Void> deleteFModeRef(@PathVariable Long fModeRefId) {
        log.debug("REST request to delete FModeRef: {}", fModeRefId);
        fModeRefService.deleteFModeRef(fModeRefId);
        return ResponseEntity.ok().headers(HeaderUtil.createAlert( "fmoderef.deleted", String.valueOf(fModeRefId))).build();
    }
    
    @PostMapping("/fmoderef")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FModeRef> createFModeRef(@Valid @RequestBody FModeRefDTO fModeRefDTO) throws URISyntaxException {
        log.debug("REST request to save FModeRef : {}", fModeRefDTO);

        if (fModeRefDTO.getFmodeId() != null) {
            throw new BadRequestAlertException("A new fModeRef cannot already have an ID", "fModeRefManagement", "idexists");
            // Lowercase the fModeRef login before comparing with database
        } else if (fModeRefRepository.findByFmodeId(fModeRefDTO.getFmodeId()).isPresent()) {
            throw new BadRequestAlertException("ID already exists", "fModeRefManagement", "idexists");
        }  {
            FModeRef newFModeRef = fModeRefService.createFModeRef(fModeRefDTO);
            // mailService.sendCreationEmail(newFModeRef);
            return ResponseEntity.created(new URI("/api/fmoderef/" + newFModeRef.getFmodeId()))
                .headers(HeaderUtil.createAlert( "fmoderef.created", String.valueOf(newFModeRef.getFmodeId())))
                .body(newFModeRef);
        }
    }

   
    @PutMapping("/fmoderef")
    @Timed
    @PreAuthorize("hasRole(\"" + AuthoritiesConstants.USER + "\")")
    public ResponseEntity<FModeRefDTO> updateFModeRef(@Valid @RequestBody FModeRefDTO fModeRefDTO) throws URISyntaxException {
        log.debug("REST request to update FModeRef : {}", fModeRefDTO);
        Optional<FModeRef> existingFModeRef = fModeRefRepository.findByFmodeId(fModeRefDTO.getFmodeId());
        if (existingFModeRef.isPresent() && (!existingFModeRef.get().getFmodeId().equals(fModeRefDTO.getFmodeId()))) {
            throw new BadRequestAlertException("Error: Invalid Input", "fModeRefManagement", "idexists");
        }
        Optional<FModeRefDTO> updatedFModeRef = fModeRefService.updateFModeRef(fModeRefDTO);

        return ResponseUtil.wrapOrNotFound(updatedFModeRef,
            HeaderUtil.createAlert("fmoderef.updated", String.valueOf(fModeRefDTO.getFmodeId())));
    }
}
