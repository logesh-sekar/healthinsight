package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.FinMatRef;
import com.ubm.opsrisk.repository.FinMatRefRepository;
import com.ubm.opsrisk.service.dto.FinMatRefDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class FinMatRefService {

    private final Logger log = LoggerFactory.getLogger(FinMatRefService.class);

    private final FinMatRefRepository finMatRefRepository;

    public FinMatRefService(FinMatRefRepository finMatRefRepository) {
        this.finMatRefRepository = finMatRefRepository;
     }

    public FinMatRef createFinMatRef(FinMatRefDTO finMatRefDTO) {
    	FinMatRef finMatRef = new FinMatRef();
    	finMatRef.setFinmatLevel(finMatRefDTO.getFinmatLevel());
    	finMatRef.setFinmatLabel(finMatRefDTO.getFinmatLabel());
    	finMatRef.setFinmatExtImpactDescription(finMatRefDTO.getFinmatExtImpactDescription());
    	finMatRef.setFinmatRegImpactDescription(finMatRefDTO.getFinmatRegImpactDescription());
    	finMatRef.setFinmatBrand(finMatRefDTO.getFinmatBrand());
    	finMatRef.setFinmatUpperThreshold(finMatRefDTO.getFinmatUpperThreshold());
    	finMatRef.setFinmatLowerThreshold(finMatRefDTO.getFinmatLowerThreshold());
    	finMatRefRepository.save(finMatRef);
        log.debug("Created Information for finMatRef: {}", finMatRef);
        return finMatRef;
    }


    /**
     * Update all information for a specific policy, and return the modified policy.
     *
     * @param policyDTO policy to update
     * @return updated policy
     */
    public Optional<FinMatRefDTO> updateFinMatRef(FinMatRefDTO finMatRefDTO) {
        return Optional.of(finMatRefRepository
            .findByFinmatRefId(finMatRefDTO.getFinmatRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(finMatRef -> {
            	finMatRef.setFinmatLevel(finMatRefDTO.getFinmatLevel());
            	finMatRef.setFinmatLabel(finMatRefDTO.getFinmatLabel());
            	finMatRef.setFinmatExtImpactDescription(finMatRefDTO.getFinmatExtImpactDescription());
            	finMatRef.setFinmatRegImpactDescription(finMatRefDTO.getFinmatRegImpactDescription());
            	finMatRef.setFinmatBrand(finMatRefDTO.getFinmatBrand());
            	finMatRef.setFinmatUpperThreshold(finMatRefDTO.getFinmatUpperThreshold());
            	finMatRef.setFinmatLowerThreshold(finMatRefDTO.getFinmatLowerThreshold());
            	finMatRef.setIsDelete(finMatRefDTO.getIsDelete());
                log.debug("Changed Information for finMatRef: {}", finMatRef);
                return finMatRef;
            })
            .map(FinMatRefDTO::new);
    }

    public void deleteFinMatRef(Long finmatRefId) {
    	finMatRefRepository.findByFinmatRefId(finmatRefId).ifPresent(finMatRef -> {
    		finMatRef.setIsDelete(true);
        	finMatRefRepository.save(finMatRef);
            log.debug("Deleted finMatRef: {}", finMatRef);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<FinMatRefDTO> getAllFinMatRef(Pageable pageable) {
        return finMatRefRepository.findAll(pageable).map(FinMatRefDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<FinMatRefDTO> getAllActiveFinMatRef(Pageable pageable) {
        return finMatRefRepository.findAllByIsDelete(false, pageable).map(FinMatRefDTO::new);
    }
}

