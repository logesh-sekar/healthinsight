package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.Control;

/**
 * A DTO representing a user, with his authorities.
 */
public class ControlDTO {
	private String controlRefId;
    
    private Long policyRefId;

    private String controlMinimumStandardId;
    
    private String controlName;

    private String controlDescription;
    
    private Long fmodeRefId;
    
    private String controlReleveantProcess;
    
    private String controlPurpose;
    
    private String controlType;
    
    private boolean isDelete;
    
    public ControlDTO() {
        // Empty constructor needed for Jackson.
    }

    public ControlDTO(Control control) {
        this.controlRefId = control.getControlRefId();
        this.policyRefId = control.getPolicyRefId();
        this.controlMinimumStandardId = control.getControlMinimumStandardId();
        this.controlName = control.getControlName();
        this.controlDescription = control.getControlDescription();
        this.fmodeRefId = control.getFmodeRefId();
        this.controlReleveantProcess = control.getControlReleveantProcess();
        this.controlPurpose = control.getControlPurpose();
        this.controlType = control.getControlType();
        this.isDelete = control.getIsDelete();
    }
    
    public String getControlRefId() {
        return controlRefId;
    }

    public void setControlRefId(String controlRefId) {
        this.controlRefId = controlRefId;
    }

    public Long getPolicyRefId() {
        return policyRefId;
    }

    public void setPolicyRefId(Long policyRefId) {
        this.policyRefId = policyRefId;
    }
    
    public String getControlMinimumStandardId() {
        return controlMinimumStandardId;
    }

    public void setControlMinimumStandardId(String controlMinimumStandardId) {
        this.controlMinimumStandardId = controlMinimumStandardId;
    }
    
    public String getControlName() {
        return controlName;
    }

    public void setControlName(String controlName) {
        this.controlName = controlName;
    }

    public String getControlDescription() {
        return controlDescription;
    }

    public void setControlDescription(String controlDescription) {
        this.controlDescription = controlDescription;
    }
    
    public Long getFmodeRefId() {
        return fmodeRefId;
    }

    public void setFmodeRefId(Long fmodeRefId) {
        this.fmodeRefId = fmodeRefId;
    }

    public String getControlReleveantProcess() {
        return controlReleveantProcess;
    }

    public void setControlReleveantProcess(String controlReleveantProcess) {
        this.controlReleveantProcess = controlReleveantProcess;
    }

    public String getControlPurpose() {
        return controlPurpose;
    }

    public void setControlPurpose(String controlPurpose) {
        this.controlPurpose = controlPurpose;
    }

    public String getControlType() {
        return controlType;
    }

    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
 
    @Override
    public String toString() {
        return "Control{" +
        		" policyRefId='" + policyRefId + '\'' +
        		", controlMinimumStandardId='" + controlMinimumStandardId + '\'' +
        		", controlName='" + controlName + '\'' +
        		", fmodeRefId='" + fmodeRefId + '\'' +
        		", controlReleveantProcess='" + controlReleveantProcess + '\'' +
        		", controlPurpose='" + controlPurpose + '\'' +
        		", controlType='" + controlType + '\'' +
        		", isDelete='" + isDelete + '\'' +
            "}";
    }
}