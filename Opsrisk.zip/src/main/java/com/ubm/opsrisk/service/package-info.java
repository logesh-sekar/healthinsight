/**
 * Service layer beans.
 */
package com.ubm.opsrisk.service;
