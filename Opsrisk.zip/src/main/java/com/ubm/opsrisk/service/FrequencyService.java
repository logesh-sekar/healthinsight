package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.Frequency;
import com.ubm.opsrisk.repository.FrequencyRepository;
import com.ubm.opsrisk.service.dto.FrequencyDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class FrequencyService {

    private final Logger log = LoggerFactory.getLogger(FrequencyService.class);

    private final FrequencyRepository frequencyRepository;

    public FrequencyService(FrequencyRepository frequencyRepository) {
        this.frequencyRepository = frequencyRepository;
     }

    public Frequency createFrequency(FrequencyDTO frequencyDTO) {
        Frequency frequency = new Frequency();
        frequency.setFrequencyLabel(frequencyDTO.getFrequencyLabel());
        frequency.setFrequencyName(frequencyDTO.getFrequencyName());
        frequency.setFrequencyDescription(frequencyDTO.getFrequencyDescription());
        frequency.setFrequencyLower(frequencyDTO.getFrequencyLower());
        frequency.setFrequencyUpper(frequencyDTO.getFrequencyUpper());
        frequencyRepository.save(frequency);
        log.debug("Created Information for Frequency: {}", frequency);
        return frequency;
    }


    /**
     * Update all information for a specific frequency, and return the modified frequency.
     *
     * @param frequencyDTO frequency to update
     * @return updated frequency
     */
    public Optional<FrequencyDTO> updateFrequency(FrequencyDTO frequencyDTO) {
        return Optional.of(frequencyRepository
            .findByFrequencyRefId(frequencyDTO.getFrequencyRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(frequency -> {
            	frequency.setFrequencyLabel(frequencyDTO.getFrequencyLabel());
                frequency.setFrequencyName(frequencyDTO.getFrequencyName());
                frequency.setFrequencyDescription(frequencyDTO.getFrequencyDescription());
                frequency.setFrequencyLower(frequencyDTO.getFrequencyLower());
                frequency.setFrequencyUpper(frequencyDTO.getFrequencyUpper());
                frequency.setIsDelete(frequencyDTO.getIsDelete());
                log.debug("Changed Information for Frequency: {}", frequency);
                return frequency;
            })
            .map(FrequencyDTO::new);
    }

    public void deleteFrequency(Long frequencyId) {
        frequencyRepository.findByFrequencyRefId(frequencyId).ifPresent(frequency -> {
        	frequency.setIsDelete(true);
            frequencyRepository.save(frequency);
            log.debug("Deleted Frequency: {}", frequency);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<FrequencyDTO> getAllFrequencies(Pageable pageable) {
        return frequencyRepository.findAll(pageable).map(FrequencyDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<FrequencyDTO> getAllActiveFrequencies(Pageable pageable) {
        return frequencyRepository.findAllByIsDelete(false, pageable).map(FrequencyDTO::new);
    }
}

