package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.FModeRef;
import com.ubm.opsrisk.repository.FModeRefRepository;
import com.ubm.opsrisk.service.dto.FModeRefDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class FModeRefService {

    private final Logger log = LoggerFactory.getLogger(FModeRefService.class);

    private final FModeRefRepository fModeRefRepository;

    public FModeRefService(FModeRefRepository fModeRefRepository) {
        this.fModeRefRepository = fModeRefRepository;
     }

    public FModeRef createFModeRef(FModeRefDTO fModeRefDTO) {
        FModeRef fModeRef = new FModeRef();
        fModeRef.setFmodeLevel1(fModeRefDTO.getFmodeLevel1());
        fModeRef.setFmodeLevel2(fModeRefDTO.getFmodeLevel2());
        fModeRef.setFmodeLevel3(fModeRefDTO.getFmodeLevel3());
        fModeRef.setFmodeDescription(fModeRefDTO.getFmodeDescription());
        fModeRefRepository.save(fModeRef);
        log.debug("Created Information for FModeRef: {}", fModeRef);
        return fModeRef;
    }


    /**
     * Update all information for a specific fModeRef, and return the modified fModeRef.
     *
     * @param fModeRefDTO fModeRef to update
     * @return updated fModeRef
     */
    public Optional<FModeRefDTO> updateFModeRef(FModeRefDTO fModeRefDTO) {
        return Optional.of(fModeRefRepository
            .findByFmodeId(fModeRefDTO.getFmodeId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(fModeRef -> {
            	fModeRef.setFmodeLevel1(fModeRefDTO.getFmodeLevel1());
                fModeRef.setFmodeLevel2(fModeRefDTO.getFmodeLevel2());
                fModeRef.setFmodeLevel3(fModeRefDTO.getFmodeLevel3());
                fModeRef.setFmodeDescription(fModeRefDTO.getFmodeDescription());
                fModeRef.setIsDelete(fModeRefDTO.getIsDelete());
                log.debug("Changed Information for FModeRef: {}", fModeRef);
                return fModeRef;
            })
            .map(FModeRefDTO::new);
    }

    public void deleteFModeRef(Long fModeRefId) {
        fModeRefRepository.findByFmodeId(fModeRefId).ifPresent(fModeRef -> {
        	fModeRef.setIsDelete(true);
            fModeRefRepository.save(fModeRef);
            log.debug("Deleted FModeRef: {}", fModeRef);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<FModeRefDTO> getAllFModeRef(Pageable pageable) {
        return fModeRefRepository.findAll(pageable).map(FModeRefDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<FModeRefDTO> getAllActiveFModeRef(Pageable pageable) {
        return fModeRefRepository.findAllByIsDelete(false, pageable).map(FModeRefDTO::new);
    }
}

