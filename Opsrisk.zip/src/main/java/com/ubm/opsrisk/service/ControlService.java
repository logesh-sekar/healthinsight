package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.Control;
import com.ubm.opsrisk.repository.ControlRepository;
import com.ubm.opsrisk.service.dto.ControlDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class ControlService {

    private final Logger log = LoggerFactory.getLogger(ControlService.class);

    private final ControlRepository controlRepository;

    public ControlService(ControlRepository controlRepository) {
        this.controlRepository = controlRepository;
     }

    public Control createControl(ControlDTO controlDTO) {
        Control control = new Control();
        control.setFmodeRefId(controlDTO.getFmodeRefId());
        control.setPolicyRefId(controlDTO.getPolicyRefId());
        control.setControlMinimumStandardId(controlDTO.getControlMinimumStandardId());
        control.setControlName(controlDTO.getControlName());
        control.setControlDescription(controlDTO.getControlDescription());
        control.setControlReleveantProcess(controlDTO.getControlReleveantProcess());
        control.setControlPurpose(controlDTO.getControlPurpose());
        control.setControlType(controlDTO.getControlType());
        controlRepository.save(control);
        log.debug("Created Information for Control: {}", control);
        return control;
    }


    /**
     * Update all information for a specific policy, and return the modified policy.
     *
     * @param controlDTO policy to update
     * @return updated policy
     */
    public Optional<ControlDTO> updateControl(ControlDTO controlDTO) {
        return Optional.of(controlRepository
            .findByControlRefId(controlDTO.getControlRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(control -> {
            	control.setFmodeRefId(controlDTO.getFmodeRefId());
                control.setPolicyRefId(controlDTO.getPolicyRefId());
                control.setControlMinimumStandardId(controlDTO.getControlMinimumStandardId());
                control.setControlName(controlDTO.getControlName());
                control.setControlDescription(controlDTO.getControlDescription());
                control.setControlReleveantProcess(controlDTO.getControlReleveantProcess());
                control.setControlPurpose(controlDTO.getControlPurpose());
                control.setControlType(controlDTO.getControlType());
                control.setIsDelete(controlDTO.getIsDelete());
                log.debug("Changed Information for Control: {}", control);
                return control;
            })
            .map(ControlDTO::new);
    }

    public void deleteControl(String controlRefId) {
        controlRepository.findByControlRefId(controlRefId).ifPresent(control -> {
        	control.setIsDelete(true);
            controlRepository.save(control);
            log.debug("Deleted Control: {}", control);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<ControlDTO> getAllControls(Pageable pageable) {
        return controlRepository.findAll(pageable).map(ControlDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<ControlDTO> getAllActiveControl(Pageable pageable) {
        return controlRepository.findAllByIsDelete(false, pageable).map(ControlDTO::new);
    }
}

