package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.FMechRefDet;
import com.ubm.opsrisk.repository.FMechRefDetRepository;
import com.ubm.opsrisk.service.dto.FMechRefDetDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class FMechRefDetService {

    private final Logger log = LoggerFactory.getLogger(FMechRefDetService.class);

    private final FMechRefDetRepository fMechRefDetRepository;

    public FMechRefDetService(FMechRefDetRepository fMechRefDetRepository) {
        this.fMechRefDetRepository = fMechRefDetRepository;
     }

    public FMechRefDet createFMechRefDet(FMechRefDetDTO fMechRefDetDTO) {
    	FMechRefDet fMechRefDet = new FMechRefDet();
    	fMechRefDet.setFmechRefDetDescription(fMechRefDetDTO.getFmechRefDetDescription());
    	fMechRefDet.setFmechRefDetLevel(fMechRefDetDTO.getFmechRefDetLevel());
        fMechRefDetRepository.save(fMechRefDet);
        log.debug("Created Information for fMechRefDet: {}", fMechRefDet);
        return fMechRefDet;
    }


    /**
     * Update all information for a specific policy, and return the modified policy.
     *
     * @param policyDTO policy to update
     * @return updated policy
     */
    public Optional<FMechRefDetDTO> updateFMechRefDet(FMechRefDetDTO fMechRefDetDTO) {
        return Optional.of(fMechRefDetRepository
            .findByFmechRefDetId(fMechRefDetDTO.getFmechRefDetId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(fMechRefDet -> {
            	fMechRefDet.setFmechRefDetDescription(fMechRefDetDTO.getFmechRefDetDescription());
            	fMechRefDet.setFmechRefDetLevel(fMechRefDetDTO.getFmechRefDetLevel());
            	fMechRefDet.setIsDelete(fMechRefDetDTO.getIsDelete());
                log.debug("Changed Information for fMechRefDet: {}", fMechRefDet);
                return fMechRefDet;
            })
            .map(FMechRefDetDTO::new);
    }

    public void deleteFMechRefDat(Long fmechRefDetId) {
    	fMechRefDetRepository.findByFmechRefDetId(fmechRefDetId).ifPresent(fMechRefDet -> {
    		fMechRefDet.setIsDelete(true);
        	fMechRefDetRepository.save(fMechRefDet);
            log.debug("Deleted fMechRefDet: {}", fMechRefDet);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<FMechRefDetDTO> getAllFMechRefDet(Pageable pageable) {
        return fMechRefDetRepository.findAll(pageable).map(FMechRefDetDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<FMechRefDetDTO> getAllActiveFMechRefDet(Pageable pageable) {
        return fMechRefDetRepository.findAllByIsDelete(false, pageable).map(FMechRefDetDTO::new);
    }
}

