package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.RiskCube;
import com.ubm.opsrisk.repository.RiskCubeRepository;
import com.ubm.opsrisk.service.dto.RiskCubeDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class RiskCubeService {

    private final Logger log = LoggerFactory.getLogger(RiskCubeService.class);

    private final RiskCubeRepository riskCubeRepository;

    public RiskCubeService(RiskCubeRepository riskCubeRepository) {
        this.riskCubeRepository = riskCubeRepository;
     }

    public RiskCube createRiskCube(RiskCubeDTO riskCubeDTO) {
        RiskCube riskCube = new RiskCube();
        riskCube.setFinmatRefId(riskCubeDTO.getFinmatRefId());
        riskCube.setFrequencyRefId(riskCubeDTO.getFrequencyRefId());
        riskCube.setFrequencyRiskLevel(riskCubeDTO.getFrequencyRiskLevel());
        riskCube.setFrequencyAction(riskCubeDTO.getFrequencyAction());
        riskCube.setFrequencyRag(riskCubeDTO.getFrequencyRag());
        riskCubeRepository.save(riskCube);
        log.debug("Created Information for RiskCube: {}", riskCube);
        return riskCube;
    }


    /**
     * Update all information for a specific riskCube, and return the modified riskCube.
     *
     * @param riskCubeDTO riskCube to update
     * @return updated riskCube
     */
    public Optional<RiskCubeDTO> updateRiskCube(RiskCubeDTO riskCubeDTO) {
        return Optional.of(riskCubeRepository
            .findByRiskcubeRefId(riskCubeDTO.getRiskcubeRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(riskCube -> {
            	riskCube.setFinmatRefId(riskCubeDTO.getFinmatRefId());
                riskCube.setFrequencyRefId(riskCubeDTO.getFrequencyRefId());
                riskCube.setFrequencyRiskLevel(riskCubeDTO.getFrequencyRiskLevel());
                riskCube.setFrequencyAction(riskCubeDTO.getFrequencyAction());
                riskCube.setFrequencyRag(riskCubeDTO.getFrequencyRag());
                riskCube.setIsDelete(riskCubeDTO.getIsDelete());
                log.debug("Changed Information for RiskCube: {}", riskCube);
                return riskCube;
            })
            .map(RiskCubeDTO::new);
    }

    public void deleteRiskCube(Long riskCubeId) {
        riskCubeRepository.findByRiskcubeRefId(riskCubeId).ifPresent(riskCube -> {
        	riskCube.setIsDelete(true);
            riskCubeRepository.save(riskCube);
            log.debug("Deleted RiskCube: {}", riskCube);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<RiskCubeDTO> getAllRiskCube(Pageable pageable) {
        return riskCubeRepository.findAll(pageable).map(RiskCubeDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<RiskCubeDTO> getAllActiveRiskCube(Pageable pageable) {
        return riskCubeRepository.findAllByIsDelete(false, pageable).map(RiskCubeDTO::new);
    }
}

