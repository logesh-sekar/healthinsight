package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.Frequency;


/**
 * A DTO representing a user, with his authorities.
 */
public class FrequencyDTO {
	private Long frequencyRefId;
    private String frequencyLabel;
    private String frequencyName;
    private String frequencyDescription;
    private Double frequencyUpper;
    private Double frequencyLower;
    private boolean isDelete;
    
    public Long getFrequencyRefId() {
        return frequencyRefId;
    }

    public void setFrequencyRefId(Long frequencyRefId) {
        this.frequencyRefId = frequencyRefId;
    }
    public String getFrequencyLabel() {
        return frequencyLabel;
    }

    public void setFrequencyLabel(String frequencyLabel) {
        this.frequencyLabel = frequencyLabel;
    }
    
    public String getFrequencyName() {
        return frequencyName;
    }

    public void setFrequencyName(String frequencyName) {
        this.frequencyName = frequencyName;
    }

    public String getFrequencyDescription() {
        return frequencyDescription;
    }

    public void setFrequencyDescription(String frequencyDescription) {
        this.frequencyDescription = frequencyDescription;
    }
    
    public Double getFrequencyUpper() {
        return frequencyUpper;
    }

    public void setFrequencyUpper(Double frequencyUpper) {
        this.frequencyUpper = frequencyUpper;
    }
    
    public Double getFrequencyLower() {
        return frequencyLower;
    }

    public void setFrequencyLower(Double frequencyLower) {
        this.frequencyLower = frequencyLower;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public FrequencyDTO() {
    	
    }
    
    public FrequencyDTO(Frequency freq) {
    	this.frequencyRefId = freq.getFrequencyRefId();
    	this.frequencyLabel = freq.getFrequencyLabel();
    	this.frequencyName = freq.getFrequencyName();
    	this.frequencyDescription = freq.getFrequencyDescription();
    	this.frequencyLower = freq.getFrequencyLower();
    	this.frequencyUpper = freq.getFrequencyUpper();
    	this.isDelete = freq.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "Frequency{" +
            " frequencyLabel='" + frequencyLabel + '\'' +
            ", frequencyName='" + frequencyName + '\'' +
            ", frequencyDescription='" + frequencyDescription + '\'' +
            ", frequencyUpper='" + frequencyUpper + '\'' +
            ", frequencyLower='" + frequencyLower + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
