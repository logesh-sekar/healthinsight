package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.RiskCube;


/**
 * A DTO representing a user, with his authorities.
 */
public class RiskCubeDTO {
	private Long riskcubeRefId;
    private Long finmatRefId;
    private Long frequencyRefId;
    private String frequencyRiskLevel;
    private String frequencyRag;
    private String frequencyAction;
    private boolean isDelete;
    
    public Long getRiskcubeRefId() {
        return riskcubeRefId;
    }

    public void setRiskcubeRefId(Long riskcubeRefId) {
        this.riskcubeRefId = riskcubeRefId;
    }
    
    public Long getFinmatRefId() {
        return finmatRefId;
    }

    public void setFinmatRefId(Long finmatRefId) {
        this.finmatRefId = finmatRefId;
    }
    
    public Long getFrequencyRefId() {
        return frequencyRefId;
    }

    public void setFrequencyRefId(Long frequencyRefId) {
        this.frequencyRefId = frequencyRefId;
    }


    public String getFrequencyRiskLevel() {
        return frequencyRiskLevel;
    }

    public void setFrequencyRiskLevel(String frequencyRiskLevel) {
        this.frequencyRiskLevel = frequencyRiskLevel;
    }

    public String getFrequencyRag() {
        return frequencyRag;
    }

    public void setFrequencyRag(String frequencyRag) {
        this.frequencyRag = frequencyRag;
    }

    public String getFrequencyAction() {
        return frequencyAction;
    }

    public void setFrequencyAction(String frequencyAction) {
        this.frequencyAction = frequencyAction;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public RiskCubeDTO() {
    	
    }
    
    public RiskCubeDTO(RiskCube riskcube) {
    	this.riskcubeRefId = riskcube.getRiskcubeRefId();
    	this.finmatRefId = riskcube.getFinmatRefId();
    	this.frequencyRefId = riskcube.getFrequencyRefId();
    	this.frequencyRiskLevel = riskcube.getFrequencyRiskLevel();
    	this.frequencyAction = riskcube.getFrequencyAction();
    	this.frequencyRag = riskcube.getFrequencyRag();
    	this.isDelete = riskcube.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "RiskCube{" +
        	"finmatRefId='" + finmatRefId + '\'' +
            ", frequencyRefId='" + frequencyRefId + '\'' +
            ", frequencyRiskLevel='" + frequencyRiskLevel + '\'' +
            ", frequencyRag='" + frequencyRag + '\'' +
            ", frequencyAction='" + frequencyAction + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
