package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.Policy;
import com.ubm.opsrisk.repository.PolicyRepository;
import com.ubm.opsrisk.service.dto.PolicyDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class PolicyService {

    private final Logger log = LoggerFactory.getLogger(PolicyService.class);

    private final PolicyRepository policyRepository;

    public PolicyService(PolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
     }

    public Policy createPolicy(PolicyDTO policyDTO) {
        Policy policy = new Policy();
        policy.setPolicyName(policyDTO.getPolicyName());
        policy.setPolicyDescription(policyDTO.getPolicyDescription());
        policy.setPolicyLink(policyDTO.getPolicyLink());
        policyRepository.save(policy);
        log.debug("Created Information for Policy: {}", policy);
        return policy;
    }


    /**
     * Update all information for a specific policy, and return the modified policy.
     *
     * @param policyDTO policy to update
     * @return updated policy
     */
    public Optional<PolicyDTO> updatePolicy(PolicyDTO policyDTO) {
        return Optional.of(policyRepository
            .findByPolicyId(policyDTO.getPolicyId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(policy -> {
            	policy.setPolicyName(policyDTO.getPolicyName());
                policy.setPolicyDescription(policyDTO.getPolicyDescription());
                policy.setPolicyLink(policyDTO.getPolicyLink());
                policy.setIsDelete(policyDTO.getIsDelete());
                log.debug("Changed Information for Policy: {}", policy);
                return policy;
            })
            .map(PolicyDTO::new);
    }

    public void deletePolicy(Long policyId) {
        policyRepository.findByPolicyId(policyId).ifPresent(policy -> {
        	policy.setIsDelete(true);
            policyRepository.save(policy);
            log.debug("Deleted Policy: {}", policy);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<PolicyDTO> getAllPolicies(Pageable pageable) {
        return policyRepository.findAll(pageable).map(PolicyDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<PolicyDTO> getAllActivePolicies(Pageable pageable) {
        return policyRepository.findAllByIsDelete(false, pageable).map(PolicyDTO::new);
    }
}

