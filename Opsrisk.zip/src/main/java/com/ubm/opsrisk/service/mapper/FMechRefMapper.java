package com.ubm.opsrisk.service.mapper;

import com.ubm.opsrisk.domain.Policy;
import com.ubm.opsrisk.service.dto.PolicyDTO;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Mapper for the entity Policy and its DTO called PolicyDTO.
 *
 * Normal mappers are generated using MapStruct, this one is hand-coded as MapStruct
 * support is still in beta, and requires a manual step with an IDE.
 */
@Service
public class FMechRefMapper {

    public PolicyDTO policyToPolicyDTO(Policy policy) {
        return new PolicyDTO(policy);
    }

    public List<PolicyDTO> policiesToPolicyDTOs(List<Policy> policies) {
        return policies.stream()
            .filter(Objects::nonNull)
            .map(this::policyToPolicyDTO)
            .collect(Collectors.toList());
    }

    public Policy policyDTOToPolicy(PolicyDTO policyDTO) {
        if (policyDTO == null) {
            return null;
        } else {
            Policy policy = new Policy();
            policy.setPolicyId(policyDTO.getPolicyId());
            policy.setPolicyName(policyDTO.getPolicyName());
            policy.setPolicyDescription(policyDTO.getPolicyDescription());
            policy.setPolicyLink(policyDTO.getPolicyLink());
            policy.setIsDelete(policyDTO.getIsDelete());
            return policy;
        }
    }

    public List<Policy> policyDTOsToPolicies(List<PolicyDTO> policyDTOs) {
        return policyDTOs.stream()
            .filter(Objects::nonNull)
            .map(this::policyDTOToPolicy)
            .collect(Collectors.toList());
    }

    public Policy policyFromId(Long id) {
        if (id == null) {
            return null;
        }
        Policy policy = new Policy();
        policy.setPolicyId(id);
        return policy;
    }
}
