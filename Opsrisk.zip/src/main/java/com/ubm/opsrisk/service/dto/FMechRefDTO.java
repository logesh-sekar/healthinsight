package com.ubm.opsrisk.service.dto;


import com.ubm.opsrisk.domain.FMechRef;



/**
 * A DTO representing a user, with his authorities.
 */
public class FMechRefDTO {
	private Long fmechRefId;
    private String fmechDescription;
    private String fmechType;
    private boolean isDelete;
    
    public Long getFmechRefId() {
        return fmechRefId;
    }

    public void setFmechRefId(Long fmechRefId) {
        this.fmechRefId = fmechRefId;
    }

    public String getFmechDetDescription() {
        return fmechDescription;
    }

    public void setFmechDetDescription(String fmechDescription) {
        this.fmechDescription = fmechDescription;
    }

    public String getFmechType() {
        return fmechType;
    }

    public void setFmechType(String fmechType) {
        this.fmechType = fmechType;
    }

    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public FMechRefDTO() {
    	
    }
    
    public FMechRefDTO(FMechRef fMechRef) {
    	this.fmechRefId = fMechRef.getFmechRefId();
    	this.fmechDescription = fMechRef.getFmechDetDescription();
		this.fmechType = fMechRef.getFmechType();
		this.isDelete = fMechRef.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "FMechRef{" +
            " fmechDescription='" + fmechDescription + '\'' +
            ", fmechType='" + fmechType + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
