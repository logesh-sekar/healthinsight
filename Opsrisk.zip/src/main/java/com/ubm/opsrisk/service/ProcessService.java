package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.Process;
import com.ubm.opsrisk.repository.ProcessRepository;
import com.ubm.opsrisk.service.dto.ProcessDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class ProcessService {

    private final Logger log = LoggerFactory.getLogger(ProcessService.class);

    private final ProcessRepository processRepository;

    public ProcessService(ProcessRepository processRepository) {
        this.processRepository = processRepository;
     }

    public Process createProcess(ProcessDTO processDTO) {
        Process process = new Process();
        process.setProcessId(processDTO.getProcessId());
        process.setProcessStepId(processDTO.getProcessStepId());
        process.setProcessDescription(processDTO.getProcessDescription());
        process.setProcessStepDescription(processDTO.getProcessStepDescription());
        processRepository.save(process);
        log.debug("Created Information for Process: {}", process);
        return process;
    }


    /**
     * Update all information for a specific process, and return the modified process.
     *
     * @param processDTO process to update
     * @return updated process
     */
    public Optional<ProcessDTO> updateProcess(ProcessDTO processDTO) {
        return Optional.of(processRepository
            .findByProcessRefId(processDTO.getProcessRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(process -> {
            	process.setProcessId(processDTO.getProcessId());
                process.setProcessStepId(processDTO.getProcessStepId());
                process.setProcessDescription(processDTO.getProcessDescription());
                process.setProcessStepDescription(processDTO.getProcessStepDescription());
                process.setIsDelete(processDTO.getIsDelete());
                log.debug("Changed Information for Process: {}", process);
                return process;
            })
            .map(ProcessDTO::new);
    }

    public void deleteProcess(Long processId) {
        processRepository.findByProcessRefId(processId).ifPresent(process -> {
        	process.setIsDelete(true);
            processRepository.save(process);
            log.debug("Deleted Process: {}", process);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<ProcessDTO> getAllPolicies(Pageable pageable) {
        return processRepository.findAll(pageable).map(ProcessDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<ProcessDTO> getAllActivePolicies(Pageable pageable) {
        return processRepository.findAllByIsDelete(false, pageable).map(ProcessDTO::new);
    }
}

