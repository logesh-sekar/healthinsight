package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.Kra;



/**
 * A DTO representing a user, with his authorities.
 */
public class KraDTO {
	private Long kraId;
    private String kraLabel;
    private String kraDescription;
    private boolean isDelete;
    
    public Long getKraId() {
        return kraId;
    }

    public void setKraId(Long kraId) {
        this.kraId = kraId;
    }

    public String getKraLabel() {
        return kraLabel;
    }

    public void setKraLabel(String kraLabel) {
        this.kraLabel = kraLabel;
    }

    public String getKraDescription() {
        return kraDescription;
    }

    public void setKraDescription(String kraDescription) {
        this.kraDescription = kraDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public KraDTO() {
    	
    }
    
    public KraDTO(Kra kra) {
    	this.kraId = kra.getKraId();
    	this.kraLabel = kra.getKraLabel();
    	this.kraDescription = kra.getKraDescription();
    	this.isDelete = kra.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "KRA{" +
            "kraLabel='" + kraLabel + '\'' +
            ", kraDescription='" + kraDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
