package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.Process;


/**
 * A DTO representing a user, with his authorities.
 */
public class ProcessDTO {
	private Long processRefId;
    private Long processId;
    private String processStepId;
    private String processDescription;
    private String processStepDescription;
    private boolean isDelete;
    
    public Long getProcessId() {
        return processId;
    }

    public void setProcessId(Long processId) {
        this.processId = processId;
    }
    
    public Long getProcessRefId() {
        return processRefId;
    }

    public void getProcessRefId(Long processRefId) {
        this.processRefId = processRefId;
    }

    public String getProcessStepId() {
        return processStepId;
    }

    public void setProcessStepId(String processStepId) {
        this.processStepId = processStepId;
    }

    public String getProcessStepDescription() {
        return processStepDescription;
    }

    public void setProcessStepDescription(String processStepDescription) {
        this.processStepDescription = processStepDescription;
    }

    public String getProcessDescription() {
        return processDescription;
    }

    public void setProcessDescription(String processDescription) {
        this.processDescription = processDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public ProcessDTO() {
    	
    }
    
    public ProcessDTO(Process process) {
    	this.processRefId = process.getProcessRefId();
    	this.processId = process.getProcessId();
    	this.processStepId = process.getProcessStepId();
    	this.processDescription = process.getProcessDescription();
    	this.processStepDescription = process.getProcessStepDescription();
    	this.isDelete = process.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "Process{" +
            "  processId='" + processId + '\'' +
            ", processStepId='" + processStepId + '\'' +
            ", processStepDescription='" + processStepDescription + '\'' +
            ", processDescription='" + processDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
