package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.Policy;



/**
 * A DTO representing a user, with his authorities.
 */
public class PolicyDTO {
    private Long policyId;

    private String policyName;

    private String policyLink;

    private String policyDescription;
    
    private boolean isDelete;

    public PolicyDTO() {
        // Empty constructor needed for Jackson.
    }

    public PolicyDTO(Policy policy) {
        this.policyId = policy.getPolicyId();
        this.policyName = policy.getPolicyName();
        this.policyDescription = policy.getPolicyDescription();
        this.policyLink = policy.getPolicyLink();
        this.isDelete = policy.getIsDelete();
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getPolicyLink() {
        return policyLink;
    }

    public void setPolicyLink(String policyLink) {
        this.policyLink = policyLink;
    }

    public String getPolicyDescription() {
        return policyDescription;
    }

    public void setPolicyDescription(String policyDescription) {
        this.policyDescription = policyDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }

    @Override
    public String toString() {
        return "PolicyDTO{" +
        		"policyName='" + policyName + '\'' +
                ", policyLink='" + policyLink + '\'' +
                ", policyDescription='" + policyDescription + '\'' +
                 "}";
    }
}
