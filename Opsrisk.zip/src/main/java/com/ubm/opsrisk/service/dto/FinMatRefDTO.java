package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.FinMatRef;



/**
 * A DTO representing a user, with his authorities.
 */
public class FinMatRefDTO {
private Long finmatRefId;
    
    private String finmatLevel;

    private String finmatLabel;
    
    private String finmatExtImpactDescription;

    private String finmatRegImpactDescription;
    
    private String finmatBrand;
    
    private Double finmatUpperThreshold;
    
    private Double finmatLowerThreshold;
        
    private boolean isDelete;
    
    public Long getFinmatRefId() {
        return finmatRefId;
    }

    public void setFinmatRefId(Long finmatRefId) {
        this.finmatRefId = finmatRefId;
    }
    
    public String getFinmatLevel() {
        return finmatLevel;
    }

    public void setFinmatLevel(String finmatLevel) {
        this.finmatLevel = finmatLevel;
    }

    public String getFinmatLabel() {
        return finmatLabel;
    }

    public void setFinmatLabel(String finmatLabel) {
        this.finmatLabel = finmatLabel;
    }
    
    public String getFinmatExtImpactDescription() {
        return finmatExtImpactDescription;
    }

    public void setFinmatExtImpactDescription(String finmatExtImpactDescription) {
        this.finmatExtImpactDescription = finmatExtImpactDescription;
    }

    public String getFinmatRegImpactDescription() {
        return finmatRegImpactDescription;
    }

    public void setFinmatRegImpactDescription(String finmatRegImpactDescription) {
        this.finmatRegImpactDescription = finmatRegImpactDescription;
    }

    public String getFinmatBrand() {
        return finmatBrand;
    }

    public void setFinmatBrand(String finmatBrand) {
        this.finmatBrand = finmatBrand;
    }

    public Double getFinmatUpperThreshold() {
        return finmatUpperThreshold;
    }

    public void setFinmatUpperThreshold(Double finmatUpperThreshold) {
        this.finmatUpperThreshold = finmatUpperThreshold;
    }
    
    public Double getFinmatLowerThreshold() {
        return finmatLowerThreshold;
    }

    public void setFinmatLowerThreshold(Double finmatLowerThreshold) {
        this.finmatLowerThreshold = finmatLowerThreshold;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public FinMatRefDTO() {
        // Empty constructor needed for Jackson.
    }

    public FinMatRefDTO(FinMatRef finmatRef) {
        this.finmatRefId = finmatRef.getFinmatRefId();
        this.finmatLevel = finmatRef.getFinmatLevel();
        this.finmatLabel = finmatRef.getFinmatLabel();
        this.finmatExtImpactDescription = finmatRef.getFinmatExtImpactDescription();
        this.finmatRegImpactDescription = finmatRef.getFinmatRegImpactDescription();
        this.finmatBrand = finmatRef.getFinmatBrand();
        this.finmatUpperThreshold = finmatRef.getFinmatUpperThreshold();
        this.finmatLowerThreshold = finmatRef.getFinmatLowerThreshold();
        this.isDelete = finmatRef.getIsDelete();
    }

    @Override
    public String toString() {
        return "FinMatRef{" +
        		" finmatLevel='" + finmatLevel + '\'' +
        		", finmatLabel='" + finmatLabel + '\'' +
        		", finmatExtImpactDescription='" + finmatExtImpactDescription + '\'' +
        		", finmatRegImpactDescription='" + finmatRegImpactDescription + '\'' +
        		", finmatBrand='" + finmatBrand + '\'' +
        		", finmatUpperThreshold='" + finmatUpperThreshold + '\'' +
        		", finmatLowerThreshold='" + finmatLowerThreshold + '\'' +
        		", isDelete='" + isDelete + '\'' +
            "}";
    }
}
