package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.FMechRef;
import com.ubm.opsrisk.repository.FMechRefRepository;
import com.ubm.opsrisk.service.dto.FMechRefDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class FMechRefService {

    private final Logger log = LoggerFactory.getLogger(FMechRefService.class);

    private final FMechRefRepository fMechRefRepository;

    public FMechRefService(FMechRefRepository fMechRefRepository) {
        this.fMechRefRepository = fMechRefRepository;
     }

    public FMechRef createFMechRef(FMechRefDTO fMechRefDTO) {
    	FMechRef fMechRef = new FMechRef();
    	fMechRef.setFmechDetDescription(fMechRefDTO.getFmechDetDescription());
    	fMechRef.setFmechType(fMechRefDTO.getFmechType());
        fMechRefRepository.save(fMechRef);
        log.debug("Created Information for fMechRef: {}", fMechRef);
        return fMechRef;
    }


    /**
     * Update all information for a specific policy, and return the modified policy.
     *
     * @param fMechRefDTO policy to update
     * @return updated policy
     */
    public Optional<FMechRefDTO> updateFMechRef(FMechRefDTO fMechRefDTO) {
        return Optional.of(fMechRefRepository
            .findByFmechRefId(fMechRefDTO.getFmechRefId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(fMechRef -> {
            	fMechRef.setFmechDetDescription(fMechRefDTO.getFmechDetDescription());
            	fMechRef.setFmechType(fMechRefDTO.getFmechType());
            	fMechRef.setIsDelete(fMechRefDTO.getIsDelete());
                log.debug("Changed Information for fMechRef: {}", fMechRef);
                return fMechRef;
            })
            .map(FMechRefDTO::new);
    }

    public void deleteFMechRef(Long fmechRefId) {
        fMechRefRepository.findByFmechRefId(fmechRefId).ifPresent(fMechRef -> {
        	fMechRef.setIsDelete(true);
            fMechRefRepository.save(fMechRef);
            log.debug("Deleted fMechRef: {}", fMechRef);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<FMechRefDTO> getAllFMechRef(Pageable pageable) {
        return fMechRefRepository.findAll(pageable).map(FMechRefDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<FMechRefDTO> getAllActiveFMechRef(Pageable pageable) {
        return fMechRefRepository.findAllByIsDelete(false, pageable).map(FMechRefDTO::new);
    }
}

