package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.FModeRef;


/**
 * A DTO representing a user, with his authorities.
 */
public class FModeRefDTO {
	private Long fmodeId;
    private String fmodeLevel1;
    private String fmodeLevel2;
    private String fmodeLevel3;
    private String fmodeDescription;
    private boolean isDelete;
    
    public Long getFmodeId() {
        return fmodeId;
    }

    public void setFmodeId(Long fmodeId) {
        this.fmodeId = fmodeId;
    }

    public String getFmodeLevel1() {
        return fmodeLevel1;
    }

    public void setFmodeLevel1(String fmodeLevel1) {
        this.fmodeLevel1 = fmodeLevel1;
    }

    public String getFmodeLevel2() {
        return fmodeLevel2;
    }

    public void setFmodeLevel2(String fmodeLevel2) {
        this.fmodeLevel2 = fmodeLevel2;
    }
    public String getFmodeLevel3() {
        return fmodeLevel3;
    }

    public void setFmodeLevel3(String fmodeLevel3) {
        this.fmodeLevel3 = fmodeLevel3;
    }

    public String getFmodeDescription() {
        return fmodeDescription;
    }

    public void setFmodeDescription(String fmodeDescription) {
        this.fmodeDescription = fmodeDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public FModeRefDTO() {
    	
    }
    
    public FModeRefDTO(FModeRef fmodeRef) {
    	this.fmodeId = fmodeRef.getFmodeId();
    	this.fmodeLevel1 = fmodeRef.getFmodeLevel1();
		this.fmodeLevel2 = fmodeRef.getFmodeLevel2();
		this.fmodeLevel3 = fmodeRef.getFmodeLevel3();
		this.fmodeDescription = fmodeRef.getFmodeDescription();
		this.isDelete = fmodeRef.getIsDelete();
    }
    
    @Override
    public String toString() {
        return "fmode{" +
            " fmodeLevel1='" + fmodeLevel1 + '\'' +
            ", fmodeLevel2='" + fmodeLevel2 + '\'' +
            ", fmodeLevel3='" + fmodeLevel3 + '\'' +
            ", fmodeDescription='" + fmodeDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
