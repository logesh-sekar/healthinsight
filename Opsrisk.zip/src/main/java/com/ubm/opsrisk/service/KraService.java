package com.ubm.opsrisk.service;

import com.ubm.opsrisk.domain.Kra;
import com.ubm.opsrisk.repository.KraRepository;
import com.ubm.opsrisk.service.dto.KraDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * Service class for managing policies.
 */
@Service
@Transactional
public class KraService {

    private final Logger log = LoggerFactory.getLogger(KraService.class);

    private final KraRepository kraRepository;

    public KraService(KraRepository kraRepository) {
        this.kraRepository = kraRepository;
     }

    public Kra createKra(KraDTO kraDTO) {
        Kra kra = new Kra();
        kra.setKraLabel(kraDTO.getKraLabel());
        kra.setKraDescription(kraDTO.getKraDescription());
        kraRepository.save(kra);
        log.debug("Created Information for Kra: {}", kra);
        return kra;
    }


    /**
     * Update all information for a specific kra, and return the modified kra.
     *
     * @param kraDTO kra to update
     * @return updated kra
     */
    public Optional<KraDTO> updateKra(KraDTO kraDTO) {
        return Optional.of(kraRepository
            .findByKraId(kraDTO.getKraId()))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(kra -> {
            	kra.setKraLabel(kraDTO.getKraLabel());
                kra.setKraDescription(kraDTO.getKraDescription());
                kra.setIsDelete(kraDTO.getIsDelete());
                log.debug("Changed Information for Kra: {}", kra);
                return kra;
            })
            .map(KraDTO::new);
    }

    public void deleteKra(Long kraId) {
        kraRepository.findByKraId(kraId).ifPresent(kra -> {
        	kra.setIsDelete(true);
            kraRepository.save(kra);
            log.debug("Deleted Kra: {}", kra);
        });
    }
    
    @Transactional(readOnly = true)
    public Page<KraDTO> getAllKra(Pageable pageable) {
        return kraRepository.findAll(pageable).map(KraDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<KraDTO> getAllActiveKra(Pageable pageable) {
        return kraRepository.findAllByIsDelete(false, pageable).map(KraDTO::new);
    }
}

