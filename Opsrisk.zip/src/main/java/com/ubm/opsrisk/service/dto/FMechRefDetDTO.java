package com.ubm.opsrisk.service.dto;

import com.ubm.opsrisk.domain.FMechRefDet;



/**
 * A DTO representing a user, with his authorities.
 */
public class FMechRefDetDTO {
	private Long fmechRefDetId;
    private String fmechRefDetDescription;
    private String fmechRefDetLevel;
    private boolean isDelete;
    
    public Long getFmechRefDetId() {
        return fmechRefDetId;
    }

    public void setFmechRefDetId(Long fmechRefDetId) {
        this.fmechRefDetId = fmechRefDetId;
    }

    public String getFmechRefDetDescription() {
        return fmechRefDetDescription;
    }

    public void setFmechRefDetDescription(String fmechRefDetDescription) {
        this.fmechRefDetDescription = fmechRefDetDescription;
    }

    public String getFmechRefDetLevel() {
        return fmechRefDetLevel;
    }

    public void setFmechRefDetLevel(String fmechRefDetLevel) {
        this.fmechRefDetLevel = fmechRefDetLevel;
    }

    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    public FMechRefDetDTO() {
    	
    }
    
    public FMechRefDetDTO(FMechRefDet fmechRefDet) {
    	this.fmechRefDetId = fmechRefDet.getFmechRefDetId();
    	this.fmechRefDetDescription = fmechRefDet.getFmechRefDetDescription();
		this.fmechRefDetLevel = fmechRefDet.getFmechRefDetLevel();
		this.isDelete = fmechRefDet.getIsDelete();
    }
    @Override
    public String toString() {
        return "FMechRefDet{" +
            " fmechRefDetDescription='" + fmechRefDetDescription + '\'' +
            ", fmechRefDetLevel='" + fmechRefDetLevel + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
