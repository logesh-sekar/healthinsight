package com.ubm.opsrisk.repository;

import com.ubm.opsrisk.domain.Frequency;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Spring Data JPA repository for the User entity.
 */
@Repository
public interface FrequencyRepository extends JpaRepository<Frequency, Long> {

    Optional<Frequency> findByFrequencyRefId(Long frequencyRefId);
    
    Page<Frequency> findAllByIsDelete(boolean isDelete, Pageable pageable);
    
    Page<Frequency> findAll(Pageable pageable);
}
