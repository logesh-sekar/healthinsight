/**
 * Spring Data JPA repositories.
 */
package com.ubm.opsrisk.repository;
