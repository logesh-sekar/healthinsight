package com.ubm.opsrisk.repository;

import com.ubm.opsrisk.domain.Kra;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Spring Data JPA repository for the User entity.
 */
@Repository
public interface KraRepository extends JpaRepository<Kra, Long> {

    Optional<Kra> findByKraId(Long kraId);
    
    Page<Kra> findAllByIsDelete(boolean isDelete, Pageable pageable);
    
    Page<Kra> findAll(Pageable pageable);
}
