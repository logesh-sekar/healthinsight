package com.ubm.opsrisk.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubm.opsrisk.domain.Fmode;

import java.util.Optional;

/**
 * Spring Data JPA repository for the User entity.
 */
@Repository
public interface FmodeRepository extends JpaRepository<Fmode, Long> {
    
    Page<Fmode> findAll(Pageable pageable);
}
