/**
 * Spring Security configuration.
 */
package com.ubm.opsrisk.security;
