package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "fmech_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FMechRef extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "fmech_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long fmechRefId;

    @Column(name = "fmech_description")
    private String fmechDescription;

    @Column(name = "fmech_type")
    private String fmechType;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getFmechRefId() {
        return fmechRefId;
    }

    public void setFmechRefId(Long fmechRefId) {
        this.fmechRefId = fmechRefId;
    }

    public String getFmechDetDescription() {
        return fmechDescription;
    }

    public void setFmechDetDescription(String fmechDescription) {
        this.fmechDescription = fmechDescription;
    }

    public String getFmechType() {
        return fmechType;
    }

    public void setFmechType(String fmechType) {
        this.fmechType = fmechType;
    }

    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FMechRef fmech = (FMechRef) o;
        return !(fmech.getFmechRefId() == null || getFmechRefId() == null) && Objects.equals(getFmechRefId(), fmech.getFmechRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFmechRefId());
    }

    @Override
    public String toString() {
        return "FMechRef{" +
            " fmechDescription='" + fmechDescription + '\'' +
            ", fmechType='" + fmechType + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
