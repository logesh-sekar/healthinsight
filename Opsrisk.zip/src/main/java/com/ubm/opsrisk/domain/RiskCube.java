package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "riskcube_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class RiskCube extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "riskcube_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long riskcubeRefId;

    @NotNull
    @Column(name = "finmat_ref_id")
    private Long finmatRefId;

    @Column(name = "frequency_ref_id")
    private Long frequencyRefId;

    @Column(name = "frequency_risk_level")
    private String frequencyRiskLevel;
    
    @Column(name = "frequency_rag")
    private String frequencyRag;
    
    @Column(name = "frequency_action")
    private String frequencyAction;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getRiskcubeRefId() {
        return riskcubeRefId;
    }

    public void setRiskcubeRefId(Long riskcubeRefId) {
        this.riskcubeRefId = riskcubeRefId;
    }
    
    public Long getFinmatRefId() {
        return finmatRefId;
    }

    public void setFinmatRefId(Long finmatRefId) {
        this.finmatRefId = finmatRefId;
    }
    
    public Long getFrequencyRefId() {
        return frequencyRefId;
    }

    public void setFrequencyRefId(Long frequencyRefId) {
        this.frequencyRefId = frequencyRefId;
    }

    public String getFrequencyRiskLevel() {
        return frequencyRiskLevel;
    }

    public void setFrequencyRiskLevel(String frequencyRiskLevel) {
        this.frequencyRiskLevel = frequencyRiskLevel;
    }

    public String getFrequencyRag() {
        return frequencyRag;
    }

    public void setFrequencyRag(String frequencyRag) {
        this.frequencyRag = frequencyRag;
    }

    public String getFrequencyAction() {
        return frequencyAction;
    }

    public void setFrequencyAction(String frequencyAction) {
        this.frequencyAction = frequencyAction;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RiskCube risk = (RiskCube) o;
        return !(risk.getRiskcubeRefId() == null || getRiskcubeRefId() == null) && Objects.equals(getRiskcubeRefId(), risk.getRiskcubeRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getRiskcubeRefId());
    }

    @Override
    public String toString() {
        return "RiskCube{" +
            "finmatRefId='" + finmatRefId + '\'' +
            ", frequencyRefId='" + frequencyRefId + '\'' +
            ", frequencyRiskLevel='" + frequencyRiskLevel + '\'' +
            ", frequencyRag='" + frequencyRag + '\'' +
            ", frequencyAction='" + frequencyAction + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
