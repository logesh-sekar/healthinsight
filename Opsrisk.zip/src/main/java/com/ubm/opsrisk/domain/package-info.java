/**
 * JPA domain objects.
 */
package com.ubm.opsrisk.domain;
