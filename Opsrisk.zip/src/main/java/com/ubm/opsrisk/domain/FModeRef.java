package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "fmode_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FModeRef extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "fmode_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long fmodeId;

    @NotNull
    @Column(name = "fmode_ref_level_1")
    private String fmodeLevel1;

    @Column(name = "fmode_ref_level_2")
    private String fmodeLevel2;

    @Column(name = "fmode_ref_level_3")
    private String fmodeLevel3;
    
    @Column(name = "fmode_ref_description")
    private String fmodeDescription;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getFmodeId() {
        return fmodeId;
    }

    public void setFmodeId(Long fmodeId) {
        this.fmodeId = fmodeId;
    }

    public String getFmodeLevel1() {
        return fmodeLevel1;
    }

    public void setFmodeLevel1(String fmodeLevel1) {
        this.fmodeLevel1 = fmodeLevel1;
    }

    public String getFmodeLevel2() {
        return fmodeLevel2;
    }

    public void setFmodeLevel2(String fmodeLevel2) {
        this.fmodeLevel2 = fmodeLevel2;
    }
    public String getFmodeLevel3() {
        return fmodeLevel3;
    }

    public void setFmodeLevel3(String fmodeLevel3) {
        this.fmodeLevel3 = fmodeLevel3;
    }

    public String getFmodeDescription() {
        return fmodeDescription;
    }

    public void setFmodeDescription(String fmodeDescription) {
        this.fmodeDescription = fmodeDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FModeRef fmode = (FModeRef) o;
        return !(fmode.getFmodeId() == null || getFmodeId() == null) && Objects.equals(getFmodeId(), fmode.getFmodeId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFmodeId());
    }

    @Override
    public String toString() {
        return "fmode{" +
            " fmodeLevel1='" + fmodeLevel1 + '\'' +
            ", fmodeLevel2='" + fmodeLevel2 + '\'' +
            ", fmodeLevel3='" + fmodeLevel3 + '\'' +
            ", fmodeDescription='" + fmodeDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
