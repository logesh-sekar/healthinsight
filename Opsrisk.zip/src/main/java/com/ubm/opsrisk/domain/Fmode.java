package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Fmode.
 */
@Entity
//@Table(name = "fmode_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Fmode  implements Serializable {
	
	private static final long serialVersionUID = 1L;

    @Id
    
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "fmode_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long fmodeId;
    
	private String keyRiskArea;
	private String policyName;
	private String referenceFmode1;
	private String referenceFmode2;
	private String referenceFmode3;
	private String referenceFmode4;
	private String fmodeDescription;
	private String fmechReference;
	private String fmechDescription;
	private String fmechDetectability;
	private String fmechFrequency;
	private String materialityTypeFin;
	private String materialityLevel;
	private String materialityDescription;
	private String materialityTypeNFR;
	private String materialityDescription1;
	private String materialityDescription2;
	private String materialityDescription3;
	private String processID;
	private String processDescription;
	private String processStepId;
	private String processStepDescription;
	private String policyLevelControlDescription;
	private String policyLevelControl;
	private String controlType;
	private String controlDescription;
	private String controlFrequency;
	private String overallRiskScore1;
	private String overallRiskScore2;
	private String overallRiskScore3;
	
	public Long getFmodeId() {
        return fmodeId;
    }

    public void setFmodeId(Long fmodeId) {
        this.fmodeId = fmodeId;
    }
    
    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Fmode fmode = (Fmode) o;
        return !(fmode.getFmodeId() == null || getFmodeId() == null) && Objects.equals(getFmodeId(), fmode.getFmodeId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFmodeId());
    }

     
    @Override
    public String toString() {
        return "Fmode{" +
            "policyName='" + policyName + '\'' +
            ", keyRiskArea='" + keyRiskArea + '\'' +
            ", referenceFmode1='" + referenceFmode1 + '\'' +
            ", referenceFmode2='" + referenceFmode2 + '\'' +
            ", referenceFmode3='" + referenceFmode3 + '\'' +
            ", referenceFmode4='" + referenceFmode4 + '\'' +
            ", fmodeDescription='" + fmodeDescription + '\'' +
            ", fmechReference='" + fmechReference + '\'' +
            ", fmechDescription='" + fmechDescription + '\'' +
            ", fmechDetectability='" + fmechDetectability + '\'' +
            ", fmechFrequency='" + fmechFrequency + '\'' +
            ", materialityTypeFin='" + materialityTypeFin + '\'' +
            ", materialityLevel='" + materialityLevel + '\'' +
            ", materialityDescription='" + materialityDescription + '\'' +
            ", materialityTypeNFR='" + materialityTypeNFR + '\'' +
            ", materialityDescription1='" + materialityDescription1 + '\'' +
            ", materialityDescription2='" + materialityDescription2 + '\'' +
            ", materialityDescription3='" + materialityDescription3 + '\'' +
            ", processID='" + processID + '\'' +
            ", processDescription='" + processDescription + '\'' +
            ", processStepId='" + processStepId + '\'' +
            ", processStepDescription='" + processStepDescription + '\'' +
            ", policyLevelControlDescription='" + policyLevelControlDescription + '\'' +
            ", policyLevelControl='" + policyLevelControl + '\'' +
            ", controlType='" + controlType + '\'' +
            ", controlDescription='" + controlDescription + '\'' +
            ", controlFrequency='" + controlFrequency + '\'' +
            ", referenceFmode2='" + overallRiskScore1 + '\'' +
            ", referenceFmode2='" + overallRiskScore2 + '\'' +
            ", referenceFmode2='" + overallRiskScore3 + '\'' +
            
            "}";
    }
}
