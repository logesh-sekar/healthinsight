package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Control.
 */
@Entity
@Table(name = "controls_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Control extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "control_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private String controlRefId;
    
    @Column(name = "policy_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long policyRefId;

    @Column(name = "control_minimum_standard_id")
    private String controlMinimumStandardId;
    
    @NotNull
    @Column(name = "control_name")
    private String controlName;

    @Column(name = "control_description")
    private String controlDescription;
    
    @Column(name = "fmode_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long fmodeRefId;
    
    @Column(name = "control_releveant_process")
    private String controlReleveantProcess;
    
    @Column(name = "control_purpose")
    private String controlPurpose;
    
    @Column(name = "control_type")
    private String controlType;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public String getControlRefId() {
        return controlRefId;
    }

    public void setControlRefId(String controlRefId) {
        this.controlRefId = controlRefId;
    }

    public Long getPolicyRefId() {
        return policyRefId;
    }

    public void setPolicyRefId(Long policyRefId) {
        this.policyRefId = policyRefId;
    }
    
    public String getControlName() {
        return controlName;
    }

    public void setControlName(String controlName) {
        this.controlName = controlName;
    }
    
    public String getControlMinimumStandardId() {
        return controlMinimumStandardId;
    }

    public void setControlMinimumStandardId(String controlMinimumStandardId) {
        this.controlMinimumStandardId = controlMinimumStandardId;
    }

    public String getControlDescription() {
        return controlDescription;
    }

    public void setControlDescription(String controlDescription) {
        this.controlDescription = controlDescription;
    }
    
    public Long getFmodeRefId() {
        return fmodeRefId;
    }

    public void setFmodeRefId(Long fmodeRefId) {
        this.fmodeRefId = fmodeRefId;
    }

    public String getControlReleveantProcess() {
        return controlReleveantProcess;
    }

    public void setControlReleveantProcess(String controlReleveantProcess) {
        this.controlReleveantProcess = controlReleveantProcess;
    }

    public String getControlPurpose() {
        return controlPurpose;
    }

    public void setControlPurpose(String controlPurpose) {
        this.controlPurpose = controlPurpose;
    }

    public String getControlType() {
        return controlType;
    }

    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Control control = (Control) o;
        return !(control.getControlRefId() == null || getControlRefId() == null) && Objects.equals(getControlRefId(), control.getControlRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getControlRefId());
    }

    @Override
    public String toString() {
        return "Control{" +
        		" policyRefId='" + policyRefId + '\'' +
        		", controlMinimumStandardId='" + controlMinimumStandardId + '\'' +
        		", controlName='" + controlName + '\'' +
        		", fmodeRefId='" + fmodeRefId + '\'' +
        		", controlReleveantProcess='" + controlReleveantProcess + '\'' +
        		", controlPurpose='" + controlPurpose + '\'' +
        		", controlType='" + controlType + '\'' +
        		", isDelete='" + isDelete + '\'' +
            "}";
    }
}
