package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "kra_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Kra extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "kra_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long kraId;

    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "kra_label")
    private String kraLabel;

    @Column(name = "kra_description")
    private String kraDescription;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getKraId() {
        return kraId;
    }

    public void setKraId(Long kraId) {
        this.kraId = kraId;
    }

    public String getKraLabel() {
        return kraLabel;
    }

    public void setKraLabel(String kraLabel) {
        this.kraLabel = kraLabel;
    }

    public String getKraDescription() {
        return kraDescription;
    }

    public void setKraDescription(String kraDescription) {
        this.kraDescription = kraDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Kra kra = (Kra) o;
        return !(kra.getKraId() == null || getKraId() == null) && Objects.equals(getKraId(), kra.getKraId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getKraId());
    }

    @Override
    public String toString() {
        return "KRA{" +
            "kraLabel='" + kraLabel + '\'' +
            ", kraDescription='" + kraDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
