package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "fmech_ref_det_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FMechRefDet extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "fmech_ref_det_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long fmechRefDetId;

    @Column(name = "fmech_ref_det_description")
    private String fmechRefDetDescription;

    @Column(name = "fmech_ref_det_level")
    private String fmechRefDetLevel;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getFmechRefDetId() {
        return fmechRefDetId;
    }

    public void setFmechRefDetId(Long fmechRefDetId) {
        this.fmechRefDetId = fmechRefDetId;
    }

    public String getFmechRefDetDescription() {
        return fmechRefDetDescription;
    }

    public void setFmechRefDetDescription(String fmechRefDetDescription) {
        this.fmechRefDetDescription = fmechRefDetDescription;
    }

    public String getFmechRefDetLevel() {
        return fmechRefDetLevel;
    }

    public void setFmechRefDetLevel(String fmechRefDetLevel) {
        this.fmechRefDetLevel = fmechRefDetLevel;
    }

    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FMechRefDet fmech = (FMechRefDet) o;
        return !(fmech.getFmechRefDetId() == null || getFmechRefDetId() == null) && Objects.equals(getFmechRefDetId(), fmech.getFmechRefDetId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFmechRefDetId());
    }

    @Override
    public String toString() {
        return "FMechRefDet{" +
            " fmechRefDetDescription='" + fmechRefDetDescription + '\'' +
            ", fmechRefDetLevel='" + fmechRefDetLevel + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
