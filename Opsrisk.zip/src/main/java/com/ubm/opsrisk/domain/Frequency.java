package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "frequency_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Frequency extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "frequency_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long frequencyRefId;

    @NotNull
    @Column(name = "frequency_label")
    private String frequencyLabel;

    @Column(name = "frequency_name")
    private String frequencyName;

    @Column(name = "frequency_description")
    private String frequencyDescription;
    
    @Column(name = "frequency_upper" , columnDefinition="numeric(7,3)")
    private Double frequencyUpper;
    
    @Column(name = "frequency_lower", columnDefinition="numeric(7,3)")
    private Double frequencyLower;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getFrequencyRefId() {
        return frequencyRefId;
    }

    public void setFrequencyRefId(Long frequencyRefId) {
        this.frequencyRefId = frequencyRefId;
    }
    
    public String getFrequencyLabel() {
        return frequencyLabel;
    }

    public void setFrequencyLabel(String frequencyLabel) {
        this.frequencyLabel = frequencyLabel;
    }

    public String getFrequencyName() {
        return frequencyName;
    }

    public void setFrequencyName(String frequencyName) {
        this.frequencyName = frequencyName;
    }

    public String getFrequencyDescription() {
        return frequencyDescription;
    }

    public void setFrequencyDescription(String frequencyDescription) {
        this.frequencyDescription = frequencyDescription;
    }
    
    public Double getFrequencyUpper() {
        return frequencyUpper;
    }

    public void setFrequencyUpper(Double frequencyUpper) {
        this.frequencyUpper = frequencyUpper;
    }
    
    public Double getFrequencyLower() {
        return frequencyLower;
    }

    public void setFrequencyLower(Double frequencyLower) {
        this.frequencyLower = frequencyLower;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Frequency freq = (Frequency) o;
        return !(freq.getFrequencyRefId() == null || getFrequencyRefId() == null) && Objects.equals(getFrequencyRefId(), freq.getFrequencyRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFrequencyRefId());
    }

    @Override
    public String toString() {
        return "Frequency{" +
            " frequencyLabel='" + frequencyLabel + '\'' +
            ", frequencyName='" + frequencyName + '\'' +
            ", frequencyDescription='" + frequencyDescription + '\'' +
            ", frequencyUpper='" + frequencyUpper + '\'' +
            ", frequencyLower='" + frequencyLower + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
