package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "process_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Process extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "process_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long processRefId;

    @NotNull
    @Column(name = "process_id")
    private Long processId;
    
    @Column(name = "process_step_id")
    private String processStepId;
    
    @Column(name = "process_description")
    private String processDescription;

    @Column(name = "process_step_description")
    private String processStepDescription;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getProcessId() {
        return processId;
    }

    public void setProcessId(Long processId) {
        this.processId = processId;
    }
    
    public Long getProcessRefId() {
        return processRefId;
    }

    public void getProcessRefId(Long processRefId) {
        this.processRefId = processRefId;
    }

    public String getProcessStepId() {
        return processStepId;
    }

    public void setProcessStepId(String processStepId) {
        this.processStepId = processStepId;
    }

    public String getProcessStepDescription() {
        return processStepDescription;
    }

    public void setProcessStepDescription(String processStepDescription) {
        this.processStepDescription = processStepDescription;
    }

    public String getProcessDescription() {
        return processDescription;
    }

    public void setProcessDescription(String processDescription) {
        this.processDescription = processDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Process process = (Process) o;
        return !(process.getProcessRefId() == null || getProcessRefId() == null) && Objects.equals(getProcessRefId(), process.getProcessRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getProcessRefId());
    }

    @Override
    public String toString() {
        return "Process{" +
            "  processId='" + processId + '\'' +
            ", processStepId='" + processStepId + '\'' +
            ", processStepDescription='" + processStepDescription + '\'' +
            ", processDescription='" + processDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
