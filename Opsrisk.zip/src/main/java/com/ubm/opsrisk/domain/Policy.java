package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Policy.
 */
@Entity
@Table(name = "policy_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Policy extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "policy_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long policyId;

    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "policy_name", length = 100, unique = true, nullable = false)
    private String policyName;

    @Column(name = "policy_link")
    private String policyLink;

    @Column(name = "policy_description")
    private String policyDescription;
    
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getPolicyLink() {
        return policyLink;
    }

    public void setPolicyLink(String policyLink) {
        this.policyLink = policyLink;
    }

    public String getPolicyDescription() {
        return policyDescription;
    }

    public void setPolicyDescription(String policyDescription) {
        this.policyDescription = policyDescription;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Policy policy = (Policy) o;
        return !(policy.getPolicyId() == null || getPolicyId() == null) && Objects.equals(getPolicyId(), policy.getPolicyId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPolicyId());
    }

    @Override
    public String toString() {
        return "Policy{" +
            "policyName='" + policyName + '\'' +
            ", policyLink='" + policyLink + '\'' +
            ", policyDescription='" + policyDescription + '\'' +
            ", isDelete='" + isDelete + '\'' +
            "}";
    }
}
