package com.ubm.opsrisk.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A FinMatRef.
 */
@Entity
@Table(name = "finmat_ref_tbl")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FinMatRef extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "finmat_ref_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Long finmatRefId;
    
    @Column(name = "finmat_level")
    @NotNull
    private String finmatLevel;

    @Column(name = "finmat_label")
    private String finmatLabel;
    
    @Column(name = "finmat_ext_impact_description")
    private String finmatExtImpactDescription;

    @Column(name = "finmat_reg_impact_description")
    private String finmatRegImpactDescription;
    
    @Column(name = "finmat_brand")
    private String finmatBrand;
    
    @Column(name = "finmat_upper_threshold", columnDefinition="numeric(15,2)")
    private Double finmatUpperThreshold;
    
    @Column(name = "finmat_lower_threshold", columnDefinition="numeric(15,2)")
    private Double finmatLowerThreshold;
        
    @Column(name = "is_delete")
    private boolean isDelete;
    
    public Long getFinmatRefId() {
        return finmatRefId;
    }

    public void setFinmatRefId(Long finmatRefId) {
        this.finmatRefId = finmatRefId;
    }
    
    public String getFinmatLevel() {
        return finmatLevel;
    }

    public void setFinmatLevel(String finmatLevel) {
        this.finmatLevel = finmatLevel;
    }

    public String getFinmatLabel() {
        return finmatLabel;
    }

    public void setFinmatLabel(String finmatLabel) {
        this.finmatLabel = finmatLabel;
    }
    
    public String getFinmatExtImpactDescription() {
        return finmatExtImpactDescription;
    }

    public void setFinmatExtImpactDescription(String finmatExtImpactDescription) {
        this.finmatExtImpactDescription = finmatExtImpactDescription;
    }

    public String getFinmatRegImpactDescription() {
        return finmatRegImpactDescription;
    }

    public void setFinmatRegImpactDescription(String finmatRegImpactDescription) {
        this.finmatRegImpactDescription = finmatRegImpactDescription;
    }

    public String getFinmatBrand() {
        return finmatBrand;
    }

    public void setFinmatBrand(String finmatBrand) {
        this.finmatBrand = finmatBrand;
    }

    public Double getFinmatUpperThreshold() {
        return finmatUpperThreshold;
    }

    public void setFinmatUpperThreshold(Double finmatUpperThreshold) {
        this.finmatUpperThreshold = finmatUpperThreshold;
    }
    
    public Double getFinmatLowerThreshold() {
        return finmatLowerThreshold;
    }

    public void setFinmatLowerThreshold(Double finmatLowerThreshold) {
        this.finmatLowerThreshold = finmatLowerThreshold;
    }
    
    public boolean getIsDelete() {
        return isDelete;
    }
    
    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FinMatRef finmat = (FinMatRef) o;
        return !(finmat.getFinmatRefId() == null || getFinmatRefId() == null) && Objects.equals(getFinmatRefId(), finmat.getFinmatRefId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getFinmatRefId());
    }

    @Override
    public String toString() {
        return "FinMatRef{" +
        		" finmatLevel='" + finmatLevel + '\'' +
        		", finmatLabel='" + finmatLabel + '\'' +
        		", finmatExtImpactDescription='" + finmatExtImpactDescription + '\'' +
        		", finmatRegImpactDescription='" + finmatRegImpactDescription + '\'' +
        		", finmatBrand='" + finmatBrand + '\'' +
        		", finmatUpperThreshold='" + finmatUpperThreshold + '\'' +
        		", finmatLowerThreshold='" + finmatLowerThreshold + '\'' +
        		", isDelete='" + isDelete + '\'' +
            "}";
    }
}
