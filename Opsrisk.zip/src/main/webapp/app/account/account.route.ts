import { Routes } from '@angular/router';

import { activateRoute, passwordRoute, passwordResetFinishRoute, passwordResetInitRoute, registerRoute, settingsRoute,
    policiesRoute } from './';
import { frequencyRoute } from './frequency/frequency.route';
import { kraRoute } from './kra/kra.route';

const ACCOUNT_ROUTES = [activateRoute, passwordRoute, passwordResetFinishRoute, passwordResetInitRoute, registerRoute, settingsRoute,
    ...policiesRoute, ...frequencyRoute, ...kraRoute];

export const accountState: Routes = [
    {
        path: '',
        children: ACCOUNT_ROUTES,
        data: {
            authorities: ['ROLE_USER']
        },
    }
];
