import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { Frequency } from './frequency.model';
import { FrequencyService } from './frequency.service';
@Component({
    selector: 'jhi-profile-delete-dialog',
    templateUrl: './frequency-delete-dialog.component.html'
})
export class FrequencyDeleteDialogComponent {
    fmode: Frequency;

    constructor(private fmodeService: FrequencyService, public activeModal: NgbActiveModal, private eventManager: JhiEventManager) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(fmodeId) {
        this.fmodeService.delete(fmodeId).subscribe(response => {
            this.eventManager.broadcast({
                name: 'FrequencyListModification',
                content: 'Deleted a Frequency'
            });
            this.activeModal.dismiss(true);
        });
    }
}
