import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { SERVER_API_URL } from '../../app.constants';
import { createRequestOption } from '../../shared/util/request-util';
import { IFrequency } from './frequency.model';

@Injectable({ providedIn: 'root' })
export class FrequencyService {
    private resourceUrl = SERVER_API_URL + 'api/frequencies';

    constructor(private http: HttpClient) {}

    create(frequency: IFrequency): Observable<HttpResponse<IFrequency>> {
        return this.http.post<IFrequency>(this.resourceUrl, frequency, { observe: 'response' });
    }

    update(frequency: IFrequency): Observable<HttpResponse<IFrequency>> {
        return this.http.put<IFrequency>(this.resourceUrl, frequency, { observe: 'response' });
    }

    query(req?: any): Observable<HttpResponse<IFrequency[]>> {
        const options = createRequestOption(req);
        return this.http.get<IFrequency[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    find(frequencyId: string): Observable<HttpResponse<IFrequency>> {
        return this.http.get<IFrequency>(`${this.resourceUrl}/${frequencyId}`, { observe: 'response' });
    }

    delete(frequencyId: string): Observable<HttpResponse<any>> {
        return this.http.delete(`${this.resourceUrl}/${frequencyId}`, { observe: 'response' });
    }

}
