import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { FrequencyComponent } from './frequency.component';
import { FrequencyUpdateComponent } from './frequency-update.component';
import { FrequencyService } from './frequency.service';
import { Frequency, IFrequency } from './frequency.model';
import { Principal } from '../../core';

@Injectable({ providedIn: 'root' })
export class FrequencyResolve implements CanActivate {
    constructor(private principal: Principal) {}

    canActivate() {
        return this.principal.identity().then(account => this.principal.hasAnyAuthority(['ROLE_USER']));
    }
}

@Injectable({ providedIn: 'root' })
export class FrequencyMgmtResolve implements Resolve<any> {
    constructor(private service: FrequencyService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const id = route.params['frequencyRefId'] ? route.params['frequencyRefId'] : null;
        if (id) {
            return this.service.find(id);
        }
        return new Frequency();
    }
}

export const frequencyRoute: Routes = [
    {
        path: 'frequency',
        component: FrequencyComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            pageTitle: 'frequency.title',
            defaultSort: 'frequencyRefId,asc'
        }
    },
    // {
    //     path: 'user-management/:login/view',
    //     component: UserMgmtDetailComponent,
    //     resolve: {
    //         user: FrequencyMgmtResolve
    //     },
    //     data: {
    //         pageTitle: 'userManagement.home.title'
    //     }
    // },
    {
        path: 'frequency/new',
        component: FrequencyUpdateComponent,
        resolve: {
            frequency: FrequencyMgmtResolve
        }
    },
    {
        path: 'frequency/:frequencyRefId/edit',
        component: FrequencyUpdateComponent,
        resolve: {
            frequency: FrequencyMgmtResolve
        }
    }
];
