export interface IFrequency {
    frequencyRefId?: any;
    frequencyLabel?: string;
    frequencyName?: string;
    frequencyDescription?: string;
    frequencyUpper?: string;
    frequencyLower?: string;
    isDelete?: boolean;
}

export class Frequency implements IFrequency {
    constructor(
        public  frequencyRefId?: any,
        public  frequencyLabel?: string,
        public  frequencyName?: string,
        public  frequencyDescription?: string,
        public  frequencyUpper?: string,
        public  frequencyLower?: string,
        public isDelete?: boolean
    ) {
        this.frequencyRefId = frequencyRefId ? frequencyRefId : null;
        this.frequencyLabel = frequencyLabel ? frequencyLabel : null;
        this.frequencyName = frequencyName ? frequencyName : null;
        this.frequencyDescription = frequencyDescription ? frequencyDescription : null;
        this.frequencyUpper = frequencyUpper ? frequencyUpper : null;
        this.frequencyLower = frequencyLower ? frequencyLower : null;
        this.isDelete = isDelete ? isDelete : false;
    }
}
