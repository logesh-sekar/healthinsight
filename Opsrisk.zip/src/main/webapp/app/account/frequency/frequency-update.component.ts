import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Frequency } from './frequency.model';
import { FrequencyService } from './frequency.service';

@Component({
    selector: 'jhi-frequency-update',
    templateUrl: './frequency-update.component.html'
})
export class FrequencyUpdateComponent implements OnInit {
    frequency: Frequency;
    isSaving: boolean;

    constructor(
        private frequencyService: FrequencyService,
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.route.data.subscribe(({ frequency }) => {
            this.frequency = frequency.body ? frequency.body : frequency;
        });
    }

    previousState() {
        this.router.navigate(['/policies']);
    }

    save() {
        this.isSaving = true;
        if (this.frequency.frequencyRefId !== null) {
            this.frequencyService.update(this.frequency).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        } else {
            this.frequencyService.create(this.frequency).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        }
    }

    private onSaveSuccess(result) {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
