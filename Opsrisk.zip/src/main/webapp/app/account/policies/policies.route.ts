import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { PolicyComponent } from './policies.component';
import { PolicyUpdateComponent } from './policy-update.component';
import { PolicyService } from './policy.service';
import { Policy, IPolicy } from './policy.model';
import { Principal } from '../../../app/core';

@Injectable({ providedIn: 'root' })
export class PolicyResolve implements CanActivate {
    constructor(private principal: Principal) {}

    canActivate() {
        return this.principal.identity().then(account => this.principal.hasAnyAuthority(['ROLE_USER']));
    }
}

@Injectable({ providedIn: 'root' })
export class PolicyMgmtResolve implements Resolve<any> {
    constructor(private service: PolicyService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const id = route.params['policyId'] ? route.params['policyId'] : null;
        if (id) {
            return this.service.find(id);
        }
        return new Policy();
    }
}

export const policiesRoute: Routes = [
    {
        path: 'policies',
        component: PolicyComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            pageTitle: 'policies.title',
            defaultSort: 'policyId,asc'
        }
    },
    // {
    //     path: 'user-management/:login/view',
    //     component: UserMgmtDetailComponent,
    //     resolve: {
    //         user: PolicyMgmtResolve
    //     },
    //     data: {
    //         pageTitle: 'userManagement.home.title'
    //     }
    // },
    {
        path: 'policies/new',
        component: PolicyUpdateComponent,
        resolve: {
            policy: PolicyMgmtResolve
        }
    },
    {
        path: 'policies/:policyId/edit',
        component: PolicyUpdateComponent,
        resolve: {
            policy: PolicyMgmtResolve
        }
    }
];
