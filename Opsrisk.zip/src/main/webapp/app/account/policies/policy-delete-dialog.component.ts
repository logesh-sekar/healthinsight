import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { Policy } from './policy.model';
import { PolicyService } from './policy.service';
@Component({
    selector: 'jhi-profile-delete-dialog',
    templateUrl: './policy-delete-dialog.component.html'
})
export class PolicyDeleteDialogComponent {
    policy: Policy;

    constructor(private policyService: PolicyService, public activeModal: NgbActiveModal, private eventManager: JhiEventManager) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(policyId) {
        this.policyService.delete(policyId).subscribe(response => {
            this.eventManager.broadcast({
                name: 'PolicyListModification',
                content: 'Deleted a Policy'
            });
            this.activeModal.dismiss(true);
        });
    }
}
