import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { SERVER_API_URL } from '../../app.constants';
import { createRequestOption } from '../../shared/util/request-util';
import { IPolicy } from './policy.model';

@Injectable({ providedIn: 'root' })
export class PolicyService {
    private resourceUrl = SERVER_API_URL + 'api/policies';

    constructor(private http: HttpClient) {}

    create(policy: IPolicy): Observable<HttpResponse<IPolicy>> {
        return this.http.post<IPolicy>(this.resourceUrl, policy, { observe: 'response' });
    }

    update(policy: IPolicy): Observable<HttpResponse<IPolicy>> {
        return this.http.put<IPolicy>(this.resourceUrl, policy, { observe: 'response' });
    }

    query(req?: any): Observable<HttpResponse<IPolicy[]>> {
        const options = createRequestOption(req);
        return this.http.get<IPolicy[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    find(policyId: string): Observable<HttpResponse<IPolicy>> {
        return this.http.get<IPolicy>(`${this.resourceUrl}/${policyId}`, { observe: 'response' });
    }

    delete(policyId: string): Observable<HttpResponse<any>> {
        return this.http.delete(`${this.resourceUrl}/${policyId}`, { observe: 'response' });
    }

}
