export interface IPolicy {
    policyId?: any;
    policyName?: string;
    policyDescription?: string;
    policyLink?: string;
    isDelete?: boolean;
}

export class Policy implements IPolicy {
    constructor(
        public policyId?: any,
        public policyName?: string,
        public policyDescription?: string,
        public policyLink?: string,
        public isDelete?: boolean
    ) {
        this.policyId = policyId ? policyId : null;
        this.policyName = policyName ? policyName : null;
        this.policyDescription = policyDescription ? policyDescription : null;
        this.policyLink = policyLink ? policyLink : null;
        this.isDelete = isDelete ? isDelete : false;
    }
}
