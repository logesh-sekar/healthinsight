import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Policy } from './policy.model';
import { PolicyService } from './policy.service';

@Component({
    selector: 'jhi-policy-update',
    templateUrl: './policy-update.component.html'
})
export class PolicyUpdateComponent implements OnInit {
    policy: Policy;
    isSaving: boolean;

    constructor(
        private policyService: PolicyService,
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.route.data.subscribe(({ policy }) => {
            this.policy = policy.body ? policy.body : policy;
        });
    }

    previousState() {
        this.router.navigate(['/policies']);
    }

    save() {
        this.isSaving = true;
        if (this.policy.policyId !== null) {
            this.policyService.update(this.policy).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        } else {
            this.policyService.create(this.policy).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        }
    }

    private onSaveSuccess(result) {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
