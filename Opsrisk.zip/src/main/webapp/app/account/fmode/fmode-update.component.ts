import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fmode } from './fmode.model';
import { FmodeService } from './fmode.service';

@Component({
    selector: 'jhi-fmode-update',
    templateUrl: './fmode-update.component.html'
})
export class FmodeUpdateComponent implements OnInit {
    fmode: Fmode;
    isSaving: boolean;

    constructor(
        private fmodeService: FmodeService,
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.route.data.subscribe(({ fmode }) => {
            this.fmode = fmode.body ? fmode.body : fmode;
        });
    }

    previousState() {
        this.router.navigate(['/policies']);
    }

    save() {
        this.isSaving = true;
        if (this.fmode.fmodeId !== null) {
            this.fmodeService.update(this.fmode).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        } else {
            this.fmodeService.create(this.fmode).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        }
    }

    private onSaveSuccess(result) {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
