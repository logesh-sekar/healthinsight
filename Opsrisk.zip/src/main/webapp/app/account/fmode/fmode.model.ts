export interface IFmode {
    fmodeId?: any;
    keyRiskArea?: string;
    policyName?: string;
    referenceFmode1?: string;
    referenceFmode2?: string;
    referenceFmode3?: string;
    referenceFmode4?: string;
    fmodeDescription?: string;
    fmechReference?: string;
    fmechDescription?: string;
    fmechDetectability?: string;
    fmechFrequency?: string;
    materialityTypeFin?: string;
    materialityLevel?: string;
    materialityDescription?: string;
    materialityTypeNFR?: string;
    materialityDescription1?: string;
    materialityDescription2?: string;
    materialityDescription3?: string;
    processID?: string;
    processDescription?: string;
    processStepId?: string;
    processStepDescription?: string;
    policyLevelControlDescription?: string;
    policyLevelControl?: string;
    controlType?: string;
    controlDescription?: string;
    controlFrequency?: string;
    overallRiskScore1?: string;
    overallRiskScore2?: string;
    overallRiskScore3?: string;
    isDelete?: boolean;
}

export class Fmode implements IFmode {
    constructor(
        public  fmodeId?: any,
        public  keyRiskArea?: string,
        public  policyName?: string,
        public  referenceFmode1?: string,
        public  referenceFmode2?: string,
        public  referenceFmode3?: string,
        public  referenceFmode4?: string,
        public  fmodeDescription?: string,
        public  fmechReference?: string,
        public  fmechDescription?: string,
        public  fmechDetectability?: string,
        public  fmechFrequency?: string,
        public  materialityTypeFin?: string,
        public  materialityLevel?: string,
        public  materialityDescription?: string,
        public  materialityTypeNFR?: string,
        public  materialityDescription1?: string,
        public  materialityDescription2?: string,
        public  materialityDescription3?: string,
        public  processID?: string,
        public  processDescription?: string,
        public  processStepId?: string,
        public  processStepDescription?: string,
        public  policyLevelControlDescription?: string,
        public  policyLevelControl?: string,
        public  controlType?: string,
        public  controlDescription?: string,
        public  controlFrequency?: string,
        public  overallRiskScore1?: string,
        public  overallRiskScore2?: string,
        public  overallRiskScore3?: string,
        public isDelete?: boolean
    ) {
        this.fmodeId = fmodeId ? fmodeId : null;
        this.keyRiskArea = keyRiskArea ? keyRiskArea : null;
        this.policyName = policyName ? policyName : null;
        this.referenceFmode1 = referenceFmode1 ? referenceFmode1 : null;
        this.referenceFmode2 = referenceFmode2 ? referenceFmode2 : null;
        this.referenceFmode3 = referenceFmode3 ? referenceFmode3 : null;
        this.referenceFmode4 = referenceFmode4 ? referenceFmode4 : null;
        this.fmodeDescription = fmodeDescription ? fmodeDescription : null;
        this.fmechReference = fmechReference ? fmechReference : null;
        this.fmechDescription = fmechDescription ? fmechDescription : null;
        this.fmechDescription = fmechDescription ? fmechDescription : null;
        this.fmechFrequency = fmechFrequency ? fmechFrequency : null;
        this.materialityLevel = materialityLevel ? materialityLevel : null;
        this.materialityDescription = materialityDescription ? materialityDescription : null;
        this.materialityTypeNFR = materialityTypeNFR ? materialityTypeNFR : null;
        this.materialityDescription3 = materialityDescription3 ? materialityDescription3 : null;
        this.processID = processID ? processID : null;
        this.processDescription = processDescription ? processDescription : null;
        this.processStepId = processStepId ? processStepId : null;
        this.processStepDescription = processStepDescription ? processStepDescription : null;
        this.policyLevelControlDescription = policyLevelControlDescription ? policyLevelControlDescription : null;
        this.policyLevelControl = policyLevelControl ? policyLevelControl : null;
        this.controlDescription = controlDescription ? controlDescription : null;
        this.controlFrequency = controlFrequency ? controlFrequency : null;
        this.overallRiskScore1 = overallRiskScore1 ? overallRiskScore1 : null;
        this.overallRiskScore2 = overallRiskScore2 ? overallRiskScore2 : null;
        this.overallRiskScore3 = overallRiskScore3 ? overallRiskScore3 : null;
        this.isDelete = isDelete ? isDelete : false;
    }
}
