import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { Fmode } from './fmode.model';
import { FmodeService } from './fmode.service';
@Component({
    selector: 'jhi-profile-delete-dialog',
    templateUrl: './fmode-delete-dialog.component.html'
})
export class FmodeDeleteDialogComponent {
    fmode: Fmode;

    constructor(private fmodeService: FmodeService, public activeModal: NgbActiveModal, private eventManager: JhiEventManager) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(fmodeId) {
        this.fmodeService.delete(fmodeId).subscribe(response => {
            this.eventManager.broadcast({
                name: 'FmodeListModification',
                content: 'Deleted a Fmode'
            });
            this.activeModal.dismiss(true);
        });
    }
}
