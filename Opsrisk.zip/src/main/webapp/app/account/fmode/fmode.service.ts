import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { SERVER_API_URL } from '../../app.constants';
import { createRequestOption } from '../../shared/util/request-util';
import { IFmode } from './fmode.model';

@Injectable({ providedIn: 'root' })
export class FmodeService {
    private resourceUrl = SERVER_API_URL + 'api/fmode';

    constructor(private http: HttpClient) {}

    create(fmode: IFmode): Observable<HttpResponse<IFmode>> {
        return this.http.post<IFmode>(this.resourceUrl, fmode, { observe: 'response' });
    }

    update(fmode: IFmode): Observable<HttpResponse<IFmode>> {
        return this.http.put<IFmode>(this.resourceUrl, fmode, { observe: 'response' });
    }

    query(req?: any): Observable<HttpResponse<IFmode[]>> {
        const options = createRequestOption(req);
        return this.http.get<IFmode[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    find(fmodeId: string): Observable<HttpResponse<IFmode>> {
        return this.http.get<IFmode>(`${this.resourceUrl}/${fmodeId}`, { observe: 'response' });
    }

    delete(fmodeId: string): Observable<HttpResponse<any>> {
        return this.http.delete(`${this.resourceUrl}/${fmodeId}`, { observe: 'response' });
    }

}
