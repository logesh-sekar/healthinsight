import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { FmodeComponent } from './fmode.component';
import { FmodeUpdateComponent } from './fmode-update.component';
import { FmodeService } from './fmode.service';
import { Fmode, IFmode } from './fmode.model';
import { Principal } from '../../core';

@Injectable({ providedIn: 'root' })
export class FmodeResolve implements CanActivate {
    constructor(private principal: Principal) {}

    canActivate() {
        return this.principal.identity().then(account => this.principal.hasAnyAuthority(['ROLE_USER']));
    }
}

@Injectable({ providedIn: 'root' })
export class FmodeMgmtResolve implements Resolve<any> {
    constructor(private service: FmodeService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const id = route.params['policyId'] ? route.params['policyId'] : null;
        if (id) {
            return this.service.find(id);
        }
        return new Fmode();
    }
}

export const fmodeRoute: Routes = [
    {
        path: 'fmode',
        component: FmodeComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            pageTitle: 'fmode.title',
            defaultSort: 'fmodeId,asc'
        }
    },
    // {
    //     path: 'user-management/:login/view',
    //     component: UserMgmtDetailComponent,
    //     resolve: {
    //         user: FmodeMgmtResolve
    //     },
    //     data: {
    //         pageTitle: 'userManagement.home.title'
    //     }
    // },
    {
        path: 'fmode/new',
        component: FmodeUpdateComponent,
        resolve: {
            policy: FmodeMgmtResolve
        }
    },
    {
        path: 'fmode/:policyId/edit',
        component: FmodeUpdateComponent,
        resolve: {
            policy: FmodeMgmtResolve
        }
    }
];
