import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { SERVER_API_URL } from '../../app.constants';
import { createRequestOption } from '../../shared/util/request-util';
import { IKra } from './kra.model';

@Injectable({ providedIn: 'root' })
export class KraService {
    private resourceUrl = SERVER_API_URL + 'api/kra';

    constructor(private http: HttpClient) {}

    create(kra: IKra): Observable<HttpResponse<IKra>> {
        return this.http.post<IKra>(this.resourceUrl, kra, { observe: 'response' });
    }

    update(kra: IKra): Observable<HttpResponse<IKra>> {
        return this.http.put<IKra>(this.resourceUrl, kra, { observe: 'response' });
    }

    query(req?: any): Observable<HttpResponse<IKra[]>> {
        const options = createRequestOption(req);
        return this.http.get<IKra[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    find(kraId: string): Observable<HttpResponse<IKra>> {
        return this.http.get<IKra>(`${this.resourceUrl}/${kraId}`, { observe: 'response' });
    }

    delete(kraId: string): Observable<HttpResponse<any>> {
        return this.http.delete(`${this.resourceUrl}/${kraId}`, { observe: 'response' });
    }

}
