import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Kra } from './kra.model';
import { KraService } from './kra.service';

@Component({
    selector: 'jhi-kra-update',
    templateUrl: './kra-update.component.html'
})
export class KraUpdateComponent implements OnInit {
    kra: Kra;
    isSaving: boolean;

    constructor(
        private kraService: KraService,
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.route.data.subscribe(({ kra }) => {
            this.kra = kra.body ? kra.body : kra;
        });
    }

    previousState() {
        this.router.navigate(['/policies']);
    }

    save() {
        this.isSaving = true;
        if (this.kra.kraId !== null) {
            this.kraService.update(this.kra).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        } else {
            this.kraService.create(this.kra).subscribe(response => this.onSaveSuccess(response), () => this.onSaveError());
        }
    }

    private onSaveSuccess(result) {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
