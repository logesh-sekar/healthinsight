export interface IKra {
    kraId?: any;
    kraLabel?: string;
    kraDescription?: string;
    isDelete?: boolean;
}

export class Kra implements IKra {
    constructor(
        public  kraId?: any,
        public  kraLabel?: string,
        public  kraDescription?: string,
        public isDelete?: boolean
    ) {
        this.kraId = kraId ? kraId : null;
        this.kraLabel = kraLabel ? kraLabel : null;
        this.kraDescription = kraDescription ? kraDescription : null;
        this.isDelete = isDelete ? isDelete : false;
    }
}
