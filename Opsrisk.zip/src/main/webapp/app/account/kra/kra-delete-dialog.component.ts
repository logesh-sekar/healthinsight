import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { Kra } from './kra.model';
import { KraService } from './kra.service';
@Component({
    selector: 'jhi-profile-delete-dialog',
    templateUrl: './kra-delete-dialog.component.html'
})
export class KraDeleteDialogComponent {
    kra: Kra;

    constructor(private kraService: KraService, public activeModal: NgbActiveModal, private eventManager: JhiEventManager) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(kraId) {
        this.kraService.delete(kraId).subscribe(response => {
            this.eventManager.broadcast({
                name: 'KraListModification',
                content: 'Deleted a Kra'
            });
            this.activeModal.dismiss(true);
        });
    }
}
