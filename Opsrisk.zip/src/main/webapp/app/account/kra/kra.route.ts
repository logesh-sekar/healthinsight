import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { KraComponent } from './kra.component';
import { KraUpdateComponent } from './kra-update.component';
import { KraService } from './kra.service';
import { Kra, IKra } from './kra.model';
import { Principal } from '../../core';

@Injectable({ providedIn: 'root' })
export class KraResolve implements CanActivate {
    constructor(private principal: Principal) {}

    canActivate() {
        return this.principal.identity().then(account => this.principal.hasAnyAuthority(['ROLE_USER']));
    }
}

@Injectable({ providedIn: 'root' })
export class KraMgmtResolve implements Resolve<any> {
    constructor(private service: KraService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const id = route.params['policyId'] ? route.params['policyId'] : null;
        if (id) {
            return this.service.find(id);
        }
        return new Kra();
    }
}

export const kraRoute: Routes = [
    {
        path: 'kra',
        component: KraComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            pageTitle: 'kra.title',
            defaultSort: 'kraId,asc'
        }
    },
    // {
    //     path: 'user-management/:login/view',
    //     component: UserMgmtDetailComponent,
    //     resolve: {
    //         user: KraMgmtResolve
    //     },
    //     data: {
    //         pageTitle: 'userManagement.home.title'
    //     }
    // },
    {
        path: 'kra/new',
        component: KraUpdateComponent,
        resolve: {
            policy: KraMgmtResolve
        }
    },
    {
        path: 'kra/:kraId/edit',
        component: KraUpdateComponent,
        resolve: {
            policy: KraMgmtResolve
        }
    }
];
