import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { OpsriskRestSharedModule } from 'app/shared';

import {
    PasswordStrengthBarComponent,
    RegisterComponent,
    ActivateComponent,
    PasswordComponent,
    PasswordResetInitComponent,
    PasswordResetFinishComponent,
    SettingsComponent,
    PolicyComponent,
    PolicyUpdateComponent,
    PolicyDeleteDialogComponent,
    FrequencyComponent,
    FrequencyDeleteDialogComponent,
    FrequencyUpdateComponent,
    KraComponent,
    KraDeleteDialogComponent,
    KraUpdateComponent,
    accountState
} from './';

@NgModule({
    imports: [OpsriskRestSharedModule, RouterModule.forChild(accountState)],
    declarations: [
        ActivateComponent,
        RegisterComponent,
        PasswordComponent,
        PasswordStrengthBarComponent,
        PasswordResetInitComponent,
        PasswordResetFinishComponent,
        SettingsComponent,
        PolicyComponent,
        PolicyUpdateComponent,
        PolicyDeleteDialogComponent,
        FrequencyComponent,
        FrequencyDeleteDialogComponent,
        FrequencyUpdateComponent,
        KraComponent,
        KraDeleteDialogComponent,
        KraUpdateComponent
    ],
    entryComponents: [PolicyDeleteDialogComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class OpsriskRestAccountModule {}
